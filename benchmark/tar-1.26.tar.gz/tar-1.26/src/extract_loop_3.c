#include "extract_loop_3.h"
#ifndef fchown
# define fchown(fd, uid, gid) (errno = ENOSYS, -1)

#endif
#ifndef ALL_MODE_BITS
#define ALL_MODE_BITS ((mode_t) ~ (mode_t) 0)

#endif
#ifndef RECOVER_SKIP
#define RECOVER_SKIP 2

#endif
#ifndef RECOVER_OK
#define RECOVER_OK 1

#endif
#ifndef RECOVER_NO
#define RECOVER_NO 0

#endif
#ifndef fchmod
# define fchmod(fd, mode) (errno = ENOSYS, -1)

#endif

void extract_file_loop_2(off_t *size, struct tar_stat_info *current_stat_info, union block * *data_block, size_t *written, size_t *count, int *fd, char * *file_name)
{
    for ((*size) = (*current_stat_info).stat.st_size; (*size) > 0; )
      {
	mv_size_left ((*size));

	/* Locate data, determine max length writeable, write it,
	   block that we have used the data, then check if the write
	   worked.  */

	(*data_block) = find_next_block ();
	if (! (*data_block))
	  {
	    ERROR ((0, 0, _("Unexpected EOF in archive")));
	    break;		/* FIXME: What happens, then?  */
	  }

	(*written) = available_space_after ((*data_block));

	if ((*written) > (*size))
	  (*written) = (*size);
	errno = 0;
	(*count) = full_write ((*fd), (*data_block)->buffer, (*written));
	(*size) -= (*written);

	set_next_block_after ((union block *)
			      ((*data_block)->buffer + (*written) - 1));
	if ((*count) != (*written))
	  {
	    if (!to_command_option)
	      write_error_details ((*file_name), (*count), (*written));
	    /* FIXME: shouldn't we restore from backup? */
	    break;
	  }
      }
}
void repair_delayed_set_stat_loop_1(struct delayed_set_stat * *data, const struct stat * *dir_stat_info, struct tar_stat_info *current_stat_info, int *re_arg_pa1_1)
{
  for ((*data) = delayed_set_stat_head;  (*data);  (*data) = (*data)->next)
    {
      struct stat st;
      if (fstatat (chdir_fd, (*data)->file_name, &st, (*data)->atflag) != 0)
	{
	  stat_error ((*data)->file_name);
	  { (*re_arg_pa1_1) = 0; return; }
	}

      if (st.st_dev == (*dir_stat_info)->st_dev
	  && st.st_ino == (*dir_stat_info)->st_ino)
	{
	  (*data)->dev = (*current_stat_info).stat.st_dev;
	  (*data)->ino = (*current_stat_info).stat.st_ino;
	  (*data)->mode = (*current_stat_info).stat.st_mode;
	  (*data)->uid = (*current_stat_info).stat.st_uid;
	  (*data)->gid = (*current_stat_info).stat.st_gid;
	  (*data)->atime = (*current_stat_info).atime;
	  (*data)->mtime = (*current_stat_info).mtime;
	  (*data)->current_mode = st.st_mode;
	  (*data)->current_mode_mask = ALL_MODE_BITS;
	  (*data)->interdir = false;
	  { (*re_arg_pa1_1) = 0; return; }
	}
    }
}
void extract_link_loop_3(struct delayed_link * *ds, struct stat *st1, char * *file_name)
{
	    for (; (*ds); (*ds) = (*ds)->next)
	      if ((*ds)->change_dir == chdir_current
		  && (*ds)->dev == (*st1).st_dev
		  && (*ds)->ino == (*st1).st_ino
		  && timespec_cmp ((*ds)->ctime, get_stat_ctime (&(*st1))) == 0)
		{
		  struct string_list *p =  xmalloc (offsetof (struct string_list, string)
						    + strlen ((*file_name)) + 1);
		  strcpy (p->string, (*file_name));
		  p->next = (*ds)->sources;
		  (*ds)->sources = p;
		  break;
		}
}
