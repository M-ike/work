#include "misc_loop_5.h"

void code_ns_fraction_loop_2(char * *p, int *i, int *ns)
{
      for (;;)
	{
	  (*p)[--(*i)] = '0' + (*ns) % 10;
	  if ((*i) == 0)
	    break;
	  (*ns) /= 10;
	}
}
void must_be_dot_or_slash_loop_3(const char * *file_name, int *re_arg_pa1_3, _Bool *re_arg_pa2_3)
{
      for (;;)
	if (ISSLASH ((*file_name)[1]))
	  (*file_name)++;
	else if ((*file_name)[1] == '.'
                 && ISSLASH ((*file_name)[2 + ((*file_name)[2] == '.')]))
	  (*file_name) += 2 + ((*file_name)[2] == '.');
	else
	  { (*re_arg_pa1_3) = 0; (*re_arg_pa2_3) = ! (*file_name)[1]; return; }
}
void chdir_arg_loop_4(const char * *dir)
{
	for ((*dir) += 2;  ISSLASH (*(*dir));  (*dir)++)
	  continue;
}
void chdir_do_loop_5(size_t *ci, int *prev, int *i)
{
	  for ((*ci) = 1; (*prev) != (*i); (*ci)++)
	    {
	      int curr = wdcache[(*ci)];
	      wdcache[(*ci)] = (*prev);
	      if (curr == (*i))
		break;
	      (*prev) = curr;
	    }
}
void normalize_filename_x_loop_1(const char * *q, char * *p, char * *name)
{
  for ((*q) = (*p) = (*name); (*(*p) = *(*q)) == '.' && ISSLASH ((*q)[1]); (*p) += !*(*q))
    for ((*q) += 2; ISSLASH (*(*q)); (*q)++)
      continue;
}
