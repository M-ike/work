#include "suffix_loop_1.h"

void find_compression_program_loop_1(int *i, size_t *len, char * *suf, int *re_arg_pa1_1, const char * *re_arg_pa2_1)
{
      for ((*i) = 0; (*i) < nsuffixes; (*i)++)
	{
	  if (compression_suffixes[(*i)].length == (*len)
	      && memcmp (compression_suffixes[(*i)].suffix, (*suf), (*len)) == 0)
	    { (*re_arg_pa1_1) = 0; (*re_arg_pa2_1) = compression_suffixes[(*i)].program; return; }
	}
}
