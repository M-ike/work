#ifndef utf8_loop_1_h_
#define utf8_loop_1_h_

#include <system.h>
#include <quotearg.h>
#include <localcharset.h>
#include "common.h"

void string_ascii_p_loop_1(const char * *p, int *re_arg_pa1_1, _Bool *re_arg_pa2_1);

#endif
