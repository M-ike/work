#ifndef names_loop_8_h_
#define names_loop_8_h_

#include <system.h>
#include <fnmatch.h>
#include <hash.h>
#include <quotearg.h>
#include "common.h"

static struct name *namelist;	/* first name in list, if any */
struct name_elt        /* A name_array element. */
{
  char type;           /* Element type, see NELT_* constants above */
  union
  {
    const char *name;  /* File or directory name */
    int matching_flags;/* fnmatch options if type == NELT_FMASK */
  } v;
};
void merge_sort_sll_loop_4(struct name * *cursor, struct name * *list, int *counter, int *first_length);
void collect_and_sort_names_loop_6(struct name * *name);
void blank_name_list_loop_7(struct name * *name);
void contains_dot_dot_loop_8(const char * *p, int *re_arg_pa1_8, _Bool *re_arg_pa2_8);
void label_notfound_loop_3(const struct name * *cursor, int *re_arg_pa1_3);
void all_names_found_loop_2(const struct name * *cursor, size_t *len, struct tar_stat_info * *p, int *re_arg_pa1_2, _Bool *re_arg_pa2_2);
void namelist_match_loop_1(struct name * *p, const char * *file_name, int *re_arg_pa1_1, struct name * *re_arg_pa2_1);
void merge_sort_loop_5(struct name * *prev, struct name * *p, struct name * *head);

#endif
