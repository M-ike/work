#ifndef tar_loop_13_h_
#define tar_loop_13_h_

#include <system.h>
#include <fnmatch.h>
#include <argp.h>
#include <argp-namefrob.h>
#include <argp-fmtstream.h>
#include <argp-version-etc.h>
#include <signal.h>
#include "common.h"
#include <argmatch.h>
#include <closeout.h>
#include <configmake.h>
#include <exitfail.h>
#include <parse-datetime.h>
#include <rmt.h>
#include <rmt-command.h>
#include <prepargs.h>
#include <quotearg.h>
#include <version-etc.h>
#include <xstrtol.h>
#include <stdopen.h>
#include <priv-set.h>

static struct fmttab {
  char const *name;
  enum archive_format fmt;
} const fmttab[] = {
  { "v7",      V7_FORMAT },
  { "oldgnu",  OLDGNU_FORMAT },
  { "ustar",   USTAR_FORMAT },
  { "posix",   POSIX_FORMAT },
#if 0 /* not fully supported yet */
  { "star",    STAR_FORMAT },
#endif
  { "gnu",     GNU_FORMAT },
  { "pax",     POSIX_FORMAT }, /* An alias for posix */
  { NULL,      0 }
};
enum
{
  ANCHORED_OPTION = CHAR_MAX + 1,
  ATIME_PRESERVE_OPTION,
  BACKUP_OPTION,
  CHECK_DEVICE_OPTION,
  CHECKPOINT_OPTION,
  CHECKPOINT_ACTION_OPTION,
  DELAY_DIRECTORY_RESTORE_OPTION,
  HARD_DEREFERENCE_OPTION,
  DELETE_OPTION,
  EXCLUDE_BACKUPS_OPTION,
  EXCLUDE_CACHES_OPTION,
  EXCLUDE_CACHES_UNDER_OPTION,
  EXCLUDE_CACHES_ALL_OPTION,
  EXCLUDE_OPTION,
  EXCLUDE_TAG_OPTION,
  EXCLUDE_TAG_UNDER_OPTION,
  EXCLUDE_TAG_ALL_OPTION,
  EXCLUDE_VCS_OPTION,
  FORCE_LOCAL_OPTION,
  FULL_TIME_OPTION,
  GROUP_OPTION,
  IGNORE_CASE_OPTION,
  IGNORE_COMMAND_ERROR_OPTION,
  IGNORE_FAILED_READ_OPTION,
  INDEX_FILE_OPTION,
  KEEP_NEWER_FILES_OPTION,
  LEVEL_OPTION,
  LZIP_OPTION,
  LZMA_OPTION,
  LZOP_OPTION,
  MODE_OPTION,
  MTIME_OPTION,
  NEWER_MTIME_OPTION,
  NO_ANCHORED_OPTION,
  NO_AUTO_COMPRESS_OPTION,
  NO_CHECK_DEVICE_OPTION,
  NO_DELAY_DIRECTORY_RESTORE_OPTION,
  NO_IGNORE_CASE_OPTION,
  NO_IGNORE_COMMAND_ERROR_OPTION,
  NO_NULL_OPTION,
  NO_OVERWRITE_DIR_OPTION,
  NO_QUOTE_CHARS_OPTION,
  NO_RECURSION_OPTION,
  NO_SAME_OWNER_OPTION,
  NO_SAME_PERMISSIONS_OPTION,
  NO_SEEK_OPTION,
  NO_UNQUOTE_OPTION,
  NO_WILDCARDS_MATCH_SLASH_OPTION,
  NO_WILDCARDS_OPTION,
  NULL_OPTION,
  NUMERIC_OWNER_OPTION,
  OCCURRENCE_OPTION,
  OLD_ARCHIVE_OPTION,
  ONE_FILE_SYSTEM_OPTION,
  OVERWRITE_DIR_OPTION,
  OVERWRITE_OPTION,
  OWNER_OPTION,
  PAX_OPTION,
  POSIX_OPTION,
  PRESERVE_OPTION,
  QUOTE_CHARS_OPTION,
  QUOTING_STYLE_OPTION,
  RECORD_SIZE_OPTION,
  RECURSION_OPTION,
  RECURSIVE_UNLINK_OPTION,
  REMOVE_FILES_OPTION,
  RESTRICT_OPTION,
  RMT_COMMAND_OPTION,
  RSH_COMMAND_OPTION,
  SAME_OWNER_OPTION,
  SHOW_DEFAULTS_OPTION,
  SHOW_OMITTED_DIRS_OPTION,
  SHOW_TRANSFORMED_NAMES_OPTION,
  SPARSE_VERSION_OPTION,
  STRIP_COMPONENTS_OPTION,
  SUFFIX_OPTION,
  TEST_LABEL_OPTION,
  TOTALS_OPTION,
  TO_COMMAND_OPTION,
  TRANSFORM_OPTION,
  UNQUOTE_OPTION,
  UTC_OPTION,
  VOLNO_FILE_OPTION,
  WARNING_OPTION,
  WILDCARDS_MATCH_SLASH_OPTION,
  WILDCARDS_OPTION
};
enum wildcards
  {
    default_wildcards, /* For exclusion == enable_wildcards,
			  for inclusion == disable_wildcards */
    disable_wildcards,
    enable_wildcards
  };
struct tar_args        /* Variables used during option parsing */
{
  struct textual_date *textual_date; /* Keeps the arguments to --newer-mtime
					and/or --date option if they are
					textual dates */
  enum wildcards wildcards;        /* Wildcard settings (--wildcards/
				      --no-wildcards) */
  int matching_flags;              /* exclude_fnmatch options */
  int include_anchored;            /* Pattern anchoring options used for
				      file inclusion */
  bool o_option;                   /* True if -o option was given */
  bool pax_option;                 /* True if --pax-option was given */
  char const *backup_suffix_string;   /* --suffix option argument */
  char const *version_control_string; /* --backup option argument */
  bool input_files;                /* True if some input files where given */
  int compress_autodetect;         /* True if compression autodetection should
				      be attempted when creating archives */
};
struct textual_date
{
  struct textual_date *next;
  struct timespec ts;
  const char *option;
  char *date;
};
enum read_file_list_state  /* Result of reading file name from the list file */
  {
    file_list_success,     /* OK, name read successfully */
    file_list_end,         /* End of list file */
    file_list_zero,        /* Zero separator encountered where it should not */
    file_list_skip         /* Empty (zero-length) entry encountered, skip it */
  };
struct file_id_list
{
  struct file_id_list *next;
  ino_t ino;
  dev_t dev;
};
static struct file_id_list *file_id_list;
void update_argv_loop_8(char * *p, char * *start, size_t *count);
void expand_pax_option_loop_10(char * *p, size_t *len);
void update_argv_loop_7(size_t *size, char * *p, struct obstack *argv_stk);
void archive_format_string_loop_2(const struct fmttab * *p, enum archive_format *fmt, int *re_arg_pa1_2, const char * *re_arg_pa2_2);
void parse_opt_loop_11(char * *arg);
void add_file_id_loop_6(struct file_id_list * *p, struct stat *st, const char * *filename);
void add_exclude_array_loop_5(int *i, const char *const * *fv);
void update_argv_loop_9(size_t *i, struct argp_state * *state, char * *p, char * *start, int *term);
void tar_set_quoting_style_loop_4(int *i, char * *arg, int *re_arg_pa1_4);
void tar_list_quoting_styles_loop_3(int *i, struct obstack * *stk, size_t *prefixlen, const char * *prefix);
void find_argp_option_loop_13(struct argp_option * *o, int *letter, int *re_arg_pa1_13, struct argp_option * *re_arg_pa2_13);
void set_archive_format_loop_1(const struct fmttab * *p, const char * *name);
void parse_opt_loop_12(char * *arg);

#endif
