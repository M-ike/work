#ifndef buffer_loop_6_h_
#define buffer_loop_6_h_

#include <system.h>
#include <system-ioctl.h>
#include <signal.h>
#include <closeout.h>
#include <fnmatch.h>
#include <human.h>
#include <quotearg.h>
#include "common.h"
#include <rmt.h>

union block *record_start;      /* start of record of archive */
off_t records_read;             /* number of records read from this archive */
struct bufmap
{
  struct bufmap *next;          /* Pointer to the next map entry */
  size_t start;                 /* Offset of the first data block */
  char *file_name;              /* Name of the stored file */
  off_t sizetotal;              /* Size of the stored file */
  off_t sizeleft;               /* Size left to read/write */
};
static struct bufmap *bufmap_head, *bufmap_tail;
enum compress_type {
  ct_none,             /* Unknown compression type */
  ct_tar,              /* Plain tar file */
  ct_compress,
  ct_gzip,
  ct_bzip2,
  ct_lzip,
  ct_lzma,
  ct_lzop,
  ct_xz
};
struct zip_magic
{
  enum compress_type type;
  size_t length;
  char const *magic;
};
struct zip_program
{
  enum compress_type type;
  char const *program;
  char const *option;
};
static struct zip_magic const magic[] = {
  { ct_none, },
  { ct_tar },
  { ct_compress, 2, "\037\235" },
  { ct_gzip,     2, "\037\213" },
  { ct_bzip2,    3, "BZh" },
  { ct_lzip,     4, "LZIP" },
  { ct_lzma,     6, "\xFFLZMA" },
  { ct_lzop,     4, "\211LZO" },
  { ct_xz,       6, "\xFD" "7zXZ" },
};
static struct zip_program zip_program[] = {

  { ct_compress, COMPRESS_PROGRAM, "-Z" },
  { ct_compress, GZIP_PROGRAM,     "-z" },
  { ct_gzip,     GZIP_PROGRAM,     "-z" },
  { ct_bzip2,    BZIP2_PROGRAM,    "-j" },
  { ct_bzip2,    "lbzip2",         "-j" },
  { ct_lzip,     LZIP_PROGRAM,     "--lzip" },
  { ct_lzma,     LZMA_PROGRAM,     "--lzma" },
  { ct_lzma,     XZ_PROGRAM,       "-J" },
  { ct_lzop,     LZOP_PROGRAM,     "--lzop" },
  { ct_xz,       XZ_PROGRAM,       "-J" },
  { ct_none }
};

void bufmap_locate_loop_1(struct bufmap * *map, size_t *off);
void check_compressed_archive_loop_3(const struct zip_magic * *p, int *re_arg_pa1_3, enum compress_type *re_arg_pa2_3);
void drop_volume_label_suffix_loop_6(const char * *p, const char * *label, size_t *len);
void bufmap_reset_loop_2(struct bufmap * *map, ssize_t *fixup);
void change_tape_menu_loop_4(char * *name, char * *input_buffer);
void change_tape_menu_loop_5(char * *cursor, char * *name);

#endif
