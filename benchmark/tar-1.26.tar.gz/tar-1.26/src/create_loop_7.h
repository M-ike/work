#ifndef create_loop_7_h_
#define create_loop_7_h_

#include <system.h>
#include <quotearg.h>
#include "common.h"
#include <hash.h>

enum { IMPOSTOR_ERRNO = ENOENT };
struct link
  {
    dev_t dev;
    ino_t ino;
    nlink_t nlink;
    char name[1];
  };
struct exclusion_tag
{
  const char *name;
  size_t length;
  enum exclusion_tag_type type;
  bool (*predicate) (int fd);
  struct exclusion_tag *next;
};
static struct exclusion_tag *exclusion_tags;
static Hash_table *link_table;
void check_links_loop_7(struct link * *lp);
void check_exclusion_tags_loop_1(struct exclusion_tag * *tag, const struct tar_stat_info * *st, const char ** *tag_file_name, int *re_arg_pa1_1, enum exclusion_tag_type *re_arg_pa2_1);
void split_long_name_loop_3(size_t *i, size_t *length, const char * *name);
void simple_finish_header_loop_4(size_t *i, union block * *header, int *sum, char * *p);
void open_failure_recover_loop_6(struct tar_stat_info * *p, const struct tar_stat_info * *dir, int *re_arg_pa1_6, _Bool *re_arg_pa2_6);
void tar_copy_str_loop_2(size_t *i, size_t *len, char * *dst, const char * *src);
void dump_dir0_loop_5(const char * *entry, const char * *directory, size_t *entry_len, size_t *name_size, size_t *name_len, char * *name_buf, struct tar_stat_info * *st);

#endif
