#include "names_loop_8.h"
#ifndef NELT_NAME
#define NELT_NAME  0   
#endif
#ifndef NELT_FMASK
#define NELT_FMASK 2   
#endif
#ifndef NELT_CHDIR
#define NELT_CHDIR 1   
#endif

void merge_sort_sll_loop_4(struct name * *cursor, struct name * *list, int *counter, int *first_length)
{
  for ((*cursor) = (*list), (*counter) = (*first_length) - 1;
       (*counter);
       (*cursor) = SUCCESSOR ((*cursor)), (*counter)--)
    continue;
}
void collect_and_sort_names_loop_6(struct name * *name)
{
      for ((*name) = namelist; (*name) && (*name)->name[0] == 0; (*name)++)
	;
}
void blank_name_list_loop_7(struct name * *name)
{
  for ((*name) = namelist; (*name); (*name) = (*name)->next)
    (*name)->found_count = 0;
}
void contains_dot_dot_loop_8(const char * *p, int *re_arg_pa1_8, _Bool *re_arg_pa2_8)
{
  for (;; (*p)++)
    {
      if ((*p)[0] == '.' && (*p)[1] == '.' && (ISSLASH ((*p)[2]) || !(*p)[2]))
	{ (*re_arg_pa1_8) = 0; (*re_arg_pa2_8) = 1; return; }

      while (! ISSLASH (*(*p)))
	{
	  if (! *(*p)++)
	    { (*re_arg_pa1_8) = 0; (*re_arg_pa2_8) = 0; return; }
	}
    }
}
void label_notfound_loop_3(const struct name * *cursor, int *re_arg_pa1_3)
{
  for ((*cursor) = namelist; (*cursor); (*cursor) = (*cursor)->next)
    if (WASFOUND ((*cursor)))
      { (*re_arg_pa1_3) = 0; return; }
}
void all_names_found_loop_2(const struct name * *cursor, size_t *len, struct tar_stat_info * *p, int *re_arg_pa1_2, _Bool *re_arg_pa2_2)
{
  for ((*cursor) = namelist; (*cursor); (*cursor) = (*cursor)->next)
    {
      if (((*cursor)->name[0] && !WASFOUND ((*cursor)))
	  || ((*len) >= (*cursor)->length && ISSLASH ((*p)->file_name[(*cursor)->length])))
	{ (*re_arg_pa1_2) = 0; (*re_arg_pa2_2) = false; return; }
    }
}
void namelist_match_loop_1(struct name * *p, const char * *file_name, int *re_arg_pa1_1, struct name * *re_arg_pa2_1)
{
  for ((*p) = namelist; (*p); (*p) = (*p)->next)
    {
      if ((*p)->name[0]
	  && exclude_fnmatch ((*p)->name, (*file_name), (*p)->matching_flags))
	{ (*re_arg_pa1_1) = 0; (*re_arg_pa2_1) = (*p); return; }
    }
}
void merge_sort_loop_5(struct name * *prev, struct name * *p, struct name * *head)
{
  for ((*prev) = NULL, (*p) = (*head); (*p); (*prev) = (*p), (*p) = (*p)->next)
    (*p)->prev = (*prev);
}
