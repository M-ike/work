#include "incremen_loop_11.h"
#ifndef TEMP_DIR_TEMPLATE
#define TEMP_DIR_TEMPLATE "tar.XXXXXX"

#endif
#ifndef DIR_CLEAR_FLAG
#define DIR_CLEAR_FLAG(d,f) (d)->flags &= ~(f)

#endif
#ifndef TAR_INCREMENTAL_VERSION
#define TAR_INCREMENTAL_VERSION 2

#endif
#ifndef DIR_IS_INITED
#define DIR_IS_INITED(d) ((d)->flags & DIRF_INIT)

#endif
#ifndef DIR_IS_NFS
#define DIR_IS_NFS(d) ((d)->flags & DIRF_NFS)

#endif
#ifndef DIR_SET_FLAG
#define DIR_SET_FLAG(d,f) (d)->flags |= (f)

#endif
#ifndef DIR_IS_RENAMED
#define DIR_IS_RENAMED(d) ((d)->flags & DIRF_RENAMED)

#endif
#ifndef DIRF_INIT
#define DIRF_INIT     0x0001    
#endif
#ifndef DIRF_RENAMED
#define DIRF_RENAMED  0x0010    
#endif
#ifndef DIRF_NFS
#define DIRF_NFS      0x0002    
#endif
#ifndef DIRF_NEW
#define DIRF_NEW      0x0008    
#endif
#ifndef DIRF_FOUND
#define DIRF_FOUND    0x0004    
#endif
#ifndef DIR_IS_FOUND
#define DIR_IS_FOUND(d) ((d)->flags & DIRF_FOUND)

#endif
#ifndef PD_CHILDREN
#define PD_CHILDREN(f) ((f) & 3)

#endif
#ifndef PD_FORCE_CHILDREN
#define PD_FORCE_CHILDREN 0x10

#endif
#ifndef PD_FORCE_INIT
#define PD_FORCE_INIT     0x20

#endif
#ifndef ST_DEV_MSB
# define ST_DEV_MSB(st) (~ (dev_t) 0 << (sizeof (st).st_dev * CHAR_BIT - 1))

#endif
#ifndef NFS_FILE_STAT
# define NFS_FILE_STAT(st) (((st).st_dev & ST_DEV_MSB (st)) != 0)

#endif

void read_unsigned_num_loop_9(size_t *i, int *c, char buf[], FILE * *fp)
{
  for ((*i) = 0; ISDIGIT ((*c)); (*i)++)
    {
      if ((*i) == sizeof(char)*21- 1)
	FATAL_ERROR ((0, 0, _("Field too long while reading snapshot file")));
      buf[(*i)] = (*c);
      (*c) = getc ((*fp));
    }
}
void store_rename_loop_6(struct directory * *prev, struct directory * *dir)
{
      for ((*prev) = (*dir); (*prev) && (*prev)->orig != (*dir); (*prev) = (*prev)->orig)
	DIR_CLEAR_FLAG ((*prev), DIRF_RENAMED);
}
void makedumpdir_loop_5(size_t *i, const char * *p, const char * *dir, const char ** *array)
{
  for ((*i) = 0, (*p) = (*dir); *(*p); (*p) += strlen ((*p)) + 1, (*i)++)
    (*array)[(*i)] = (*p);
}
void get_gnu_dumpdir_loop_10(size_t *size, size_t *copied, union block * *data_block, char * *to)
{
  for (; (*size) > 0; (*size) -= (*copied))
    {
      mv_size_left ((*size));
      (*data_block) = find_next_block ();
      if (!(*data_block))
	ERROR ((1, 0, _("Unexpected EOF in archive")));
      (*copied) = available_space_after ((*data_block));
      if ((*copied) > (*size))
	(*copied) = (*size);
      memcpy ((*to), (*data_block)->buffer, (*copied));
      (*to) += (*copied);
      set_next_block_after ((union block *)
			    ((*data_block)->buffer + (*copied) - 1));
    }
}
void makedumpdir_loop_4(const char * *p, const char * *dir, size_t *dirsize, size_t *len)
{
  for ((*p) = (*dir); *(*p); (*p) += strlen ((*p)) + 1, (*dirsize)++)
    (*len) += strlen ((*p)) + 2;
}
void dirlist_replace_prefix_loop_3(struct directory * *dp, const char * *pref, size_t *pref_len, const char * *repl, size_t *repl_len)
{
  for ((*dp) = dirhead; (*dp); (*dp) = (*dp)->next)
    replace_prefix (&(*dp)->name, (*pref), (*pref_len), (*repl), (*repl_len));
}
void dumpdir_ok_loop_11(char * *p, char * *dumpdir, int *expect, int *has_tempdir, int *re_arg_pa1_11, _Bool *re_arg_pa2_11)
{
  for ((*p) = (*dumpdir); *(*p); (*p) += strlen ((*p)) + 1)
    {
      if ((*expect) && *(*p) != (*expect))
	{
	  ERROR ((0, 0,
		  _("Malformed dumpdir: expected '%c' but found %#3o"),
		  (*expect), *(*p)));
	  { (*re_arg_pa1_11) = 0; (*re_arg_pa2_11) = false; return; }
	}
      switch (*(*p))
	{
	case 'X':
	  if ((*has_tempdir))
	    {
	      ERROR ((0, 0,
		      _("Malformed dumpdir: 'X' duplicated")));
	      { (*re_arg_pa1_11) = 0; (*re_arg_pa2_11) = false; return; }
	    }
	  else
	    (*has_tempdir) = 1;
	  break;

	case 'R':
	  if ((*p)[1] == 0)
	    {
	      if (!(*has_tempdir))
		{
		  ERROR ((0, 0,
			  _("Malformed dumpdir: empty name in 'R'")));
		  { (*re_arg_pa1_11) = 0; (*re_arg_pa2_11) = false; return; }
		}
	      else
		(*has_tempdir) = 0;
	    }
	  (*expect) = 'T';
	  break;

	case 'T':
	  if ((*expect) != 'T')
	    {
	      ERROR ((0, 0,
		      _("Malformed dumpdir: 'T' not preceeded by 'R'")));
	      { (*re_arg_pa1_11) = 0; (*re_arg_pa2_11) = false; return; }
	    }
	  if ((*p)[1] == 0 && !(*has_tempdir))
	    {
	      ERROR ((0, 0,
		      _("Malformed dumpdir: empty name in 'T'")));
	      { (*re_arg_pa1_11) = 0; (*re_arg_pa2_11) = false; return; }
	    }
	  (*expect) = 0;
	  break;

	case 'N':
	case 'Y':
	case 'D':
	  break;

	default:
	  /* FIXME: bail out? */
	  break;
	}
    }
}
void read_negative_num_loop_8(size_t *i, int *c, FILE * *fp, char buf[])
{
  for ((*i) = 1; ISDIGIT ((*c) = getc ((*fp))); (*i)++)
    {
      if ((*i) == sizeof(char)*21- 1)
	FATAL_ERROR ((0, 0, _("Field too long while reading snapshot file")));
      buf[(*i)] = (*c);
    }
}
void dumpdir_create0_loop_1(size_t *i, size_t *total, size_t *ctsize, const char * *q, const char * *contents, size_t *len, const char * *cmask)
{
  for ((*i) = 0, (*total) = 0, (*ctsize) = 1, (*q) = (*contents); *(*q); (*total)++, (*q) += (*len))
    {
      (*len) = strlen ((*q)) + 1;
      (*ctsize) += (*len);
      if (!(*cmask) || strchr ((*cmask), *(*q)))
	(*i)++;
    }
}
void dumpdir_create0_loop_2(size_t *i, char * *p, struct dumpdir * *dump, const char * *cmask)
{
  for ((*i) = 0, (*p) = (*dump)->contents; *(*p); (*p) += strlen ((*p)) + 1)
    {
      if (!(*cmask) || strchr ((*cmask), *(*p)))
	(*dump)->elv[(*i)++] = (*p) + 1;
    }
}
void read_obstack_loop_7(size_t *i, int *c, FILE * *fp, struct obstack * *stk)
{
  for ((*i) = 0, (*c) = getc ((*fp)); (*c) != EOF && (*c) != 0; (*c) = getc ((*fp)), (*i)++)
    obstack_1grow ((*stk), (*c));
}
