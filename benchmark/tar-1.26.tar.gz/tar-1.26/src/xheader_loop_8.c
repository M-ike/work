#include "xheader_loop_8.h"
#ifndef XHDR_GLOBAL
#define XHDR_GLOBAL    0x02

#endif
#ifndef GLOBAL_HEADER_TEMPLATE
#define GLOBAL_HEADER_TEMPLATE "/GlobalHead.%p.%n"

#endif
#ifndef XHDR_PROTECTED
#define XHDR_PROTECTED 0x01

#endif

void xheader_protected_pattern_p_loop_6(const struct xhdr_tab * *p, const char * *pattern, int *re_arg_pa1_6, _Bool *re_arg_pa2_6)
{
  for ((*p) = xhdr_tab; (*p)->keyword; (*p)++)
    if (((*p)->flags & XHDR_PROTECTED) && fnmatch ((*pattern), (*p)->keyword, 0) == 0)
      { (*re_arg_pa1_6) = 0; (*re_arg_pa2_6) = true; return; }
}
void xheader_set_keyword_equal_loop_3(char * *p, char * *eq)
{
  for ((*p) = (*eq) + 1; *(*p) && isspace ((unsigned char) *(*p)); (*p)++)
    ;
}
void xheader_format_name_loop_4(char * *q, char * *buf, const char * *p, const char * *fmt, char * *dir, char * *base, const char * *pptr, const char * *nptr)
{
  for ((*q) = (*buf), (*p) = (*fmt); *(*p); )
    {
      if (*(*p) == '%')
	{
	  switch ((*p)[1])
	    {
	    case '%':
	      *(*q)++ = *(*p)++;
	      (*p)++;
	      break;

	    case 'd':
	      if ((*dir))
		(*q) = stpcpy ((*q), (*dir));
	      (*p) += 2;
	      break;

	    case 'f':
	      if ((*base))
		(*q) = stpcpy ((*q), (*base));
	      (*p) += 2;
	      break;

	    case '(*p)':
	      (*q) = stpcpy ((*q), (*pptr));
	      (*p) += 2;
	      break;

	    case 'n':
	      if ((*nptr))
		{
		  (*q) = stpcpy ((*q), (*nptr));
		  (*p) += 2;
		  break;
		}
	      /* else fall through */

	    default:
	      *(*q)++ = *(*p)++;
	      if (*(*p))
		*(*q)++ = *(*p)++;
	    }
	}
      else
	*(*q)++ = *(*p)++;
    }
}
void decode_record_loop_8(char * *p, char * *len_lim)
{
  for ((*p) = (*len_lim); *(*p) == ' ' || *(*p) == '\t'; (*p)++)
    continue;
}
void xheader_keyword_override_p_loop_2(struct keyword_list * *kp, const char * *keyword, int *re_arg_pa1_2, _Bool *re_arg_pa2_2)
{
  for ((*kp) = keyword_override_list; (*kp); (*kp) = (*kp)->next)
    if (strcmp ((*kp)->pattern, (*keyword)) == 0)
      { (*re_arg_pa1_2) = 0; (*re_arg_pa2_2) = true; return; }
}
void xheader_keyword_deleted_p_loop_1(struct keyword_list * *kp, const char * *kw, int *re_arg_pa1_1, _Bool *re_arg_pa2_1)
{
  for ((*kp) = keyword_pattern_list; (*kp); (*kp) = (*kp)->next)
    if (fnmatch ((*kp)->pattern, (*kw), 0) == 0)
      { (*re_arg_pa1_1) = 0; (*re_arg_pa2_1) = true; return; }
}
void xheader_protected_keyword_p_loop_7(const struct xhdr_tab * *p, const char * *keyword, int *re_arg_pa1_7, _Bool *re_arg_pa2_7)
{
  for ((*p) = xhdr_tab; (*p)->keyword; (*p)++)
    if (((*p)->flags & XHDR_PROTECTED) && strcmp ((*p)->keyword, (*keyword)) == 0)
      { (*re_arg_pa1_7) = 0; (*re_arg_pa2_7) = true; return; }
}
void locate_handler_loop_5(const struct xhdr_tab * *p, const char * *keyword, int *re_arg_pa1_5, const struct xhdr_tab * *re_arg_pa2_5)
{
  for ((*p) = xhdr_tab; (*p)->keyword; (*p)++)
    if (strcmp ((*p)->keyword, (*keyword)) == 0)
      { (*re_arg_pa1_5) = 0; (*re_arg_pa2_5) = (*p); return; }
}
