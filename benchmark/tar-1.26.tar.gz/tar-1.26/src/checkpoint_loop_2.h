#ifndef checkpoint_loop_2_h_
#define checkpoint_loop_2_h_

#include <system.h>
#include "common.h"

enum checkpoint_opcode
  {
    cop_dot,
    cop_bell,
    cop_echo,
    cop_ttyout,
    cop_sleep,
    cop_exec
  };
struct checkpoint_action
{
  struct checkpoint_action *next;
  enum checkpoint_opcode opcode;
  union
  {
    time_t time;
    char *command;
  } v;
};
static struct checkpoint_action *checkpoint_action, *checkpoint_action_tail;
void expand_checkpoint_string_loop_1(const char * *ip, const char * *input, size_t *outlen, size_t *cpslen, size_t *opstrlen);
void expand_checkpoint_string_loop_2(const char * *ip, const char * *input, char * *op, char * *output, char * *cps, const char * *opstr);

#endif
