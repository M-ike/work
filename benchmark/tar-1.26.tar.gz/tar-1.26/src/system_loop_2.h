#ifndef system_loop_2_h_
#define system_loop_2_h_

#include <system.h>
#include "common.h"
#include <priv-set.h>
#include <rmt.h>
#include <signal.h>

extern union block *record_start; /* FIXME */
void sys_child_open_for_compress_loop_1(size_t *length, char * *cursor, size_t *status);
void run_decompress_program_loop_2(const char * *p, int *i, const char * *prog);

#endif
