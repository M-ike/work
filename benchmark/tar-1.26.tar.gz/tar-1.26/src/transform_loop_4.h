#ifndef transform_loop_4_h_
#define transform_loop_4_h_

#include <system.h>
#include <regex.h>
#include "common.h"

enum transform_type
  {
    transform_first,
    transform_global
  };
enum replace_segm_type
  {
    segm_literal,   /* Literal segment */
    segm_backref,   /* Back-reference segment */
    segm_case_ctl   /* Case control segment (GNU extension) */
  };
enum case_ctl_type
  {
    ctl_stop,       /* Stop case conversion */
    ctl_upcase_next,/* Turn the next character to uppercase */
    ctl_locase_next,/* Turn the next character to lowercase */
    ctl_upcase,     /* Turn the replacement to uppercase until ctl_stop */
    ctl_locase      /* Turn the replacement to lowercase until ctl_stop */
  };
struct replace_segm
{
  struct replace_segm *next;
  enum replace_segm_type type;
  union
  {
    struct
    {
      char *ptr;
      size_t size;
    } literal;                /* type == segm_literal */
    size_t ref;               /* type == segm_backref */
    enum case_ctl_type ctl;   /* type == segm_case_ctl */
  } v;
};
struct transform
{
  struct transform *next;
  enum transform_type transform_type;
  int flags;
  unsigned match_number;
  regex_t regex;
  /* Compiled replacement expression */
  struct replace_segm *repl_head, *repl_tail;
  size_t segm_count; /* Number of elements in the above list */
};
static struct transform *transform_head, *transform_tail;
void parse_transform_expr_loop_2(int *j, int *i, const char * *expr, int *delim);
void parse_transform_expr_loop_1(int *i, const char * *expr, int *delim);
void run_case_conv_loop_3(char * *p, char * *case_ctl_buffer, size_t *size);
void run_case_conv_loop_4(char * *p, char * *case_ctl_buffer, size_t *size);

#endif
