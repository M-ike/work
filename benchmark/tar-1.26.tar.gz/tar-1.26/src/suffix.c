#include "suffix_loop_1.h"
/* This file is part of GNU tar.
   Copyright (C) 2007, 2009 Free Software Foundation, Inc.

   Written by Sergey Poznyakoff.

   GNU tar is free software; you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the
   Free Software Foundation; either version 3, or (at your option) any later
   version.

   GNU tar is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
   Public License for more details.

   You should have received a copy of the GNU General Public License along
   with GNU tar.  If not, see <http://www.gnu.org/licenses/>.  */





static const char *
find_compression_program (const char *name, const char *defprog)
{
  char *suf = strrchr (name, '.');

  if (suf)
    {
      int i;
      size_t len;

      suf++;
      len = strlen (suf);

	{ int re_arg_pa1_1 = -1; const char * re_arg_pa2_1;
    find_compression_program_loop_1(&i, &len, &suf, &re_arg_pa1_1, &re_arg_pa2_1);
	if(re_arg_pa1_1 != -1) return re_arg_pa2_1; }
    }
  return defprog;
}

void
set_compression_program_by_suffix (const char *name, const char *defprog)
{
  const char *program = find_compression_program (name, defprog);
  if (program)
    use_compress_program_option = program;
}
