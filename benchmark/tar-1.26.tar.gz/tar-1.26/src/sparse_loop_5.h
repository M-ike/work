#ifndef sparse_loop_5_h_
#define sparse_loop_5_h_

#include <system.h>
#include <inttostr.h>
#include <quotearg.h>
#include "common.h"

struct tar_sparse_file;
enum sparse_scan_state
  {
    scan_begin,
    scan_block,
    scan_end
  };
struct tar_sparse_optab
{
  bool (*init) (struct tar_sparse_file *);
  bool (*done) (struct tar_sparse_file *);
  bool (*sparse_member_p) (struct tar_sparse_file *);
  bool (*dump_header) (struct tar_sparse_file *);
  bool (*fixup_header) (struct tar_sparse_file *);
  bool (*decode_header) (struct tar_sparse_file *);
  bool (*scan_block) (struct tar_sparse_file *, enum sparse_scan_state,
		      void *);
  bool (*dump_region) (struct tar_sparse_file *, size_t);
  bool (*extract_region) (struct tar_sparse_file *, size_t);
};
struct tar_sparse_file
{
  int fd;                           /* File descriptor */
  bool seekable;                    /* Is fd seekable? */
  off_t offset;                     /* Current offset in fd if seekable==false.
				       Otherwise unused */
  off_t dumped_size;                /* Number of bytes actually written
				       to the archive */
  struct tar_stat_info *stat_info;  /* Information about the file */
  struct tar_sparse_optab const *optab; /* Operation table */
  void *closure;                    /* Any additional data optab calls might
				       require */
};
enum oldgnu_add_status
  {
    add_ok,
    add_finish,
    add_fail
  };
void pax_dump_header_0_loop_3(size_t *i, struct tar_sparse_file * *file, struct sp_array * *map, char nbuf[]);
void pax_dump_header_1_loop_5(size_t *i, struct tar_sparse_file * *file, char * *p, struct sp_array * *map, char nbuf[], union block * *blk, char * *q);
void pax_dump_header_0_loop_2(size_t *i, struct tar_sparse_file * *file);
void oldgnu_store_sparse_info_loop_1(size_t * *pindex, struct tar_sparse_file * *file, size_t *sparse_size, struct sparse * *sp);
void pax_dump_header_1_loop_4(size_t *i, struct tar_sparse_file * *file, char * *p, struct sp_array * *map, char nbuf[], off_t *size);

#endif
