#include "utf8_loop_1.h"
#ifndef iconv
# define iconv(cd, inbuf, inbytesleft, outbuf, outbytesleft) ((size_t) 0)

#endif
#ifndef iconv_open
# define iconv_open(tocode, fromcode) ((iconv_t) -1)

#endif
#ifndef ICONV_CONST
# define ICONV_CONST

#endif
#ifndef iconv_close
# define iconv_close(cd) 0

#endif

void string_ascii_p_loop_1(const char * *p, int *re_arg_pa1_1, _Bool *re_arg_pa2_1)
{
  for (; *(*p); (*p)++)
    if (*(*p) & ~0x7f)
      { (*re_arg_pa1_1) = 0; (*re_arg_pa2_1) = false; return; }
}
