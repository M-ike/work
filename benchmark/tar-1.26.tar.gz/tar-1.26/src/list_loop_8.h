#ifndef list_loop_8_h_
#define list_loop_8_h_

#include <system.h>
#include <inttostr.h>
#include <quotearg.h>
#include "common.h"

static char const base_64_digits[64] =
{
  'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M',
  'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
  'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm',
  'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z',
  '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '+', '/'
};
static char base64_map[UCHAR_MAX + 1];
void from_header_loop_8(uintmax_t *value, const char * *where, const char * *lim, uintmax_t *topbits, const char * *type, _Bool *silent, int *re_arg_pa1_8, uintmax_t *re_arg_pa2_8);
void from_header_loop_6(uintmax_t *value, const char * *where, const char * *lim, uintmax_t *overflow);
void base64_init_loop_1(int *i);
void from_header_loop_5(const char * *where, const char * *lim, const char * *type, _Bool *silent, int *re_arg_pa1_5, uintmax_t *re_arg_pa2_5);
void tar_checksum_loop_3(size_t *i, union block * *header, int *unsigned_sum, int *signed_sum);
void read_header_loop_4(size_t *size, size_t *written, union block * *data_block, char * *bp);
void tar_checksum_loop_2(size_t *i, union block * *header, int *unsigned_sum, char * *p, int *signed_sum);
void from_header_loop_7(uintmax_t *value, int *digit, const char * *where, const char * *lim, uintmax_t *overflow);

#endif
