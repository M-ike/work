#include "transform_loop_4.h"
#ifndef CASE_CTL_RESET
#define CASE_CTL_RESET()  if (case_ctl == ctl_upcase_next     \
			      || case_ctl == ctl_locase_next) \
                            {                                 \
                              case_ctl = save_ctl;            \
                              save_ctl = ctl_stop;            \
			    }

#endif

void parse_transform_expr_loop_2(int *j, int *i, const char * *expr, int *delim)
{
  for ((*j) = (*i) + 1; (*expr)[(*j)] && (*expr)[(*j)] != (*delim); (*j)++)
    if ((*expr)[(*j)] == '\\' && (*expr)[(*j)+1])
      (*j)++;
}
void parse_transform_expr_loop_1(int *i, const char * *expr, int *delim)
{
  for ((*i) = 2; (*expr)[(*i)] && (*expr)[(*i)] != (*delim); (*i)++)
    if ((*expr)[(*i)] == '\\' && (*expr)[(*i)+1])
      (*i)++;
}
void run_case_conv_loop_3(char * *p, char * *case_ctl_buffer, size_t *size)
{
      for ((*p) = (*case_ctl_buffer); (*p) < (*case_ctl_buffer) + (*size); (*p)++)
	*(*p) = toupper ((unsigned char) *(*p));
}
void run_case_conv_loop_4(char * *p, char * *case_ctl_buffer, size_t *size)
{
      for ((*p) = (*case_ctl_buffer); (*p) < (*case_ctl_buffer) + (*size); (*p)++)
	*(*p) = tolower ((unsigned char) *(*p));
}
