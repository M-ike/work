#include "buffer_loop_6.h"
#ifndef READ_ERROR_MAX
#define READ_ERROR_MAX 10

#endif
#ifndef NMAGIC
#define NMAGIC (sizeof(magic)/sizeof(magic[0]))

#endif
#ifndef VOLUME_TEXT_LEN
#define VOLUME_TEXT_LEN (sizeof VOLUME_TEXT - 1)

#endif
#ifndef VOLUME_TEXT
#define VOLUME_TEXT " Volume "

#endif
#ifndef VOL_SUFFIX
#define VOL_SUFFIX "Volume"

#endif

void bufmap_locate_loop_1(struct bufmap * *map, size_t *off)
{
  for ((*map) = bufmap_head; (*map); (*map) = (*map)->next)
    {
      if (!(*map)->next
	  || (*off) < (*map)->next->start * BLOCKSIZE)
	break;
    }
}
void check_compressed_archive_loop_3(const struct zip_magic * *p, int *re_arg_pa1_3, enum compress_type *re_arg_pa2_3)
{
  for ((*p) = magic + 2; (*p) < magic + NMAGIC; (*p)++)
    if (memcmp (record_start->buffer, (*p)->magic, (*p)->length) == 0)
      { (*re_arg_pa1_3) = 0; (*re_arg_pa2_3) = (*p)->type; return; }
}
void drop_volume_label_suffix_loop_6(const char * *p, const char * *label, size_t *len)
{
  for ((*p) = (*label) + (*len) - 1; (*p) > (*label) && isdigit ((unsigned char) *(*p)); (*p)--)
    ;
}
void bufmap_reset_loop_2(struct bufmap * *map, ssize_t *fixup)
{
      for (; (*map); (*map) = (*map)->next)
	(*map)->start += (*fixup);
}
void change_tape_menu_loop_4(char * *name, char * *input_buffer)
{
            for ((*name) = (*input_buffer) + 1;
                 *(*name) == ' ' || *(*name) == '\t';
                 (*name)++)
              ;
}
void change_tape_menu_loop_5(char * *cursor, char * *name)
{
            for ((*cursor) = (*name); *(*cursor) && *(*cursor) != '\n'; (*cursor)++)
              ;
}
