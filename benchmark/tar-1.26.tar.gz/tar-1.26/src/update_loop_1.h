#ifndef update_loop_1_h_
#define update_loop_1_h_

#include <system.h>
#include <quotearg.h>
#include "common.h"

void update_archive_loop_1(char * *p, char * *dirp, namebuf_t *nbuf);

#endif
