#include "tar_loop_13.h"
#ifndef GLOBAL
#define GLOBAL

#endif
#ifndef FORMAT_MASK
#define FORMAT_MASK(n) (1<<(n))

#endif
#ifndef DEFAULT_ARCHIVE
# define DEFAULT_ARCHIVE "tar.out"

#endif
#ifndef DEFAULT_BLOCKING
# define DEFAULT_BLOCKING 20

#endif
#ifndef LOW_DENSITY_NUM
# define LOW_DENSITY_NUM 0

#endif
#ifndef MID_DENSITY_NUM
# define MID_DENSITY_NUM 8

#endif
#ifndef DEFAULT_ARCHIVE_FORMAT
# define DEFAULT_ARCHIVE_FORMAT GNU_FORMAT

#endif
#ifndef HIGH_DENSITY_NUM
# define HIGH_DENSITY_NUM 16

#endif
#ifndef TAR_SIZE_SUFFIXES
#define TAR_SIZE_SUFFIXES "bBcGgkKMmPTtw"

#endif
#ifndef MAKE_EXCL_OPTIONS
#define MAKE_EXCL_OPTIONS(args) \
 ((((args)->wildcards != disable_wildcards) ? EXCLUDE_WILDCARDS : 0) \
  | (args)->matching_flags \
  | recursion_option)

#endif
#ifndef MAKE_INCL_OPTIONS
#define MAKE_INCL_OPTIONS(args) \
 ((((args)->wildcards == enable_wildcards) ? EXCLUDE_WILDCARDS : 0) \
  | (args)->include_anchored \
  | (args)->matching_flags \
  | recursion_option)

#endif
#ifndef NS_PRECISION_FORMAT_MASK
#define NS_PRECISION_FORMAT_MASK FORMAT_MASK (POSIX_FORMAT)

#endif

void update_argv_loop_8(char * *p, char * *start, size_t *count)
{
    for ((*p) = (*start); *(*p); (*p) += strlen ((*p)) + 1)
      if ((*p)[0] == '-')
	(*count)++;
}
void expand_pax_option_loop_10(char * *p, size_t *len)
{
	  for (++(*p); *(*p) && isspace ((unsigned char) *(*p)); (*p)++)
	    (*len)--;
}
void update_argv_loop_7(size_t *size, char * *p, struct obstack *argv_stk)
{
	    for (; (*size) > 0; (*size)--, (*p)++)
	      if (*(*p))
		obstack_1grow (&(*argv_stk), *(*p));
	      else
		obstack_1grow (&(*argv_stk), '\n');
}
void archive_format_string_loop_2(const struct fmttab * *p, enum archive_format *fmt, int *re_arg_pa1_2, const char * *re_arg_pa2_2)
{
  for ((*p) = fmttab; (*p)->name; (*p)++)
    if ((*p)->fmt == (*fmt))
      { (*re_arg_pa1_2) = 0; (*re_arg_pa2_2) = (*p)->name; return; }
}
void parse_opt_loop_11(char * *arg)
{
      for (;*(*arg); (*arg)++)
	set_char_quoting (NULL, *(*arg), 0);
}
void add_file_id_loop_6(struct file_id_list * *p, struct stat *st, const char * *filename)
{
  for ((*p) = file_id_list; (*p); (*p) = (*p)->next)
    if ((*p)->ino == (*st).st_ino && (*p)->dev == (*st).st_dev)
      {
	FATAL_ERROR ((0, 0, _("%s: file list already read"),
		      quotearg_colon ((*filename))));
      }
}
void add_exclude_array_loop_5(int *i, const char *const * *fv)
{
  for ((*i) = 0; (*fv)[(*i)]; (*i)++)
    add_exclude (excluded, (*fv)[(*i)], 0);
}
void update_argv_loop_9(size_t *i, struct argp_state * *state, char * *p, char * *start, int *term)
{
  for ((*i) = (*state)->next, (*p) = (*start); *(*p); (*p) += strlen ((*p)) + 1, (*i)++)
    {
      if ((*term) == 0 && (*p)[0] == '-')
	(*state)->argv[(*i)++] = "--add-file";
      (*state)->argv[(*i)] = (*p);
    }
}
void tar_set_quoting_style_loop_4(int *i, char * *arg, int *re_arg_pa1_4)
{
  for ((*i) = 0; quoting_style_args[(*i)]; (*i)++)
    if (strcmp ((*arg), quoting_style_args[(*i)]) == 0)
      {
	set_quoting_style (NULL, (*i));
	{ (*re_arg_pa1_4) = 0; return; }
      }
}
void tar_list_quoting_styles_loop_3(int *i, struct obstack * *stk, size_t *prefixlen, const char * *prefix)
{
  for ((*i) = 0; quoting_style_args[(*i)]; (*i)++)
    {
      obstack_grow ((*stk), (*prefix), (*prefixlen));
      obstack_grow ((*stk), quoting_style_args[(*i)],
		    strlen (quoting_style_args[(*i)]));
      obstack_1grow ((*stk), '\n');
    }
}
void find_argp_option_loop_13(struct argp_option * *o, int *letter, int *re_arg_pa1_13, struct argp_option * *re_arg_pa2_13)
{
  for (;
       !((*o)->name == NULL
	 && (*o)->key == 0
	 && (*o)->arg == 0
	 && (*o)->flags == 0
	 && (*o)->doc == NULL); (*o)++)
    if ((*o)->key == (*letter))
      { (*re_arg_pa1_13) = 0; (*re_arg_pa2_13) = (*o); return; }
}
void set_archive_format_loop_1(const struct fmttab * *p, const char * *name)
{
  for ((*p) = fmttab; strcmp ((*p)->name, (*name)) != 0; )
    if (! (++(*p))->name)
      USAGE_ERROR ((0, 0, _("%s: Invalid archive format"),quotearg_colon ((*name))));
}
void parse_opt_loop_12(char * *arg)
{
      for (;*(*arg); (*arg)++)
	set_char_quoting (NULL, *(*arg), 1);
}
