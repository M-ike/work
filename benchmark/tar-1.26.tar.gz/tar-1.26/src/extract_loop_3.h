#ifndef extract_loop_3_h_
#define extract_loop_3_h_

#include <system.h>
#include <quotearg.h>
#include <errno.h>
#include <priv-set.h>
#include <utimens.h>
#include "common.h"

static bool we_are_root;	/* true if our effective uid == 0 */
static mode_t newdir_umask;	/* umask when creating new directories */
static mode_t current_umask;	/* current umask (which is set to 0 if -p) */
struct delayed_set_stat
  {
    /* Next directory in list.  */
    struct delayed_set_stat *next;

    /* Metadata for this directory.  */
    dev_t dev;
    ino_t ino;
    mode_t mode; /* The desired mode is MODE & ~ current_umask.  */
    uid_t uid;
    gid_t gid;
    struct timespec atime;
    struct timespec mtime;

    /* An estimate of the directory's current mode, along with a mask
       specifying which bits of this estimate are known to be correct.
       If CURRENT_MODE_MASK is zero, CURRENT_MODE's value doesn't
       matter.  */
    mode_t current_mode;
    mode_t current_mode_mask;

    /* This directory is an intermediate directory that was created
       as an ancestor of some other directory; it was not mentioned
       in the archive, so do not set its uid, gid, atime, or mtime,
       and don't alter its mode outside of MODE_RWX.  */
    bool interdir;

    /* Whether symbolic links should be followed when accessing the
       directory.  */
    int atflag;

    /* Do not set the status of this directory until after delayed
       links are created.  */
    bool after_links;

    /* Directory that the name is relative to.  */
    int change_dir;

    /* Length and contents of name.  */
    size_t file_name_len;
    char file_name[1];
  };
static struct delayed_set_stat *delayed_set_stat_head;
struct delayed_link
  {
    /* The next delayed link in the list.  */
    struct delayed_link *next;

    /* The device, inode number and ctime of the placeholder.  Use
       ctime, not mtime, to make false matches less likely if some
       other process removes the placeholder.  */
    dev_t dev;
    ino_t ino;
    struct timespec ctime;

    /* True if the link is symbolic.  */
    bool is_symlink;

    /* The desired metadata, valid only the link is symbolic.  */
    mode_t mode;
    uid_t uid;
    gid_t gid;
    struct timespec atime;
    struct timespec mtime;

    /* The directory that the sources and target are relative to.  */
    int change_dir;

    /* A list of sources for this link.  The sources are all to be
       hard-linked together.  */
    struct string_list *sources;

    /* The desired target of the desired link.  */
    char target[1];
  };
static struct delayed_link *delayed_link_head;
struct string_list
  {
    struct string_list *next;
    char string[1];
  };
typedef int (*tar_extractor_t) (char *file_name, int typeflag);
void extract_file_loop_2(off_t *size, struct tar_stat_info *current_stat_info, union block * *data_block, size_t *written, size_t *count, int *fd, char * *file_name);
void repair_delayed_set_stat_loop_1(struct delayed_set_stat * *data, const struct stat * *dir_stat_info, struct tar_stat_info *current_stat_info, int *re_arg_pa1_1);
void extract_link_loop_3(struct delayed_link * *ds, struct stat *st1, char * *file_name);

#endif
