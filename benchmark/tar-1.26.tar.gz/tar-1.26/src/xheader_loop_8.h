#ifndef xheader_loop_8_h_
#define xheader_loop_8_h_

#include <system.h>
#include <fnmatch.h>
#include <hash.h>
#include <inttostr.h>
#include <quotearg.h>
#include "common.h"

struct keyword_list
{
  struct keyword_list *next;
  char *pattern;
  char *value;
};
static struct keyword_list *keyword_pattern_list;
static struct keyword_list *keyword_global_override_list;
static struct keyword_list *keyword_override_list;
struct xhdr_tab
{
  char const *keyword;
  void (*coder) (struct tar_stat_info const *, char const *,
		 struct xheader *, void const *data);
  void (*decoder) (struct tar_stat_info *, char const *, char const *, size_t);
  int flags;
};
extern struct xhdr_tab const xhdr_tab[];
enum decode_time_status
  {
    decode_time_success,
    decode_time_range,
    decode_time_bad_header
  };
void xheader_protected_pattern_p_loop_6(const struct xhdr_tab * *p, const char * *pattern, int *re_arg_pa1_6, _Bool *re_arg_pa2_6);
void xheader_set_keyword_equal_loop_3(char * *p, char * *eq);
void xheader_format_name_loop_4(char * *q, char * *buf, const char * *p, const char * *fmt, char * *dir, char * *base, const char * *pptr, const char * *nptr);
void decode_record_loop_8(char * *p, char * *len_lim);
void xheader_keyword_override_p_loop_2(struct keyword_list * *kp, const char * *keyword, int *re_arg_pa1_2, _Bool *re_arg_pa2_2);
void xheader_keyword_deleted_p_loop_1(struct keyword_list * *kp, const char * *kw, int *re_arg_pa1_1, _Bool *re_arg_pa2_1);
void xheader_protected_keyword_p_loop_7(const struct xhdr_tab * *p, const char * *keyword, int *re_arg_pa1_7, _Bool *re_arg_pa2_7);
void locate_handler_loop_5(const struct xhdr_tab * *p, const char * *keyword, int *re_arg_pa1_5, const struct xhdr_tab * *re_arg_pa2_5);

#endif
