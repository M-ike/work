#include "create_loop_7.h"
#ifndef FILL
#define FILL(field,byte) do {            \
  memset(field, byte, sizeof(field)-1);  \
  (field)[sizeof(field)-1] = 0;          \
} while (0)

#endif
#ifndef MAJOR_TO_CHARS
#define MAJOR_TO_CHARS(val, where) major_to_chars (val, where, sizeof (where))

#endif
#ifndef MINOR_TO_CHARS
#define MINOR_TO_CHARS(val, where) minor_to_chars (val, where, sizeof (where))

#endif
#ifndef GID_TO_CHARS
#define GID_TO_CHARS(val, where) gid_to_chars (val, where, sizeof (where))

#endif
#ifndef MAX_OCTAL_VAL
#define MAX_OCTAL_VAL(buffer) MAX_VAL_WITH_DIGITS (sizeof (buffer) - 1, LG_8)

#endif
#ifndef CACHEDIR_SIGNATURE_SIZE
#define CACHEDIR_SIGNATURE_SIZE (sizeof CACHEDIR_SIGNATURE - 1)

#endif
#ifndef MAX_VAL_WITH_DIGITS
#define MAX_VAL_WITH_DIGITS(digits, bits_per_digit) \
   ((digits) * (bits_per_digit) < sizeof (uintmax_t) * CHAR_BIT \
    ? ((uintmax_t) 1 << ((digits) * (bits_per_digit))) - 1 \
    : (uintmax_t) -1)

#endif
#ifndef UNAME_TO_CHARS
#define UNAME_TO_CHARS(name,buf) string_to_chars (name, buf, sizeof(buf))

#endif
#ifndef GNAME_TO_CHARS
#define GNAME_TO_CHARS(name,buf) string_to_chars (name, buf, sizeof(buf))

#endif
#ifndef MODE_TO_CHARS
#define MODE_TO_CHARS(val, where) mode_to_chars (val, where, sizeof (where))

#endif
#ifndef UID_TO_CHARS
#define UID_TO_CHARS(val, where) uid_to_chars (val, where, sizeof (where))

#endif
#ifndef CACHEDIR_SIGNATURE
#define CACHEDIR_SIGNATURE "Signature: 8a477f597d28d172789f06886806bc55"

#endif

void check_links_loop_7(struct link * *lp)
{
  for ((*lp) = hash_get_first (link_table); (*lp);
       (*lp) = hash_get_next (link_table, (*lp)))
    {
      if ((*lp)->nlink)
	{
	  WARN ((0, 0, _("Missing links to %s."), quote ((*lp)->name)));
	}
    }
}
void check_exclusion_tags_loop_1(struct exclusion_tag * *tag, const struct tar_stat_info * *st, const char ** *tag_file_name, int *re_arg_pa1_1, enum exclusion_tag_type *re_arg_pa2_1)
{
  for ((*tag) = exclusion_tags; (*tag); (*tag) = (*tag)->next)
    {
      int tagfd = subfile_open ((*st), (*tag)->name, open_read_flags);
      if (0 <= tagfd)
	{
	  bool satisfied = !(*tag)->predicate || (*tag)->predicate (tagfd);
	  close (tagfd);
	  if (satisfied)
	    {
	      if ((*tag_file_name))
		*(*tag_file_name) = (*tag)->name;
	      { (*re_arg_pa1_1) = 0; (*re_arg_pa2_1) = (*tag)->type; return; }
	    }
	}
    }
}
void split_long_name_loop_3(size_t *i, size_t *length, const char * *name)
{
  for ((*i) = (*length) - 1; (*i) > 0; (*i)--)
    if (ISSLASH ((*name)[(*i)]))
      break;
}
void simple_finish_header_loop_4(size_t *i, union block * *header, int *sum, char * *p)
{
  for ((*i) = sizeof *(*header); (*i)-- != 0; )
    /* We can't use unsigned char here because of old compilers, e.g. V7.  */
    (*sum) += 0xFF & *(*p)++;
}
void open_failure_recover_loop_6(struct tar_stat_info * *p, const struct tar_stat_info * *dir, int *re_arg_pa1_6, _Bool *re_arg_pa2_6)
{
      for ((*p) = (*dir)->parent->parent; (*p); (*p) = (*p)->parent)
	if (0 < (*p)->fd && (! (*p)->parent || (*p)->parent->fd <= 0))
	  {
	    tar_stat_close ((*p));
	    { (*re_arg_pa1_6) = 0; (*re_arg_pa2_6) = true; return; }
	  }
}
void tar_copy_str_loop_2(size_t *i, size_t *len, char * *dst, const char * *src)
{
  for ((*i) = 0; (*i) < (*len); (*i)++)
    if (! ((*dst)[(*i)] = (*src)[(*i)]))
      break;
}
void dump_dir0_loop_5(const char * *entry, const char * *directory, size_t *entry_len, size_t *name_size, size_t *name_len, char * *name_buf, struct tar_stat_info * *st)
{
	    for ((*entry) = (*directory); ((*entry_len) = strlen ((*entry))) != 0;
		 (*entry) += (*entry_len) + 1)
	      {
		if ((*name_size) < (*name_len) + (*entry_len))
		  {
		    (*name_size) = (*name_len) + (*entry_len);
		    (*name_buf) = xrealloc ((*name_buf), (*name_size) + 1);
		  }
		strcpy ((*name_buf) + (*name_len), (*entry));
		if (!excluded_name ((*name_buf)))
		  dump_file ((*st), (*entry), (*name_buf));
	      }
}
