#ifndef incremen_loop_11_h_
#define incremen_loop_11_h_

#include <system.h>
#include <hash.h>
#include <quotearg.h>
#include "common.h"

enum children
  {
    NO_CHILDREN,
    CHANGED_CHILDREN,
    ALL_CHILDREN
  };
struct dumpdir                 /* Dump directory listing */
{
  char *contents;              /* Actual contents */
  size_t total;                /* Total number of elements */
  size_t elc;                  /* Number of D/N/Y elements. */
  char **elv;                  /* Array of D/N/Y elements */
};
struct directory
  {
    struct directory *next;
    struct timespec mtime;      /* Modification time */
    dev_t device_number;	/* device number for directory */
    ino_t inode_number;		/* inode number for directory */
    struct dumpdir *dump;       /* Directory contents */
    struct dumpdir *idump;      /* Initial contents if the directory was
				   rescanned */
    enum children children;     /* What to save under this directory */
    unsigned flags;             /* See DIRF_ macros above */
    struct directory *orig;     /* If the directory was renamed, points to
				   the original directory structure */
    const char *tagfile;        /* Tag file, if the directory falls under
				   exclusion_tag_under */
    char *caname;               /* canonical name */
    char *name;	     	        /* file name of directory */
  };
struct dumpdir_iter
{
  struct dumpdir *dump; /* Dumpdir being iterated */
  int all;              /* Iterate over all entries, not only D/N/Y */
  size_t next;          /* Index of the next element */
};
static struct directory *dirhead, *dirtail;
void read_unsigned_num_loop_9(size_t *i, int *c, char buf[], FILE * *fp);
void store_rename_loop_6(struct directory * *prev, struct directory * *dir);
void makedumpdir_loop_5(size_t *i, const char * *p, const char * *dir, const char ** *array);
void get_gnu_dumpdir_loop_10(size_t *size, size_t *copied, union block * *data_block, char * *to);
void makedumpdir_loop_4(const char * *p, const char * *dir, size_t *dirsize, size_t *len);
void dirlist_replace_prefix_loop_3(struct directory * *dp, const char * *pref, size_t *pref_len, const char * *repl, size_t *repl_len);
void dumpdir_ok_loop_11(char * *p, char * *dumpdir, int *expect, int *has_tempdir, int *re_arg_pa1_11, _Bool *re_arg_pa2_11);
void read_negative_num_loop_8(size_t *i, int *c, FILE * *fp, char buf[]);
void dumpdir_create0_loop_1(size_t *i, size_t *total, size_t *ctsize, const char * *q, const char * *contents, size_t *len, const char * *cmask);
void dumpdir_create0_loop_2(size_t *i, char * *p, struct dumpdir * *dump, const char * *cmask);
void read_obstack_loop_7(size_t *i, int *c, FILE * *fp, struct obstack * *stk);

#endif
