#ifndef utils_loop_2_h_
#define utils_loop_2_h_

/*  Functions from hack's utils library.
    Copyright (C) 1989, 1990, 1991, 1998, 1999, 2003, 2008, 2009
    Free Software Foundation, Inc.

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA. */
#include "config.h"
#include <stdio.h>
#include <stdarg.h>
#include <errno.h>

struct open_file
  {
    FILE *fp;
    char *name;
    struct open_file *link;
    unsigned temp : 1;
  };
static struct open_file *open_files = NULL;
struct buffer
  {
    size_t allocated;
    size_t length;
    char *b;
  };
#ifndef MIN_ALLOCATE
#define MIN_ALLOCATE 50

#endif

void register_open_file_loop_2(struct open_file * *p, FILE * *fp);
void utils_fp_name_loop_1(struct open_file * *p, FILE * *fp, int *re_arg_pa1_1, const char * *re_arg_pa2_1);

#endif
