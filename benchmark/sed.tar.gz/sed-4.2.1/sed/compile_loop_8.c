#include "compile_loop_8.h"
#ifndef YMAP_LENGTH
#define YMAP_LENGTH		256 
#endif

#ifndef VECTOR_ALLOC_INCREMENT
#define VECTOR_ALLOC_INCREMENT	40

#endif

#ifndef OPEN_BRACKET
#define OPEN_BRACKET	'['

#endif

#ifndef CLOSE_BRACKET
#define CLOSE_BRACKET	']'

#endif

#ifndef OPEN_BRACE
#define OPEN_BRACE	'{'

#endif

#ifndef CLOSE_BRACE
#define CLOSE_BRACE	'}'

#endif

#ifndef BAD_BANG
#define BAD_BANG (errors)

#endif

#ifndef BAD_COMMA
#define BAD_COMMA (BAD_BANG + sizeof(N_("multiple `!'s")))

#endif

#ifndef BAD_STEP
#define BAD_STEP (BAD_COMMA + sizeof(N_("unexpected `,'")))

#endif

#ifndef EXCESS_OPEN_BRACE
#define EXCESS_OPEN_BRACE (BAD_STEP + sizeof(N_("invalid usage of +N or ~N as first address")))

#endif

#ifndef EXCESS_CLOSE_BRACE
#define EXCESS_CLOSE_BRACE (EXCESS_OPEN_BRACE + sizeof(N_("unmatched `{'")))

#endif

#ifndef EXCESS_JUNK
#define EXCESS_JUNK (EXCESS_CLOSE_BRACE + sizeof(N_("unexpected `}'")))

#endif

#ifndef EXPECTED_SLASH
#define EXPECTED_SLASH (EXCESS_JUNK + sizeof(N_("extra characters after command")))

#endif

#ifndef NO_CLOSE_BRACE_ADDR
#define NO_CLOSE_BRACE_ADDR (EXPECTED_SLASH + sizeof(N_("expected \\ after `a', `c' or `i'")))

#endif

#ifndef NO_COLON_ADDR
#define NO_COLON_ADDR (NO_CLOSE_BRACE_ADDR + sizeof(N_("`}' doesn't want any addresses")))

#endif

#ifndef NO_SHARP_ADDR
#define NO_SHARP_ADDR (NO_COLON_ADDR + sizeof(N_(": doesn't want any addresses")))

#endif

#ifndef NO_COMMAND
#define NO_COMMAND (NO_SHARP_ADDR + sizeof(N_("comments don't accept any addresses")))

#endif

#ifndef ONE_ADDR
#define ONE_ADDR (NO_COMMAND + sizeof(N_("missing command")))

#endif

#ifndef UNTERM_ADDR_RE
#define UNTERM_ADDR_RE (ONE_ADDR + sizeof(N_("command only uses one address")))

#endif

#ifndef UNTERM_S_CMD
#define UNTERM_S_CMD (UNTERM_ADDR_RE + sizeof(N_("unterminated address regex")))

#endif

#ifndef UNTERM_Y_CMD
#define UNTERM_Y_CMD (UNTERM_S_CMD + sizeof(N_("unterminated `s' command")))

#endif

#ifndef UNKNOWN_S_OPT
#define UNKNOWN_S_OPT (UNTERM_Y_CMD + sizeof(N_("unterminated `y' command")))

#endif

#ifndef EXCESS_P_OPT
#define EXCESS_P_OPT (UNKNOWN_S_OPT + sizeof(N_("unknown option to `s'")))

#endif

#ifndef EXCESS_G_OPT
#define EXCESS_G_OPT (EXCESS_P_OPT + sizeof(N_("multiple `p' options to `s' command")))

#endif

#ifndef EXCESS_N_OPT
#define EXCESS_N_OPT (EXCESS_G_OPT + sizeof(N_("multiple `g' options to `s' command")))

#endif

#ifndef ZERO_N_OPT
#define ZERO_N_OPT (EXCESS_N_OPT + sizeof(N_("multiple number options to `s' command")))

#endif

#ifndef Y_CMD_LEN
#define Y_CMD_LEN (ZERO_N_OPT + sizeof(N_("number option to `s' command may not be zero")))

#endif

#ifndef BAD_DELIM
#define BAD_DELIM (Y_CMD_LEN + sizeof(N_("strings for `y' command are different lengths")))

#endif

#ifndef ANCIENT_VERSION
#define ANCIENT_VERSION (BAD_DELIM + sizeof(N_("delimiter character is not a single-byte character")))

#endif

#ifndef INVALID_LINE_0
#define INVALID_LINE_0 (ANCIENT_VERSION + sizeof(N_("expected newer version of sed")))

#endif

#ifndef UNKNOWN_CMD
#define UNKNOWN_CMD (INVALID_LINE_0 + sizeof(N_("invalid usage of line address 0")))

#endif

#ifndef END_ERRORS
#define END_ERRORS (UNKNOWN_CMD + sizeof(N_("unknown command: `%c'")))

#endif

void convert_number_loop_1(char * *p, char * *buf, const char * *bufend, int *maxdigits, int *base, int *n)
{
for ((*p)=(*buf); (*p) < (*bufend) && (*maxdigits)-- > 0; ++(*p))
    {
      int d = -1;
      switch (*(*p))
	{
	case '0': d = 0x0; break;
	case '1': d = 0x1; break;
	case '2': d = 0x2; break;
	case '3': d = 0x3; break;
	case '4': d = 0x4; break;
	case '5': d = 0x5; break;
	case '6': d = 0x6; break;
	case '7': d = 0x7; break;
	case '8': d = 0x8; break;
	case '9': d = 0x9; break;
	case 'A': case 'a': d = 0xa; break;
	case 'B': case 'b': d = 0xb; break;
	case 'C': case 'c': d = 0xc; break;
	case 'D': case 'd': d = 0xd; break;
	case 'E': case 'e': d = 0xe; break;
	case 'F': case 'f': d = 0xf; break;
	}
      if (d < 0 || (*base) <= d)
	break;
      (*n) = (*n) * (*base) + d;
    }

}
void get_openfile_loop_2(struct output * *p, struct output ** *file_ptrs, char * *file_name)
{
for ((*p)=*(*file_ptrs); (*p); (*p)=(*p)->link)
    if (strcmp((*p)->name, (*file_name)) == 0)
      break;

}
void get_openfile_loop_3(struct special_files * *special, char * *file_name, struct buffer * *b, int *re_arg_pa1_3, struct output * *re_arg_pa2_3)
{
for ((*special) = special_files; (*special)->outf.name; (*special)++)
        if (strcmp((*special)->outf.name, (*file_name)) == 0)
          {
	    (*special)->outf.fp = *(*special)->pfp;
	    free_buffer ((*b));
	    { (*re_arg_pa1_3) = 0; (*re_arg_pa2_3) = &(*special)->outf; return; }
          }

}
void check_final_program_loop_4(struct output * *p)
{
for ((*p)=file_read; (*p); (*p)=(*p)->link)
      if ((*p)->name)
	{
	  FREE((*p)->name);
	  (*p)->name = NULL;
	}

}
void check_final_program_loop_5(struct output * *p)
{
for ((*p)=file_write; (*p); (*p)=(*p)->link)
      if ((*p)->name)
	{
	  FREE((*p)->name);
	  (*p)->name = NULL;
	}

}
void rewind_read_files_loop_6(struct output * *p)
{
for ((*p)=file_read; (*p); (*p)=(*p)->link)
    if ((*p)->fp)
      rewind((*p)->fp);

}
void finish_program_loop_7(struct output * *p, struct output * *q)
{
for ((*p)=file_read; (*p); (*p)=(*q))
      {
	if ((*p)->fp)
	  ck_fclose((*p)->fp);
	(*q) = (*p)->link;
#if 0
	/* We use obstacks. */
	FREE((*p));
#endif
      }

}
void finish_program_loop_8(struct output * *p, struct output * *q)
{
for ((*p)=file_write; (*p); (*p)=(*q))
      {
	if ((*p)->fp)
	  ck_fclose((*p)->fp);
	(*q) = (*p)->link;
#if 0
	/* We use obstacks. */
	FREE((*p));
#endif
      }

}
