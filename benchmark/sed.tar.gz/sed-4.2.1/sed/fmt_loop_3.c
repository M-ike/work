#include "fmt_loop_3.h"
#ifndef LEEWAY
#define	LEEWAY	7

#endif

#ifndef MAXCOST
#define	MAXCOST	(~(((unsigned long) 1) << (8 * sizeof (COST) -1)))

#endif

#ifndef SQR
#define	SQR(n)		((n) * (n))

#endif

#ifndef EQUIV
#define	EQUIV(n)	SQR ((COST) (n))

#endif

#ifndef SHORT_COST
#define	SHORT_COST(n)	EQUIV ((n) * 10)

#endif

#ifndef RAGGED_COST
#define	RAGGED_COST(n)	(SHORT_COST (n) / 2)

#endif

#ifndef LINE_COST
#define	LINE_COST	EQUIV (70)

#endif

#ifndef WIDOW_COST
#define	WIDOW_COST(n)	(EQUIV (200) / ((n) + 2))

#endif

#ifndef ORPHAN_COST
#define	ORPHAN_COST(n)	(EQUIV (150) / ((n) + 2))

#endif

#ifndef SENTENCE_BONUS
#define	SENTENCE_BONUS	EQUIV (50)

#endif

#ifndef NOBREAK_COST
#define	NOBREAK_COST	EQUIV (600)

#endif

#ifndef PAREN_BONUS
#define	PAREN_BONUS	EQUIV (40)

#endif

#ifndef PUNCT_BONUS
#define	PUNCT_BONUS	EQUIV(40)

#endif

#ifndef LINE_CREDIT
#define	LINE_CREDIT	EQUIV(3)

#endif

#ifndef MAXWORDS
#define	MAXWORDS	1000

#endif

#ifndef GETC
#define GETC()          (parabuf == end_of_parabuf ? EOF : *parabuf++)

#endif

#ifndef isopen
#define	isopen(c)	(strchr ("([`'\"", (c)) != NULL)

#endif

#ifndef isclose
#define	isclose(c)	(strchr (")]'\"", (c)) != NULL)

#endif

#ifndef isperiod
#define	isperiod(c)	(strchr (".?!", (c)) != NULL)

#endif

#ifndef TABWIDTH
#define	TABWIDTH	8

#endif

void get_space_loop_1(int *register_c, int *re_arg_pa1_1, int *re_arg_pa2_1)
{
for (;;)
    {
      if ((*register_c) == ' ')
	in_column++;
      else if ((*register_c) == '\t')
	in_column = (in_column / TABWIDTH + 1) * TABWIDTH;
      else
	{ (*re_arg_pa1_1) = 0; (*re_arg_pa2_1) = (*register_c); return; }
      (*register_c) = GETC();
    }

}
void flush_paragraph_loop_2(WORD * *register_w, COST *best_break, WORD * *split_point)
{
for ((*register_w) = words->next_break; (*register_w) != word_limit; (*register_w) = (*register_w)->next_break)
    {
      if ((*register_w)->best_cost - (*register_w)->next_break->best_cost < (*best_break))
	{
	  (*split_point) = (*register_w);
	  (*best_break) = (*register_w)->best_cost - (*register_w)->next_break->best_cost;
	}
      if ((*best_break) <= MAXCOST - LINE_CREDIT)
	(*best_break) += LINE_CREDIT;
    }

}
void put_word_loop_3(int *register_n, WORD * *register_w, const char * *register_s)
{
for ((*register_n) = (*register_w)->length; (*register_n) != 0; (*register_n)--)
    putc (*(*register_s)++, outfile);

}
