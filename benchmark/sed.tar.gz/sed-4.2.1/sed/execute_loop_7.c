#include "execute_loop_7.h"
#ifndef INITIAL_BUFFER_SIZE
#define INITIAL_BUFFER_SIZE	50

#endif

#ifndef FREAD_BUFFER_SIZE
#define FREAD_BUFFER_SIZE	8192

#endif

#ifndef UNUSED
#  define UNUSED	__attribute__((unused))

#endif

#ifndef SIZEOF_LINE
#define SIZEOF_LINE	offsetof (struct line, mbstate)

#endif

void release_append_queue_loop_1(struct append_queue * *p, struct append_queue * *q)
{
for ((*p)=append_head; (*p); (*p)=(*q))
    {
      if ((*p)->free)
        FREE((*p)->text);

      (*q) = (*p)->next;
      FREE((*p));
    }

}
void dump_append_queue_loop_2(struct append_queue * *p, struct output *output_file)
{
for ((*p)=append_head; (*p); (*p)=(*p)->next)
    {
      if ((*p)->text)
        ck_fwrite((*p)->text, 1, (*p)->textlen, (*output_file).fp);

      if ((*p)->fname)
	{
	  char buf[FREAD_BUFFER_SIZE];
	  size_t cnt;
	  FILE *fp;

	  /* "If _fname_ does not exist or cannot be read, it shall
	     be treated as if it were an empty file, causing no error
	     condition."  IEEE Std 1003.2-1992
	     So, don't fail. */
	  fp = ck_fopen((*p)->fname, read_mode, false);
	  if (fp)
	    {
	      while ((cnt = ck_fread(buf, 1, sizeof buf, fp)) > 0)
		ck_fwrite(buf, 1, cnt, (*output_file).fp);
	      ck_fclose(fp);
	    }
	}
    }

}
void get_backup_file_name_loop_3(char * *asterisk, char * *old_asterisk, int *backup_length, int *name_length)
{
for ((*asterisk) = in_place_extension - 1, (*old_asterisk) = (*asterisk) + 1;
       ((*asterisk) = strchr((*old_asterisk), '*'));
       (*old_asterisk) = (*asterisk) + 1)
    (*backup_length) += (*name_length) - 1;

}
void get_backup_file_name_loop_4(char * *asterisk, char * *old_asterisk, char * *p, const char * *name, int *name_length)
{
for ((*asterisk) = in_place_extension - 1, (*old_asterisk) = (*asterisk) + 1;
       ((*asterisk) = strchr((*old_asterisk), '*'));
       (*old_asterisk) = (*asterisk) + 1)
    {
      MEMCPY ((*p), (*old_asterisk), (*asterisk) - (*old_asterisk));
      (*p) += (*asterisk) - (*old_asterisk);
      strcpy ((*p), (*name));
      (*p) += (*name_length);
    }

}
void reset_addresses_loop_5(struct sed_cmd * *cur_cmd, struct vector * *vec, int *n)
{
for ((*cur_cmd) = (*vec)->v, (*n) = (*vec)->v_length; (*n)--; (*cur_cmd)++)
    if ((*cur_cmd)->a1
	&& (*cur_cmd)->a1->addr_type == ADDR_IS_NUM
	&& (*cur_cmd)->a1->addr_number == 0)
      (*cur_cmd)->range_state = RANGE_ACTIVE;
    else
      (*cur_cmd)->range_state = RANGE_INACTIVE;

}
void do_list_loop_6(countT *len, unsigned char * *p, char * *o, char obuf[], size_t *olen, countT *width, int *line_len, FILE * *fp)
{
for (; (*len)--; ++(*p)) {
      (*o) = obuf;
      
      /* Some locales define 8-bit characters as printable.  This makes the
	 testsuite fail at 8to7.sed because the `l' command in fact will not
	 convert the 8-bit characters. */
#if defined isascii || defined HAVE_ISASCII
      if (isascii(*(*p)) && ISPRINT(*(*p))) {
#else
      if (ISPRINT(*(*p))) {
#endif
	  *(*o)++ = *(*p);
	  if (*(*p) == '\\')
	    *(*o)++ = '\\';
      } else {
	  *(*o)++ = '\\';
	  switch (*(*p)) {
#if defined __STDC__ && __STDC__-0
	    case '\a': *(*o)++ = 'a'; break;
#else /* Not STDC; we'll just assume ASCII */
	    case 007:  *(*o)++ = 'a'; break;
#endif
	    case '\b': *(*o)++ = 'b'; break;
	    case '\f': *(*o)++ = 'f'; break;
	    case '\n': *(*o)++ = 'n'; break;
	    case '\r': *(*o)++ = 'r'; break;
	    case '\t': *(*o)++ = 't'; break;
	    case '\v': *(*o)++ = 'v'; break;
	    default:
	      sprintf((*o), "%03o", *(*p));
	      (*o) += strlen((*o));
	      break;
	    }
      }
      (*olen) = (*o) - obuf;
      if ((*width)+(*olen) >= (*line_len) && (*line_len) > 0) {
	  ck_fwrite("\\\n", 1, 2, (*fp));
	  (*width) = 0;
      }
      ck_fwrite(obuf, 1, (*olen), (*fp));
      (*width) += (*olen);
  }

}
void execute_program_loop_7(unsigned char * *e, unsigned char * *p, struct line *line, struct sed_cmd * *cur_cmd)
{
for ((*e)=(*p)+(*line).length; (*p)<(*e); ++(*p))
                     *(*p) = (*cur_cmd)->x.translate[*(*p)];

}
