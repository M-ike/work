#ifndef execute_loop_7_h_
#define execute_loop_7_h_

/*  GNU SED, a batch stream editor.
    Copyright (C) 1989,90,91,92,93,94,95,98,99,2002,2003,2004,2005,2006,2008,2009
    Free Software Foundation, Inc.

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA. */
#undef EXPERIMENTAL_DASH_N_OPTIMIZATION	/*don't use -- is very buggy*/
#define INITIAL_BUFFER_SIZE	50
#define FREAD_BUFFER_SIZE	8192
#include "sed.h"
#include <stddef.h>
#include <stdio.h>
#include <ctype.h>
#include <errno.h>

#ifndef INITIAL_BUFFER_SIZE
#define INITIAL_BUFFER_SIZE	50

#endif

#ifndef FREAD_BUFFER_SIZE
#define FREAD_BUFFER_SIZE	8192

#endif

#ifndef UNUSED
#  define UNUSED	__attribute__((unused))

#endif



/* Sed operates a line at a time. */
struct line {
  char *text;		/* Pointer to line allocated by malloc. */
  char *active;		/* Pointer to non-consumed part of text. */
  size_t length;	/* Length of text (or active, if used). */
  size_t alloc;		/* Allocated space for active. */
  bool chomped;		/* Was a trailing newline dropped? */
#i
#ifndef SIZEOF_LINE
#define SIZEOF_LINE	offsetof (struct line, mbstate)

#endif

#endif

/* A queue of text to write out at the end of a cycle
   (filled by the "a", "r" and "R" commands.) */
struct append_queue {
  const char *fname;
  
  bool free;
};

/* State information for the input stream. */
struct input {
  /* The list of yet-to-be-opened files.  It is invalid for file_list
     to be NULL.  When *file_list is NULL we are currently processing
     the last file.  */

  char **file_list;

  /* Count of files we failed to open. */
  countT bad_count;	    

  /* Current input line number (over all files).  */
  countT line_number;	    

  /* True if we'll reset line numbers and addresses before
     starting to process the next (possibly the first) file.  */
  bool reset_at_next_file;

  /* Function to read one line.  If FP is NULL, read_fn better not
     be one which uses fp; in particular, read_always_fail() is
     recommended. */
  bool (*read_fn) P_((struct input *));	/* read one line */

  char *out_file_name;

  const char *in_file_name;

  /* Owner and mode to be set just before closing the file.  */
  struct stat st;

  
/* The buffered input look-ahead.  The only fie
void get_backup_file_name_loop_3(char * *asterisk, char * *old_asterisk, int *backup_length, int *name_length);
void reset_addresses_loop_5(struct sed_cmd * *cur_cmd, struct vector * *vec, int *n);
void get_backup_file_name_loop_4(char * *asterisk, char * *old_asterisk, char * *p, const char * *name, int *name_length);
void execute_program_loop_7(unsigned char * *e, unsigned char * *p, struct line *line, struct sed_cmd * *cur_cmd);
void release_append_queue_loop_1(struct append_queue * *p, struct append_queue * *q);
void do_list_loop_6(countT *len, unsigned char * *p, char * *o, char obuf[], size_t *olen, countT *width, int *line_len, FILE * *fp);
void dump_append_queue_loop_2(struct append_queue * *p, struct output *output_file);

#endif
