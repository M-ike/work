#include "utils_loop_2.h"
void utils_fp_name_loop_1(struct open_file * *p, FILE * *fp, int *re_arg_pa1_1, const char * *re_arg_pa2_1)
{
for ((*p)=open_files; (*p); (*p)=(*p)->link)
    if ((*p)->fp == (*fp))
      { (*re_arg_pa1_1) = 0; (*re_arg_pa2_1) = (*p)->name; return; }

}
void register_open_file_loop_2(struct open_file * *p, FILE * *fp)
{
for ((*p)=open_files; (*p); (*p)=(*p)->link)
    {
      if ((*fp) == (*p)->fp)
	{
	  FREE((*p)->name);
	  break;
	}
    }

}
#ifndef MIN_ALLOCATE
#define MIN_ALLOCATE 50

#endif

