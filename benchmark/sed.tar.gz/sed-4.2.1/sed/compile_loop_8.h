#ifndef compile_loop_8_h_
#define compile_loop_8_h_

/*  GNU SED, a batch stream editor.
    Copyright (C) 1989,90,91,92,93,94,95,98,99,2002,2003,2004,2005,2006,2008
    Free Software Foundation, Inc.

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA. */
/* compile.c: translate sed source into internal form */
#include "sed.h"
#include <stdio.h>
#include <ctype.h>
#ifdef HAVE_STRINGS_H
# include <strings.h>
# ifdef HAVE_MEMORY_H
#  include <memory.h>
# endif
#else
# include <string.h>
#endif /* HAVE_STRINGS_H */
#ifdef HAVE_STRINGS_H
# include <strings.h>
# ifdef HAVE_MEMORY_H
#  include <memory.h>
# endif
#else
# include <string.h>
#endif /* HAVE_STRINGS_H */
#ifdef HAVE_STDLIB_H
# include <stdlib.h>
#endif
#ifdef HAVE_STRINGS_H
# include <strings.h>
# ifdef HAVE_MEMORY_H
#  include <memory.h>
# endif
#else
# include <string.h>
#endif /* HAVE_STRINGS_H */
#ifdef HAVE_STDLIB_H
# include <stdlib.h>
#endif
#ifndef EXIT_FAILURE
# define EXIT_FAILURE 1
#endif
#ifdef HAVE_STRINGS_H
# include <strings.h>
# ifdef HAVE_MEMORY_H
#  include <memory.h>
# endif
#else
# include <string.h>
#endif /* HAVE_STRINGS_H */
#ifdef HAVE_STDLIB_H
# include <stdlib.h>
#endif
#ifndef EXIT_FAILURE
# define EXIT_FAILURE 1
#endif
#ifdef HAVE_SYS_TYPES_H
# include <sys/types.h>
#endif
#include <obstack.h>

#ifndef YMAP_LENGTH
#define YMAP_LENGTH		256 
#endif

#ifndef VECTOR_ALLOC_INCREMENT
#define VECTOR_ALLOC_INCREMENT	40

#endif

#ifndef OPEN_BRACKET
#define OPEN_BRACKET	'['

#endif

#ifndef OPEN_BRACE
#define OPEN_BRACE	'{'

#endif

#ifndef CLOSE_BRACE
#define CLOSE_BRACE	'}'

#endif

#define OPEN_BRACKET	'['
#define CLOSE_BRACKET	']'
#define OPEN_BRACE	'{'
#define CLOSE_BRACE	'}'

struct prog_info {
  /* When we're reading a script command from a string, `prog.base'
     points to the first character in the string, 'prog.cur' points
     to the current character in the string, and 'prog.end' points
     to the end of the string.  This allows us to compile script
     strings that contain nulls. */
  const unsigned char *base;
  const unsigned char *cur;
  const unsigned char *end;

     and `prog.cur' are NULL, we're in trouble! */
  FILE *file;
};

/* Information used to give out useful and informative error messages. */
struct error_info {
  /* This is the name of the current script file. */
  const char *name;

  
  countT string_expr_count;
};


/* Label structure used to resolve GOTO's, labels, and block beginnings. */
st
  char *name;			/* NUL-terminated name of the label */
  struct error_info err_info;	/* track where `{}' blocks start */
  struct sed_label *next;	/* linked list (stack) */
};
  struct output outf;
  FILE **pfp;
};

FILE *my_stdin, *my_stdout, *my_stderr;
st
static struct prog_info prog;
static struct error_info cur_input;
#ifndef BAD_BANG
#define BAD_BANG (errors)

#endif

#ifndef BAD_COMMA
#define BAD_COMMA (BAD_BANG + sizeof(N_("multiple `!'s")))

#endif

#ifndef BAD_STEP
#define BAD_STEP (BAD_COMMA + sizeof(N_("unexpected `,'")))

#endif

#ifndef EXCESS_OPEN_BRACE
#define EXCESS_OPEN_BRACE (BAD_STEP + sizeof(N_("invalid usage of +N or ~N as first address")))

#endif

#ifndef EXCESS_CLOSE_BRACE
#define EXCESS_CLOSE_BRACE (EXCESS_OPEN_BRACE + sizeof(N_("unmatched `{'")))

#endif

#ifndef EXCESS_JUNK
#define EXCESS_JUNK (EXCESS_CLOSE_BRACE + sizeof(N_("unexpected `}'")))

#endif

#ifndef EXPECTED_SLASH
#define EXPECTED_SLASH (EXCESS_JUNK + sizeof(N_("extra characters after command")))

#endif

#ifndef NO_CLOSE_BRACE_ADDR
#define NO_CLOSE_BRACE_ADDR (EXPECTED_SLASH + sizeof(N_("expected \\ after `a', `c' or `i'")))

#endif

#ifndef NO_COLON_ADDR
#define NO_COLON_ADDR (NO_CLOSE_BRACE_ADDR + sizeof(N_("`}' doesn't want any addresses")))

#endif

#ifndef NO_SHARP_ADDR
#define NO_SHARP_ADDR (NO_COLON_ADDR + sizeof(N_(": doesn't want any addresses")))

#endif

#ifndef NO_COMMAND
#define NO_COMMAND (NO_SHARP_ADDR + sizeof(N_("comments don't accept any addresses")))

#endif

#ifndef ONE_ADDR
#define ONE_ADDR (NO_COMMAND + sizeof(N_("missing command")))

#endif

#ifndef UNTERM_ADDR_RE
#define UNTERM_ADDR_RE (ONE_ADDR + sizeof(N_("command only uses one address")))

#endif

#ifndef UNTERM_S_CMD
#define UNTERM_S_CMD (UNTERM_ADDR_RE + sizeof(N_("unterminated address regex")))

#endif

#ifndef UNTERM_Y_CMD
#define UNTERM_Y_CMD (UNTERM_S_CMD + sizeof(N_("unterminated `s' command")))

#endif

#ifndef UNKNOWN_S_OPT
#define UNKNOWN_S_OPT (UNTERM_Y_CMD + sizeof(N_("unterminated `y' command")))

#endif

#ifndef EXCESS_P_OPT
#define EXCESS_P_OPT (UNKNOWN_S_OPT + sizeof(N_("unknown option to `s'")))

#endif

#ifndef EXCESS_G_OPT
#define EXCESS_G_OPT (EXCESS_P_OPT + sizeof(N_("multiple `p' options to `s' command")))

#endif

#ifndef EXCESS_N_OPT
#define EXCESS_N_OPT (EXCESS_G_OPT + sizeof(N_("multiple `g' options to `s' command")))

#endif

#ifndef ZERO_N_OPT
#define ZERO_N_OPT (EXCESS_N_OPT + sizeof(N_("multiple number options to `s' command")))

#endif

#ifndef Y_CMD_LEN
#define Y_CMD_LEN (ZERO_N_OPT + sizeof(N_("number option to `s' command may not be zero")))

#endif

#ifndef BAD_DELIM
#define BAD_DELIM (Y_CMD_LEN + sizeof(N_("strings for `y' command are different lengths")))

#endif

#ifndef ANCIENT_VERSION
#define ANCIENT_VERSION (BAD_DELIM + sizeof(N_("delimiter character is not a single-byte character")))

#endif

#ifndef INVALID_LINE_0
#define INVALID_LINE_0 (ANCIENT_VERSION + sizeof(N_("expected newer version of sed")))

#endif

#ifndef UNKNOWN_CMD
#define UNKNOWN_CMD (INVALID_LINE_0 + sizeof(N_("invalid usage of line address 0")))

#endif

#ifndef END_ERRORS
#define END_ERRORS (UNKNOWN_CMD + sizeof(N_("unknown command: `%c'")))

#endif

  "expected newer version of sed\0"
  "invalid usage of line address 0\0"
void finish_program_loop_7(struct output * *p, struct output * *q);
void check_final_program_loop_4(struct output * *p);
void finish_program_loop_8(struct output * *p, struct output * *q);
void rewind_read_files_loop_6(struct output * *p);
void get_openfile_loop_3(struct special_files * *special, char * *file_name, struct buffer * *b, int *re_arg_pa1_3, struct output * *re_arg_pa2_3);
void convert_number_loop_1(char * *p, char * *buf, const char * *bufend, int *maxdigits, int *base, int *n);
void get_openfile_loop_2(struct output * *p, struct output ** *file_ptrs, char * *file_name);
void check_final_program_loop_5(struct output * *p);

#endif
