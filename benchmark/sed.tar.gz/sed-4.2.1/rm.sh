#!/bin/sh

rm ./sed/*

cp ./sed_backup/* ./sed/
