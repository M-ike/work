#!/bin/sh

BIN=/home/zql/desktop/LoopExtractor00/driver
SRC=.

file_list=""

for file in `find $SRC -name "*.c"`
do
    file_list=$file_list$file" "
done

echo $file_list
$BIN -include/home/zql/desktop/sed-4.2.1/config.h -I/home/zql/desktop/sed-4.2.1/testsuite/ -I/home/zql/desktop/sed-4.2.1/build-aux/ -I/home/zql/desktop/sed-4.2.1/ -I/home/zql/desktop/sed-4.2.1/lib/ -I/home/zql/desktop/sed-4.2.1/sed/  -I/usr/include -I/usr/lib/gcc/x86_64-linux-gnu/4.6/include $file_list
