#ifndef system_loop_2_h_
#define system_loop_2_h_

/* System-dependent calls for tar.

   Copyright (C) 2003, 2004, 2005, 2006, 2007,
   2008, 2010 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the
   Free Software Foundation; either version 3, or (at your option) any later
   version.

   This program is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
   Public License for more details.

   You should have received a copy of the GNU General Public License along
   with this program; if not, write to the Free Software Foundation, Inc.,
   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.  */
#include <system.h>
#include "common.h"
#include <priv-set.h>
#include <rmt.h>
#include <signal.h>

extern union block *record_start;
#ifndef PREAD
#define	PREAD 0			
#endif

#ifndef PWRITE
#define	PWRITE 1		
#endif

void run_decompress_program_loop_2(const char * *p, int *i, const char * *prog);
void sys_child_open_for_compress_loop_1(size_t *length, char * *cursor, size_t *status);

#endif
