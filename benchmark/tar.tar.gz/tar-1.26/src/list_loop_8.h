#ifndef list_loop_8_h_
#define list_loop_8_h_

/* List a tar archive, with support routines for reading a tar archive.

   Copyright (C) 1988, 1992, 1993, 1994, 1996, 1997, 1998, 1999, 2000,
   2001, 2003, 2004, 2005, 2006, 2007, 2010 Free Software Foundation, Inc.

   Written by John Gilmore, on 1985-08-26.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the
   Free Software Foundation; either version 3, or (at your option) any later
   version.

   This program is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
   Public License for more details.

   You should have received a copy of the GNU General Public License along
   with this program; if not, write to the Free Software Foundation, Inc.,
   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.  */
#include <system.h>
#include <inttostr.h>
#include <quotearg.h>
#include "common.h"
#define max(a, b) ((a) < (b) ? (b) : (a))

#ifndef max
#define max(a, b) ((a) < (b) ? (b) : (a))

#endif

#ifndef GID_FROM_HEADER
#define GID_FROM_HEADER(where) gid_from_header (where, sizeof (where))

#endif

#ifndef MINOR_FROM_HEADER
#define MINOR_FROM_HEADER(where) minor_from_header (where, sizeof (where))

#endif

#ifndef MODE_FROM_HEADER
#define MODE_FROM_HEADER(where, hbits) \
  mode_from_header (where, sizeof (where), hbits)

#endif

#ifndef TIME_FROM_HEADER
#define TIME_FROM_HEADER(where) time_from_header (where, sizeof (where))

#endif

#ifndef UID_FROM_HEADER
#define UID_FROM_HEADER(where) uid_from_header (where, sizeof (where))

#endif

static time_t time_from_header (const char *buf, size_t size);
static uid_t uid_from_header (const char *buf, size_t size);
static uintmax_t from_header (const char *, size_t, const char *,
			      uintmax_t, uintmax_t, bool, bool);

/* Base 64 digits; see Internet RFC 2045 Table 1.  */
static char const base_64_digits[64] =
{

  'n', 'o', 'p', 'q', 'r', 's', 't', '
#ifndef ISOCTAL
#define ISOCTAL(c) ((c)>='0'&&(c)<='7')

#endif

void read_header_loop_4(size_t *size, size_t *written, union block * *data_block, char * *bp);
void tar_checksum_loop_2(size_t *i, union block * *header, int *unsigned_sum, char * *p, int *signed_sum);
void from_header_loop_6(uintmax_t *value, const char * *where, const char * *lim, uintmax_t *overflow);
void base64_init_loop_1(int *i);
void from_header_loop_5(const char * *where, const char * *lim, const char * *type, _Bool *silent, int *re_arg_pa1_5, uintmax_t *re_arg_pa2_5);
void tar_checksum_loop_3(size_t *i, union block * *header, int *unsigned_sum, int *signed_sum);
void from_header_loop_8(uintmax_t *value, const char * *where, const char * *lim, uintmax_t *topbits, const char * *type, _Bool *silent, int *re_arg_pa1_8, uintmax_t *re_arg_pa2_8);
void from_header_loop_7(uintmax_t *value, int *digit, const char * *where, const char * *lim, uintmax_t *overflow);

#endif
