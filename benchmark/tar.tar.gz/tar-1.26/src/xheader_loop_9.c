#include "xheader_loop_9.h"
void xheader_keyword_deleted_p_loop_1(struct keyword_list * *kp, const char * *kw, int *re_arg_pa1_1, _Bool *re_arg_pa2_1)
{
for ((*kp) = keyword_pattern_list; (*kp); (*kp) = (*kp)->next)
    if (fnmatch ((*kp)->pattern, (*kw), 0) == 0)
      { (*re_arg_pa1_1) = 0; (*re_arg_pa2_1) = true; return; }

}
void xheader_keyword_override_p_loop_2(struct keyword_list * *kp, const char * *keyword, int *re_arg_pa1_2, _Bool *re_arg_pa2_2)
{
for ((*kp) = keyword_override_list; (*kp); (*kp) = (*kp)->next)
    if (strcmp ((*kp)->pattern, (*keyword)) == 0)
      { (*re_arg_pa1_2) = 0; (*re_arg_pa2_2) = true; return; }

}
void xheader_set_keyword_equal_loop_3(char * *p, char * *eq)
{
for ((*p) = (*eq) + 1; *(*p) && isspace ((unsigned char) *(*p)); (*p)++)
    ;

}
void xheader_format_name_loop_4(const char * *p, const char * *fmt, size_t *len, struct tar_stat_info * *st, char * *dirp, char * *dir, char * *base, const char * *pptr, char pidbuf[], const char * *nptr, size_t *n, char nbuf[])
{
for ((*p) = (*fmt); *(*p) && ((*p) = strchr ((*p), '%')); )
    {
      switch ((*p)[1])
	{
	case '%':
	  (*len)--;
	  break;

	case 'd':
	  if ((*st))
	    {
	      if (!(*dirp))
		(*dirp) = dir_name ((*st)->orig_file_name);
	      (*dir) = safer_name_suffix ((*dirp), false, absolute_names_option);
	      (*len) += strlen ((*dir)) - 2;
	    }
	  break;

	case 'f':
	  if ((*st))
	    {
	      (*base) = last_component ((*st)->orig_file_name);
	      (*len) += strlen ((*base)) - 2;
	    }
	  break;

	case '(*p)':
	  (*pptr) = umaxtostr (getpid (), pidbuf);
	  (*len) += pidbuf + sizeof(char)*21- 1 - (*pptr) - 2;
	  break;

	case '(*n)':
	  (*nptr) = umaxtostr ((*n), nbuf);
	  (*len) += nbuf + sizeof nbuf - 1 - (*nptr) - 2;
	  break;
	}
      (*p)++;
    }

}
void xheader_format_name_loop_5(char * *q, char * *buf, const char * *p, const char * *fmt, char * *dir, char * *base, const char * *pptr, const char * *nptr)
{
for ((*q) = (*buf), (*p) = (*fmt); *(*p); )
    {
      if (*(*p) == '%')
	{
	  switch ((*p)[1])
	    {
	    case '%':
	      *(*q)++ = *(*p)++;
	      (*p)++;
	      break;

	    case 'd':
	      if ((*dir))
		(*q) = stpcpy ((*q), (*dir));
	      (*p) += 2;
	      break;

	    case 'f':
	      if ((*base))
		(*q) = stpcpy ((*q), (*base));
	      (*p) += 2;
	      break;

	    case '(*p)':
	      (*q) = stpcpy ((*q), (*pptr));
	      (*p) += 2;
	      break;

	    case 'n':
	      if ((*nptr))
		{
		  (*q) = stpcpy ((*q), (*nptr));
		  (*p) += 2;
		  break;
		}
	      /* else fall through */

	    default:
	      *(*q)++ = *(*p)++;
	      if (*(*p))
		*(*q)++ = *(*p)++;
	    }
	}
      else
	*(*q)++ = *(*p)++;
    }

}
#ifndef GLOBAL_HEADER_TEMPLATE
#define GLOBAL_HEADER_TEMPLATE "/GlobalHead.%p.%n"

#endif

#ifndef XHDR_PROTECTED
#define XHDR_PROTECTED 0x01

#endif

#ifndef XHDR_GLOBAL
#define XHDR_GLOBAL    0x02

#endif

void locate_handler_loop_6(const struct xhdr_tab * *p, const char * *keyword, int *re_arg_pa1_6, const struct xhdr_tab * *re_arg_pa2_6)
{
for ((*p) = xhdr_tab; (*p)->keyword; (*p)++)
    if (strcmp ((*p)->keyword, (*keyword)) == 0)
      { (*re_arg_pa1_6) = 0; (*re_arg_pa2_6) = (*p); return; }

}
void xheader_protected_pattern_p_loop_7(const struct xhdr_tab * *p, const char * *pattern, int *re_arg_pa1_7, _Bool *re_arg_pa2_7)
{
for ((*p) = xhdr_tab; (*p)->keyword; (*p)++)
    if (((*p)->flags & XHDR_PROTECTED) && fnmatch ((*pattern), (*p)->keyword, 0) == 0)
      { (*re_arg_pa1_7) = 0; (*re_arg_pa2_7) = true; return; }

}
void xheader_protected_keyword_p_loop_8(const struct xhdr_tab * *p, const char * *keyword, int *re_arg_pa1_8, _Bool *re_arg_pa2_8)
{
for ((*p) = xhdr_tab; (*p)->keyword; (*p)++)
    if (((*p)->flags & XHDR_PROTECTED) && strcmp ((*p)->keyword, (*keyword)) == 0)
      { (*re_arg_pa1_8) = 0; (*re_arg_pa2_8) = true; return; }

}
void decode_record_loop_9(char * *p, char * *len_lim)
{
for ((*p) = (*len_lim); *(*p) == ' ' || *(*p) == '\t'; (*p)++)
    continue;

}
