#ifndef names_loop_9_h_
#define names_loop_9_h_

/* Various processing of names.

   Copyright (C) 1988, 1992, 1994, 1996, 1997, 1998, 1999, 2000, 2001,
   2003, 2004, 2005, 2006, 2007, 2009 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the
   Free Software Foundation; either version 3, or (at your option) any later
   version.

   This program is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
   Public License for more details.

   You should have received a copy of the GNU General Public License along
   with this program; if not, write to the Free Software Foundation, Inc.,
   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.  */
#include <system.h>
#include <fnmatch.h>
#include <hash.h>
#include <quotearg.h>
#include "common.h"

static struct name *namelist;
#ifndef NELT_NAME
#define NELT_NAME  0   
#endif

#ifndef NELT_CHDIR
#define NELT_CHDIR 1   
#endif

#ifndef NELT_FMASK
#define NELT_FMASK 2   
#endif

#define NELT_CHDIR 1   /* Change directory request */
#define NELT_FMASK 2   /* Change fnmatch options request */

struct name_elt        /* A name_array element. */
{
  char type;           /* Element type, see NELT_* constants above */
  union
  {
  
#ifndef SUCCESSOR
# define SUCCESSOR(name) ((name)->next)

#endif

#ifdef SUCCESSOR
#undef SUCCESSOR
#endif

void namelist_match_loop_1(struct name * *p, const char * *file_name, int *re_arg_pa1_1, struct name * *re_arg_pa2_1);
void blank_name_list_loop_8(struct name * *name);
void rebase_child_list_loop_6(struct name * *child, size_t *old_prefix_len, size_t *new_prefix_len, char * *new_prefix);
void collect_and_sort_names_loop_7(struct name * *name);
void contains_dot_dot_loop_9(const char * *p, int *re_arg_pa1_9, _Bool *re_arg_pa2_9);
void merge_sort_loop_5(struct name * *prev, struct name * *p, struct name * *head);
void label_notfound_loop_3(const struct name * *cursor, int *re_arg_pa1_3);
void all_names_found_loop_2(const struct name * *cursor, size_t *len, struct tar_stat_info * *p, int *re_arg_pa1_2, _Bool *re_arg_pa2_2);
void merge_sort_sll_loop_4(struct name * *cursor, struct name * *list, int *counter, int *first_length);

#endif
