#include "utf8_loop_1.h"
void string_ascii_p_loop_1(const char * *p, int *re_arg_pa1_1, _Bool *re_arg_pa2_1)
{
for (; *(*p); (*p)++)
    if (*(*p) & ~0x7f)
      { (*re_arg_pa1_1) = 0; (*re_arg_pa2_1) = false; return; }

}
