#ifndef misc_loop_5_h_
#define misc_loop_5_h_

/* Miscellaneous functions, not really specific to GNU tar.

   Copyright (C) 1988, 1992, 1994, 1995, 1996, 1997, 1999, 2000, 2001,
   2003, 2004, 2005, 2006, 2007, 2009, 2010 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the
   Free Software Foundation; either version 3, or (at your option) any later
   version.

   This program is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
   Public License for more details.

   You should have received a copy of the GNU General Public License along
   with this program; if not, write to the Free Software Foundation, Inc.,
   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.  */
#include <system.h>
#include <rmt.h>
#include "common.h"
#include <quotearg.h>
#include <xgetcwd.h>
#include <unlinkdir.h>
#include <utimens.h>
#ifndef DOUBLE_SLASH_IS_DISTINCT_ROOT
# define DOUBLE_SLASH_IS_DISTINCT_ROOT 0
#endif

struct wd
{
  /* The directory's name.  */
  char const *name;

  /* If nonzero, the file descriptor of the directory, or AT_FDCWD if
     the working directory.  If zero, the directory needs to be opened
     to be used.  */
  int fd;
};
enum { CHDIR_CACHE_SIZE = 16 };
static int wdcache[CHDIR_CACHE_SIZE];
struct namebuf
{
  char *buffer;		/* directory, `/', and directory member */
  size_t buffer_size;	/* allocated size of name_buffer */
  size_t dir_length;	/* length of directory part in buffer */
};
void code_ns_fraction_loop_2(char * *p, int *i, int *ns);
void chdir_arg_loop_4(const char * *dir);
void must_be_dot_or_slash_loop_3(const char * *file_name, int *re_arg_pa1_3, _Bool *re_arg_pa2_3);
void chdir_do_loop_5(size_t *ci, int *prev, int *i);
void normalize_filename_x_loop_1(const char * *q, char * *p, char * *name);

#endif
