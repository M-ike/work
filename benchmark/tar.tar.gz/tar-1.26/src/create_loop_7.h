#ifndef create_loop_7_h_
#define create_loop_7_h_

/* Create a tar archive.

   Copyright (C) 1985, 1992, 1993, 1994, 1996, 1997, 1999, 2000, 2001,
   2003, 2004, 2005, 2006, 2007, 2009, 2010 Free Software Foundation, Inc.

   Written by John Gilmore, on 1985-08-25.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the
   Free Software Foundation; either version 3, or (at your option) any later
   version.

   This program is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
   Public License for more details.

   You should have received a copy of the GNU General Public License along
   with this program; if not, write to the Free Software Foundation, Inc.,
   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.  */
#include <system.h>
#include <quotearg.h>
#include "common.h"
#include <hash.h>

enum { IMPOSTOR_ERRNO = ENOENT };
struct link
  {
    dev_t dev;
    ino_t ino;
    nlink_t nlink;
    char name[1];
  };
struct exclusion_tag
{
  const char *name;
  size_t length;
  enum exclusion_tag_type type;
  bool (*predicate) (int fd);
  struct exclusion_tag *next;
};
static struct exclusion_tag *exclusion_tags;
#ifndef CACHEDIR_SIGNATURE
#define CACHEDIR_SIGNATURE "Signature: 8a477f597d28d172789f06886806bc55"

#endif

#ifndef CACHEDIR_SIGNATURE_SIZE
#define CACHEDIR_SIGNATURE_SIZE (sizeof CACHEDIR_SIGNATURE - 1)

#endif

#ifndef MAX_VAL_WITH_DIGITS
#define MAX_VAL_WITH_DIGITS(digits, bits_per_digit) \
   ((digits) * (bits_per_digit) < sizeof (uintmax_t) * CHAR_BIT \
    ? ((uintmax_t) 1 << ((digits) * (bits_per_digit))) - 1 \
    : (uintmax_t) -1)

#endif

#ifndef MAX_OCTAL_VAL
#define MAX_OCTAL_VAL(buffer) MAX_VAL_WITH_DIGITS (sizeof (buffer) - 1, LG_8)

#endif

#ifndef GID_TO_CHARS
#define GID_TO_CHARS(val, where) gid_to_chars (val, where, sizeof (where))

#endif

#ifndef MAJOR_TO_CHARS
#define MAJOR_TO_CHARS(val, where) major_to_chars (val, where, sizeof (where))

#endif

#ifndef MINOR_TO_CHARS
#define MINOR_TO_CHARS(val, where) minor_to_chars (val, where, sizeof (where))

#endif

#ifndef MODE_TO_CHARS
#define MODE_TO_CHARS(val, where) mode_to_chars (val, where, sizeof (where))

#endif

#ifndef UID_TO_CHARS
#define UID_TO_CHARS(val, where) uid_to_chars (val, where, sizeof (where))

#endif

#ifndef UNAME_TO_CHARS
#define UNAME_TO_CHARS(name,buf) string_to_chars (name, buf, sizeof(buf))

#endif

#ifndef GNAME_TO_CHARS
#define GNAME_TO_CHARS(name,buf) string_to_chars (name, buf, sizeof(buf))

#endif

#ifndef FILL
#define FILL(field,byte) do {            \
  memset(field, byte, sizeof(field)-1);  \
  (field)[sizeof(field)-1] = 0;          \
} while (0)

#endif

	   (0, 0, _("%s: Unknown file
void split_long_name_loop_3(size_t *i, size_t *length, const char * *name);
void check_exclusion_tags_loop_1(struct exclusion_tag * *tag, const struct tar_stat_info * *st, const char ** *tag_file_name, int *re_arg_pa1_1, enum exclusion_tag_type *re_arg_pa2_1);
void tar_copy_str_loop_2(size_t *i, size_t *len, char * *dst, const char * *src);
void check_links_loop_7(struct link * *lp);
void dump_dir0_loop_5(const char * *entry, const char * *directory, size_t *entry_len, size_t *name_size, size_t *name_len, char * *name_buf, struct tar_stat_info * *st);
void open_failure_recover_loop_6(struct tar_stat_info * *p, const struct tar_stat_info * *dir, int *re_arg_pa1_6, _Bool *re_arg_pa2_6);
void simple_finish_header_loop_4(size_t *i, union block * *header, int *sum, char * *p);

#endif
