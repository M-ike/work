#include "checkpoint_loop_2.h"
void expand_checkpoint_string_loop_1(const char * *ip, const char * *input, size_t *outlen, size_t *cpslen, size_t *opstrlen)
{
for ((*ip) = (*input); ((*ip) = strchr ((*ip), '%')) != NULL; )
    {
      switch ((*ip)[1])
	{
	case 'u':
	  (*outlen) += (*cpslen) - 2;
	  break;

	case 's':
	  (*outlen) += (*opstrlen) - 2;
	}
      (*ip)++;
    }

}
void expand_checkpoint_string_loop_2(const char * *ip, const char * *input, char * *op, char * *output, char * *cps, const char * *opstr)
{
for ((*ip) = (*input), (*op) = (*output); *(*ip); )
    {
      if (*(*ip) == '%')
	{
	  switch (*++(*ip))
	    {
	    case 'u':
	      (*op) = stpcpy ((*op), (*cps));
	      break;

	    case 's':
	      (*op) = stpcpy ((*op), (*opstr));
	      break;

	    default:
	      *(*op)++ = '%';
	      *(*op)++ = *(*ip);
	      break;
	    }
	  (*ip)++;
	}
      else
	*(*op)++ = *(*ip)++;
    }

}
