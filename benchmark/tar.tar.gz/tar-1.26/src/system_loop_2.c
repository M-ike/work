#include "system_loop_2.h"
#ifndef PREAD
#define	PREAD 0			
#endif

#ifndef PWRITE
#define	PWRITE 1		
#endif

void sys_child_open_for_compress_loop_1(size_t *length, char * *cursor, size_t *status)
{
for ((*length) = 0, (*cursor) = record_start->buffer;
	   (*length) < record_size;
	   (*length) += (*status), (*cursor) += (*status))
	{
	  size_t size = record_size - (*length);

	  (*status) = safe_read (STDIN_FILENO, (*cursor), size);
	  if ((*status) == SAFE_READ_ERROR)
	    read_fatal (use_compress_program_option);
	  if ((*status) == 0)
	    break;
	}

}
void run_decompress_program_loop_2(const char * *p, int *i, const char * *prog)
{
for ((*p) = first_decompress_program (&(*i)); (*p); (*p) = next_decompress_program (&(*i)))
    {
      if ((*prog))
	{
	  WARNOPT (WARN_DECOMPRESS_PROGRAM,
		   (0, errno, _("cannot run %s"), (*prog)));
	  WARNOPT (WARN_DECOMPRESS_PROGRAM,
		   (0, 0, _("trying %s"), (*p)));
	}
      (*prog) = (*p);
      execlp ((*p), (*p), "-d", NULL);
    }

}
