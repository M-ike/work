#include "suffix_loop_1.h"









static const char *
find_compression_program (const char *name, const char *defprog)
{
  char *suf = strrchr (name, '.');

  if (suf)
    {
      int i;
      size_t len;

      suf++;
      len = strlen (suf);

      	{ int re_arg_pa1_1 = -1; const char * re_arg_pa2_1;
    find_compression_program_loop_1(&i, &len, &suf, &re_arg_pa1_1, &re_arg_pa2_1);
	if(re_arg_pa1_1 != -1) return re_arg_pa2_1; }

    }
  return defprog;
}

void
set_compression_program_by_suffix (const char *name, const char *defprog)
{
  const char *program = find_compression_program (name, defprog);
  if (program)
    use_compress_program_option = program;
}
