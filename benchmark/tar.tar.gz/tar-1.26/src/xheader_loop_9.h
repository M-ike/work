#ifndef xheader_loop_9_h_
#define xheader_loop_9_h_

/* POSIX extended headers for tar.

   Copyright (C) 2003, 2004, 2005, 2006, 2007, 2009, 2010 Free Software
   Foundation, Inc.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the
   Free Software Foundation; either version 3, or (at your option) any later
   version.

   This program is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
   Public License for more details.

   You should have received a copy of the GNU General Public License along
   with this program; if not, write to the Free Software Foundation, Inc.,
   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.  */
#include <system.h>
#include <fnmatch.h>
#include <hash.h>
#include <inttostr.h>
#include <quotearg.h>
#include "common.h"

struct keyword_list
{
  struct keyword_list *next;
  char *pattern;
  char *value;
};
static struct keyword_list *keyword_pattern_list;
static struct keyword_list *keyword_global_override_list;
static struct keyword_list *keyword_override_list;
#ifndef GLOBAL_HEADER_TEMPLATE
#define GLOBAL_HEADER_TEMPLATE "/GlobalHead.%p.%n"

#endif

#ifndef XHDR_PROTECTED
#define XHDR_PROTECTED 0x01

#endif

#define XHDR_GLOBAL    0x02

struct xhdr_tab
{
  char const *keyword;
  void (*coder) (struct tar_stat_info const *, char const *,
		 struct xheader *, void const *data);
  
   here, we'd need a boatload of forward
}

enum decode_time_status
  {
    decode_time_success,
    
void xheader_format_name_loop_4(const char * *p, const char * *fmt, size_t *len, struct tar_stat_info * *st, char * *dirp, char * *dir, char * *base, const char * *pptr, char pidbuf[], const char * *nptr, size_t *n, char nbuf[]);
void xheader_keyword_deleted_p_loop_1(struct keyword_list * *kp, const char * *kw, int *re_arg_pa1_1, _Bool *re_arg_pa2_1);
void decode_record_loop_9(char * *p, char * *len_lim);
void xheader_keyword_override_p_loop_2(struct keyword_list * *kp, const char * *keyword, int *re_arg_pa1_2, _Bool *re_arg_pa2_2);
void xheader_set_keyword_equal_loop_3(char * *p, char * *eq);
void xheader_protected_keyword_p_loop_8(const struct xhdr_tab * *p, const char * *keyword, int *re_arg_pa1_8, _Bool *re_arg_pa2_8);
void xheader_format_name_loop_5(char * *q, char * *buf, const char * *p, const char * *fmt, char * *dir, char * *base, const char * *pptr, const char * *nptr);
void locate_handler_loop_6(const struct xhdr_tab * *p, const char * *keyword, int *re_arg_pa1_6, const struct xhdr_tab * *re_arg_pa2_6);
void xheader_protected_pattern_p_loop_7(const struct xhdr_tab * *p, const char * *pattern, int *re_arg_pa1_7, _Bool *re_arg_pa2_7);

#endif
