#ifndef extract_loop_3_h_
#define extract_loop_3_h_

/* Extract files from a tar archive.

   Copyright (C) 1988, 1992, 1993, 1994, 1996, 1997, 1998, 1999, 2000,
   2001, 2003, 2004, 2005, 2006, 2007, 2010 Free Software Foundation, Inc.

   Written by John Gilmore, on 1985-11-19.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the
   Free Software Foundation; either version 3, or (at your option) any later
   version.

   This program is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
   Public License for more details.

   You should have received a copy of the GNU General Public License along
   with this program; if not, write to the Free Software Foundation, Inc.,
   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.  */
#include <system.h>
#include <quotearg.h>
#include <errno.h>
#include <priv-set.h>
#include <utimens.h>
#include "common.h"

static bool we_are_root;
static mode_t newdir_umask;
static mode_t current_umask;
#ifndef ALL_MODE_BITS
#define ALL_MODE_BITS ((mode_t) ~ (mode_t) 0)

#endif


struct delayed_set_stat
  {
    /* Next directory in list.  */
    struct delayed_set_stat *next;

    /* Metadata for this directory.  */
    dev_t dev;
    ino_t ino;
    mode_t mode; /* The desired mode is MODE & ~ current_umask.  */
    uid_t uid;
    gid_t gid;
    struct timespec atime;
    struct timespec mtime;

    /* An estimate of the directory's current mode, along with a mask
       specifying which bits of this estimate are known to be correct.
       If CURRENT_MODE_MASK is zero, CURRENT_MODE's value doesn't
       matter.  */
    mode_t current_mode;
    mode_t current_mode_mask;

    /* This directory is an intermediate directory that was created
       as an ancestor of some other directory; it was not mentioned
       in the archive, so do not set its uid, gid, atime, or mtime,
       and don't alter its mode outside of MODE_RWX.  */
    bool interdir;

    /* Whether symbolic links should be followed when accessing the
       directory.  */
    int atflag;

    /* Do not set the status of this directory until after delayed
       links are created.  */
    bool after_links;

    /* Directory that the name is relative to.  */
    int change_dir;

    /* Length and contents of name.  */
    size_t file_name_len;
    

/* List of links whose creation we have delayed.  */
struct delayed_link
  {
    /* The next delayed link in the list.  */
    struct delayed_link *next;

    /* The device, inode number and ctime of the placeholder.  Use
       ctime, not mtime, to make false matches less likely if some
       other process removes the placeholder.  */
    dev_t dev;
    ino_t ino;
    struct timespec ctime;

    /* True if the link is symbolic.  */
    bool is_symlink;

    /* The desired metadata, valid only the link is symbolic.  */
    mode_t mode;
    uid_t uid;
    gid_t gid;
    struct timespec atime;
    struct timespec mtime;

    /* The directory that the sources and target are relative to.  */
    int change_dir;

    /* A list of sources for this link.  The sources are all to be
       hard-linked together.  */

    struct string_list *sources;

    /* The desired target of the desired link.  */
    


struct string_list
  {
    struct string_list *next;
    
#ifndef RECOVER_NO
#define RECOVER_NO 0

#endif

#ifndef RECOVER_SKIP
#define RECOVER_SKIP 2

#endif

  return 1;
void repair_delayed_set_stat_loop_1(struct delayed_set_stat * *data, const struct stat * *dir_stat_info, struct tar_stat_info *current_stat_info, int *re_arg_pa1_1);
void extract_file_loop_2(off_t *size, struct tar_stat_info *current_stat_info, union block * *data_block, size_t *written, size_t *count, int *fd, char * *file_name);
void extract_link_loop_3(struct delayed_link * *ds, struct stat *st1, char * *file_name);

#endif
