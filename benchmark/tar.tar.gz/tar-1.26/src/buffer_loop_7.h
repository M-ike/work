#ifndef buffer_loop_7_h_
#define buffer_loop_7_h_

/* Buffer management for tar.

   Copyright (C) 1988, 1992, 1993, 1994, 1996, 1997, 1999, 2000, 2001,
   2003, 2004, 2005, 2006, 2007, 2008, 2009, 2010 Free Software
   Foundation, Inc.

   Written by John Gilmore, on 1985-08-25.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the
   Free Software Foundation; either version 3, or (at your option) any later
   version.

   This program is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
   Public License for more details.

   You should have received a copy of the GNU General Public License along
   with this program; if not, write to the Free Software Foundation, Inc.,
   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.  */
#include <system.h>
#include <system-ioctl.h>
#include <signal.h>
#include <closeout.h>
#include <fnmatch.h>
#include <human.h>
#include <quotearg.h>
#include "common.h"
#include <rmt.h>
/* Number of retries before giving up on read.  */
#define READ_ERROR_MAX 10
/* Variables.  */

#ifndef READ_ERROR_MAX
#define READ_ERROR_MAX 10

#endif


enum access_mode ac

struct bufmap
{
  struct bufmap *next;          /* Pointer to the next map entry */
  size_t start;                 /* Offset of the first data block */
  char *file_name;              /* Name of the stored file */
  off_t sizetotal;              /* Size of the stored file */
  
};

enum compress_type {
  ct_none,             /* Unknown compression type */
  ct_tar,              /* Plain tar file */
  ct_compress,
  ct_gzip,
  ct_bzip2,
  ct_lzip,
  ct_lzma,
  ct_lzop,
  

struct zip_magic
{
  enum compress_type type;
  size_t length;
  

struct zip_program
{
  enum compress_type type;
  char const *program;
  

static struct zip_magic const magic[] = {
  { ct_none, },
  { ct_tar },
  { ct_compress, 2, "\037\235" },
  { ct_gzip,     2, "\037\213" },
  { ct_bzip2,    3, "BZh" },
  { ct_lzip,     4, "LZIP" },
  { ct_lzma,     6, "\xFFLZMA" },
  { ct_lzop,     4, "\211LZO" },
  
#ifndef NMAGIC
#define NMAGIC (sizeof(magic)/sizeof(magic[0]))

#endif

#define NMAGIC (sizeof(magic)/sizeof(magic[0]))

static struct zip_program zip_program[] = {
  { ct_compress, COMPRESS_PROGRAM, "-Z" },
  { ct_compress, GZIP_PROGRAM,     "-z" },
  { ct_gzip,     GZIP_PROGRAM,     "-z" },
  { ct_bzip2,    BZIP2_PROGRAM,    "-j" },
  { ct_bzip2,    "lbzip2",         "-j" },
  { ct_lzip,     LZIP_PROGRAM,     "--lzip" },
  { ct_lzma,     LZMA_PROGRAM,     "--lzma" },
  { ct_lzma,     XZ_PROGRAM,       "-J" },
  { ct_lzop,     LZOP_PROGRAM,     "--lzop" },
  
#ifndef VOLUME_TEXT
#define VOLUME_TEXT " Volume "

#endif

#ifndef VOL_SUFFIX
#define VOL_SUFFIX "Volume"

#endif

void bufmap_free_loop_2(struct bufmap * *map, struct bufmap * *mark);
void check_compressed_archive_loop_4(const struct zip_magic * *p, int *re_arg_pa1_4, enum compress_type *re_arg_pa2_4);
void bufmap_locate_loop_1(struct bufmap * *map, size_t *off);
void change_tape_menu_loop_5(char * *name, char * *input_buffer);
void drop_volume_label_suffix_loop_7(const char * *p, const char * *label, size_t *len);
void change_tape_menu_loop_6(char * *cursor, char * *name);
void bufmap_reset_loop_3(struct bufmap * *map, ssize_t *fixup);

#endif
