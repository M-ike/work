#include "list_loop_8.h"
#ifndef max
#define max(a, b) ((a) < (b) ? (b) : (a))

#endif

#ifndef GID_FROM_HEADER
#define GID_FROM_HEADER(where) gid_from_header (where, sizeof (where))

#endif

#ifndef MAJOR_FROM_HEADER
#define MAJOR_FROM_HEADER(where) major_from_header (where, sizeof (where))

#endif

#ifndef MINOR_FROM_HEADER
#define MINOR_FROM_HEADER(where) minor_from_header (where, sizeof (where))

#endif

#ifndef MODE_FROM_HEADER
#define MODE_FROM_HEADER(where, hbits) \
  mode_from_header (where, sizeof (where), hbits)

#endif

#ifndef TIME_FROM_HEADER
#define TIME_FROM_HEADER(where) time_from_header (where, sizeof (where))

#endif

#ifndef UID_FROM_HEADER
#define UID_FROM_HEADER(where) uid_from_header (where, sizeof (where))

#endif

void base64_init_loop_1(int *i)
{
for ((*i) = 0; (*i) < 64; (*i)++)
    base64_map[(int) base_64_digits[(*i)]] = (*i);

}
void tar_checksum_loop_2(size_t *i, union block * *header, int *unsigned_sum, char * *p, int *signed_sum)
{
for ((*i) = sizeof *(*header); (*i)-- != 0;)
    {
      (*unsigned_sum) += (unsigned char) *(*p);
      (*signed_sum) += (signed char) (*(*p)++);
    }

}
void tar_checksum_loop_3(size_t *i, union block * *header, int *unsigned_sum, int *signed_sum)
{
for ((*i) = sizeof (*header)->header.chksum; (*i)-- != 0;)
    {
      (*unsigned_sum) -= (unsigned char) (*header)->header.chksum[(*i)];
      (*signed_sum) -= (signed char) ((*header)->header.chksum[(*i)]);
    }

}
void read_header_loop_4(size_t *size, size_t *written, union block * *data_block, char * *bp)
{
for ((*size) -= BLOCKSIZE; (*size) > 0; (*size) -= (*written))
		{
		  (*data_block) = find_next_block ();
		  if (! (*data_block))
		    {
		      ERROR ((0, 0, _("Unexpected EOF in archive")));
		      break;
		    }
		  (*written) = available_space_after ((*data_block));
		  if ((*written) > (*size))
		    (*written) = (*size);

		  memcpy ((*bp), (*data_block)->buffer, (*written));
		  (*bp) += (*written);
		  set_next_block_after ((union block *)
					((*data_block)->buffer + (*written) - 1));
		}

}
#ifndef ISOCTAL
#define ISOCTAL(c) ((c)>='0'&&(c)<='7')

#endif

void from_header_loop_5(const char * *where, const char * *lim, const char * *type, _Bool *silent, int *re_arg_pa1_5, uintmax_t *re_arg_pa2_5)
{
for (;;)
    {
      if ((*where) == (*lim))
	{
	  if ((*type) && !(*silent))
	    ERROR ((0, 0,
		    /* TRANSLATORS: %s is (*type) of the value (gid_t, uid_t,
		       etc.) */
		    _("Blanks in header where numeric %s value expected"),
		    (*type)));
	  { (*re_arg_pa1_5) = 0; (*re_arg_pa2_5) = -1; return; }
	}
      if (!ISSPACE ((unsigned char) *(*where)))
	break;
      (*where)++;
    }

}
void from_header_loop_6(uintmax_t *value, const char * *where, const char * *lim, uintmax_t *overflow)
{
for (;;)
	{
	  (*value) += *(*where)++ - '0';
	  if ((*where) == (*lim) || ! ISODIGIT (*(*where)))
	    break;
	  (*overflow) |= (*value) ^ ((*value) << LG_8 >> LG_8);
	  (*value) <<= LG_8;
	}

}
void from_header_loop_7(uintmax_t *value, int *digit, const char * *where, const char * *lim, uintmax_t *overflow)
{
for (;;)
	    {
	      (*value) += 7 - (*digit);
	      (*where)++;
	      if ((*where) == (*lim) || ! ISODIGIT (*(*where)))
		break;
	      (*digit) = *(*where) - '0';
	      (*overflow) |= (*value) ^ ((*value) << LG_8 >> LG_8);
	      (*value) <<= LG_8;
	    }

}
void from_header_loop_8(uintmax_t *value, const char * *where, const char * *lim, uintmax_t *topbits, const char * *type, _Bool *silent, int *re_arg_pa1_8, uintmax_t *re_arg_pa2_8)
{
for (;;)
	{
	  (*value) = ((*value) << LG_256) + (unsigned char) *(*where)++;
	  if ((*where) == (*lim))
	    break;
	  if ((((*value) << LG_256 >> LG_256) | (*topbits)) != (*value))
	    {
	      if ((*type) && !(*silent))
		ERROR ((0, 0,
			_("Archive base-256 value is out of %s range"),
			(*type)));
	      { (*re_arg_pa1_8) = 0; (*re_arg_pa2_8) = -1; return; }
	    }
	}

}
