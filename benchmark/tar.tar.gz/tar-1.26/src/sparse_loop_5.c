#include "sparse_loop_5.h"
void oldgnu_store_sparse_info_loop_1(size_t * *pindex, struct tar_sparse_file * *file, size_t *sparse_size, struct sparse * *sp)
{
for (; *(*pindex) < (*file)->stat_info->sparse_map_avail
	 && (*sparse_size) > 0; (*sparse_size)--, (*sp)++, ++*(*pindex))
    {
      OFF_TO_CHARS ((*file)->stat_info->sparse_map[*(*pindex)].offset,
		    (*sp)->offset);
      OFF_TO_CHARS ((*file)->stat_info->sparse_map[*(*pindex)].numbytes,
		    (*sp)->numbytes);
    }

}
void pax_dump_header_0_loop_2(size_t *i, struct tar_sparse_file * *file)
{
for ((*i) = 0; (*i) < (*file)->stat_info->sparse_map_avail; (*i)++)
	{
	  xheader_store ("GNU.sparse.offset", (*file)->stat_info, &(*i));
	  xheader_store ("GNU.sparse.numbytes", (*file)->stat_info, &(*i));
	}

}
void pax_dump_header_0_loop_3(size_t *i, struct tar_sparse_file * *file, struct sp_array * *map, char nbuf[])
{
for ((*i) = 0; (*i) < (*file)->stat_info->sparse_map_avail; (*i)++)
	{
	  if ((*i))
	    xheader_string_add (&(*file)->stat_info->xhdr, ",");
	  xheader_string_add (&(*file)->stat_info->xhdr,
			      umaxtostr ((*map)[(*i)].offset, nbuf));
	  xheader_string_add (&(*file)->stat_info->xhdr, ",");
	  xheader_string_add (&(*file)->stat_info->xhdr,
			      umaxtostr ((*map)[(*i)].numbytes, nbuf));
	}

}
#ifndef COPY_STRING
#define COPY_STRING(b,dst,src) do                \
 {                                               \
   char *endp = b->buffer + BLOCKSIZE;           \
   char const *srcp = src;                       \
   while (*srcp)                                 \
     {                                           \
       if (dst == endp)                          \
	 {                                       \
	   set_next_block_after (b);             \
	   b = find_next_block ();               \
           dst = b->buffer;                      \
	   endp = b->buffer + BLOCKSIZE;         \
	 }                                       \
       *dst++ = *srcp++;                         \
     }                                           \
   } while (0)

#endif

void pax_dump_header_1_loop_4(size_t *i, struct tar_sparse_file * *file, char * *p, struct sp_array * *map, char nbuf[], off_t *size)
{
for ((*i) = 0; (*i) < (*file)->stat_info->sparse_map_avail; (*i)++)
    {
      (*p) = umaxtostr ((*map)[(*i)].offset, nbuf);
      (*size) += strlen ((*p)) + 1;
      (*p) = umaxtostr ((*map)[(*i)].numbytes, nbuf);
      (*size) += strlen ((*p)) + 1;
    }

}
void pax_dump_header_1_loop_5(size_t *i, struct tar_sparse_file * *file, char * *p, struct sp_array * *map, char nbuf[], union block * *blk, char * *q)
{
for ((*i) = 0; (*i) < (*file)->stat_info->sparse_map_avail; (*i)++)
    {
      (*p) = umaxtostr ((*map)[(*i)].offset, nbuf);
      COPY_STRING ((*blk), (*q), (*p));
      COPY_STRING ((*blk), (*q), "\n");
      (*p) = umaxtostr ((*map)[(*i)].numbytes, nbuf);
      COPY_STRING ((*blk), (*q), (*p));
      COPY_STRING ((*blk), (*q), "\n");
    }

}
#ifndef COPY_BUF
#define COPY_BUF(b,buf,src) do                                     \
 {                                                                 \
   char *endp = b->buffer + BLOCKSIZE;                             \
   char *dst = buf;                                                \
   do                                                              \
     {                                                             \
       if (dst == buf + UINTMAX_STRSIZE_BOUND -1)                  \
         {                                                         \
           ERROR ((0, 0, _("%s: numeric overflow in sparse archive member"), \
	          file->stat_info->orig_file_name));               \
           return false;                                           \
         }                                                         \
       if (src == endp)                                            \
	 {                                                         \
	   set_next_block_after (b);                               \
           file->dumped_size += BLOCKSIZE;                         \
           b = find_next_block ();                                 \
           src = b->buffer;                                        \
	   endp = b->buffer + BLOCKSIZE;                           \
	 }                                                         \
       *dst = *src++;                                              \
     }                                                             \
   while (*dst++ != '\n');                                         \
   dst[-1] = 0;                                                    \
 } while (0)

#endif

