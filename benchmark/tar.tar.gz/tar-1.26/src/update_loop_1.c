#include "update_loop_1.h"
void update_archive_loop_1(char * *p, char * *dirp, namebuf_t *nbuf)
{
for ((*p) = (*dirp); *(*p); (*p) += strlen ((*p)) + 1)
			      addname (namebuf_name ((*nbuf), (*p)),
				       0, false, NULL);

}
