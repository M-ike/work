#ifndef tar_loop_14_h_
#define tar_loop_14_h_

/* A tar (tape archiver) program.

   Copyright (C) 1988, 1992, 1993, 1994, 1995, 1996, 1997, 1999, 2000,
   2001, 2003, 2004, 2005, 2006, 2007, 2009 Free Software Foundation, Inc.

   Written by John Gilmore, starting 1985-08-25.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the
   Free Software Foundation; either version 3, or (at your option) any later
   version.

   This program is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
   Public License for more details.

   You should have received a copy of the GNU General Public License along
   with this program; if not, write to the Free Software Foundation, Inc.,
   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.  */
#include <system.h>
#include <fnmatch.h>
#include <argp.h>
#include <argp-namefrob.h>
#include <argp-fmtstream.h>
#include <argp-version-etc.h>
#include <signal.h>
#if ! defined SIGCHLD && defined SIGCLD
# define SIGCHLD SIGCLD
#endif
/* The following causes "common.h" to produce definitions of all the global
   variables, rather than just "extern" declarations of them.  GNU tar does
   depend on the system loader to preset all GLOBAL variables to neutral (or
   zero) values; explicit initialization is usually not done.  */
#define GLOBAL
#include "common.h"
#include <argmatch.h>
#include <closeout.h>
#include <configmake.h>
#include <exitfail.h>
#include <parse-datetime.h>
#include <rmt.h>
#include <rmt-command.h>
#include <prepargs.h>
#include <quotearg.h>
#include <version-etc.h>
#include <xstrtol.h>
#include <stdopen.h>
#include <priv-set.h>
/* Local declarations.  */
#if ! defined SIGCHLD && defined SIGCLD
# define SIGCHLD SIGCLD
#endif
#ifndef DEFAULT_ARCHIVE_FORMAT
# define DEFAULT_ARCHIVE_FORMAT GNU_FORMAT
#endif
#if ! defined SIGCHLD && defined SIGCLD
# define SIGCHLD SIGCLD
#endif
#ifndef DEFAULT_ARCHIVE_FORMAT
# define DEFAULT_ARCHIVE_FORMAT GNU_FORMAT
#endif
#ifndef DEFAULT_ARCHIVE
# define DEFAULT_ARCHIVE "tar.out"
#endif
#if ! defined SIGCHLD && defined SIGCLD
# define SIGCHLD SIGCLD
#endif
#ifndef DEFAULT_ARCHIVE_FORMAT
# define DEFAULT_ARCHIVE_FORMAT GNU_FORMAT
#endif
#ifndef DEFAULT_ARCHIVE
# define DEFAULT_ARCHIVE "tar.out"
#endif
#ifndef DEFAULT_BLOCKING
# define DEFAULT_BLOCKING 20
#endif

#ifndef GLOBAL
#define GLOBAL

#endif


static struct fmttab {
  char const *name;
  enum archive_format fmt;
} const fmttab[] = {
  { "v7",      V7_FORMAT },
  { "oldgnu",  OLDGNU_FORMAT },
  { "ustar",   USTAR_FORMAT },
  { "posix",   POSIX_FORMAT },
#if 0 /* not fully supported yet */
  { "star",    STAR_FORMAT },
#endif
  { "gnu",     GNU_FORMAT },
  { "pax",     POSIX_FORMAT }, /* An alias for posix */
  
#ifndef FORMAT_MASK
#define FORMAT_MASK(n) (1<<(n))

#endif

/* Options.  */

enum
{
  ANCHORED_OPTION = CHAR_MAX + 1,
  ATIME_PRESERVE_OPTION,
  BACKUP_OPTION,
  CHECK_DEVICE_OPTION,
  CHECKPOINT_OPTION,
  CHECKPOINT_ACTION_OPTION,
  DELAY_DIRECTORY_RESTORE_OPTION,
  HARD_DEREFERENCE_OPTION,
  DELETE_OPTION,
  EXCLUDE_BACKUPS_OPTION,
  EXCLUDE_CACHES_OPTION,
  EXCLUDE_CACHES_UNDER_OPTION,
  EXCLUDE_CACHES_ALL_OPTION,
  EXCLUDE_OPTION,
  EXCLUDE_TAG_OPTION,
  EXCLUDE_TAG_UNDER_OPTION,
  EXCLUDE_TAG_ALL_OPTION,
  EXCLUDE_VCS_OPTION,
  FORCE_LOCAL_OPTION,
  FULL_TIME_OPTION,
  GROUP_OPTION,
  IGNORE_CASE_OPTION,
  IGNORE_COMMAND_ERROR_OPTION,
  IGNORE_FAILED_READ_OPTION,
  INDEX_FILE_OPTION,
  KEEP_NEWER_FILES_OPTION,
  LEVEL_OPTION,
  LZIP_OPTION,
  LZMA_OPTION,
  LZOP_OPTION,
  MODE_OPTION,
  MTIME_OPTION,
  NEWER_MTIME_OPTION,
  NO_ANCHORED_OPTION,
  NO_AUTO_COMPRESS_OPTION,
  NO_CHECK_DEVICE_OPTION,
  NO_DELAY_DIRECTORY_RESTORE_OPTION,
  NO_IGNORE_CASE_OPTION,
  NO_IGNORE_COMMAND_ERROR_OPTION,
  NO_NULL_OPTION,
  NO_OVERWRITE_DIR_OPTION,
  NO_QUOTE_CHARS_OPTION,
  NO_RECURSION_OPTION,
  NO_SAME_OWNER_OPTION,
  NO_SAME_PERMISSIONS_OPTION,
  NO_SEEK_OPTION,
  NO_UNQUOTE_OPTION,
  NO_WILDCARDS_MATCH_SLASH_OPTION,
  NO_WILDCARDS_OPTION,
  NULL_OPTION,
  NUMERIC_OWNER_OPTION,
  OCCURRENCE_OPTION,
  OLD_ARCHIVE_OPTION,
  ONE_FILE_SYSTEM_OPTION,
  OVERWRITE_DIR_OPTION,
  OVERWRITE_OPTION,
  OWNER_OPTION,
  PAX_OPTION,
  POSIX_OPTION,
  PRESERVE_OPTION,
  QUOTE_CHARS_OPTION,
  QUOTING_STYLE_OPTION,
  RECORD_SIZE_OPTION,
  RECURSION_OPTION,
  RECURSIVE_UNLINK_OPTION,
  REMOVE_FILES_OPTION,
  RESTRICT_OPTION,
  RMT_COMMAND_OPTION,
  RSH_COMMAND_OPTION,
  SAME_OWNER_OPTION,
  SHOW_DEFAULTS_OPTION,
  SHOW_OMITTED_DIRS_OPTION,
  SHOW_TRANSFORMED_NAMES_OPTION,
  SPARSE_VERSION_OPTION,
  STRIP_COMPONENTS_OPTION,
  SUFFIX_OPTION,
  TEST_LABEL_OPTION,
  TOTALS_OPTION,
  TO_COMMAND_OPTION,
  TRANSFORM_OPTION,
  UNQUOTE_OPTION,
  UTC_OPTION,
  VOLNO_FILE_OPTION,
  WARNING_OPTION,
  
#ifndef GRID
#define GRID 10

#endif

#ifndef GRID
#define GRID 20

#endif

#ifndef GRID
#define GRID 30

#endif

#ifndef GRID
#define GRID 40

#endif

#ifndef GRID
#define GRID 50

#endif

#ifndef GRID
#define GRID 60

#endif

#ifndef GRID
#define GRID 70

#endif

#ifndef GRID
#define GRID 80

#endif

#ifndef GRID
#define GRID 90

#endif

#ifndef GRID
#define GRID 100

#endif

#ifndef GRID
#define GRID 110

#endif

#ifndef GRID
#define GRID 120

#endif

#ifndef GRID
#define GRID 130

#endif

#ifndef GRID
#define GRID 140

#endif

#ifndef GRID
#define GRID 150

#endif

#ifdef GRID
#undef GRID
#endif

  {0, 0, 0, 0, 0, 0}
};

static char const *const atime_preserve_args[] =
{
  "replace", "system", NULL
};
static enum atime_preserve const atime_preserve_types[] =
{
  replace_atime_preserve, system_ati
me_preserve
};

/* Make sure atime_preserve_types has as much entries as atime_preserve_args
   (minus 1 for NULL guard) */
ARGMATCH_VERIFY (atime_preserve_args, atime_preserve_types);

/* Wildcard matching settings */
enum wildcards
  {
    default_wildcards, /* For exclusion == enable_wildcards,
			  for inclusion == disable_wildcards */
    disable_wildcards,
    enable_wildcards
  };

#ifndef MAKE_EXCL_OPTIONS
#define MAKE_EXCL_OPTIONS(args) \
 ((((args)->wildcards != disable_wildcards) ? EXCLUDE_WILDCARDS : 0) \
  | (args)->matching_flags \
  | recursion_option)

#endif

#ifndef MAKE_INCL_OPTIONS
#define MAKE_INCL_OPTIONS(args) \
 ((((args)->wildcards == enable_wildcards) ? EXCLUDE_WILDCARDS : 0) \
  | (args)->include_anchored \
  | (args)->matching_flags \
  | recursion_option)

#endif

    { "USR2", SIGUSR2 },
    { "SIGHUP", SIGHUP },
    { "HUP", SIGHUP },
    { "SIGINT", SIGINT },
    { "INT", SIGINT },
    { "SIGQUIT", SIGQUIT },
  
    {
      struct textual_date *next = p->next;
      if (verbose_option)
	{
	  char const *treated_as = tartime (p->ts, true);
	  if (strcmp (p->date, treated_as) != 0)
	   
	}
      obstack_1grow (stk, c);
      counter++;
    }

  

#ifndef LOW_DENSITY_NUM
# define LOW_DENSITY_NUM 0

#endif

#ifndef MID_DENSITY_NUM
# define MID_DENSITY_NUM 8

#endif

#ifndef HIGH_DENSITY_NUM
# define HIGH_DENSITY_NUM 16

#endif

#ifndef TAR_SIZE_SUFFIXES
#define TAR_SIZE_SUFFIXES "bBcGgkKMmPTtw"

#endif

#ifndef NS_PRECISION_FORMAT_MASK
#define NS_PRECISION_FORMAT_MASK FORMAT_MASK (POSIX_FORMAT)

#endif

void tar_set_quoting_style_loop_4(int *i, char * *arg, int *re_arg_pa1_4);
void archive_format_string_loop_2(const struct fmttab * *p, enum archive_format *fmt, int *re_arg_pa1_2, const char * *re_arg_pa2_2);
void update_argv_loop_9(char * *p, char * *start, size_t *count);
void expand_pax_option_loop_11(char * *p, size_t *len);
void tar_list_quoting_styles_loop_3(int *i, struct obstack * *stk, size_t *prefixlen, const char * *prefix);
void parse_opt_loop_12(char * *arg);
void find_argp_option_loop_14(struct argp_option * *o, int *letter, int *re_arg_pa1_14, struct argp_option * *re_arg_pa2_14);
void add_exclude_array_loop_5(int *i, const char *const * *fv);
void parse_opt_loop_13(char * *arg);
void update_argv_loop_8(size_t *size, char * *p, struct obstack *argv_stk);
void add_file_id_loop_7(struct file_id_list * *p, struct stat *st, const char * *filename);
void set_archive_format_loop_1(const struct fmttab * *p, const char * *name);
void report_textual_dates_loop_6(struct textual_date * *p, struct tar_args * *args);
void update_argv_loop_10(size_t *i, struct argp_state * *state, char * *p, char * *start, int *term);

#endif
