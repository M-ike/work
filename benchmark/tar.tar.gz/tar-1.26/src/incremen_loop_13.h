#ifndef incremen_loop_13_h_
#define incremen_loop_13_h_

/* GNU dump extensions to tar.

   Copyright (C) 1988, 1992, 1993, 1994, 1996, 1997, 1999, 2000, 2001,
   2003, 2004, 2005, 2006, 2007, 2008, 2009 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the
   Free Software Foundation; either version 3, or (at your option) any later
   version.

   This program is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
   Public License for more details.

   You should have received a copy of the GNU General Public License along
   with this program; if not, write to the Free Software Foundation, Inc.,
   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.  */
#include <system.h>
#include <hash.h>
#include <quotearg.h>
#include "common.h"
/* Incremental dump specialities.  */
/* Which child files to save under a directory.  */

enum children
  {
    NO_CHILDREN,
    CHANGED_CHILDREN,
    ALL_CHILDREN
  };
#ifndef DIRF_INIT
#define DIRF_INIT     0x0001    
#endif

#ifndef DIRF_NFS
#define DIRF_NFS      0x0002    
#endif

#ifndef DIRF_FOUND
#define DIRF_FOUND    0x0004    
#endif

#ifndef DIRF_NEW
#define DIRF_NEW      0x0008    
#endif

#ifndef DIRF_RENAMED
#define DIRF_RENAMED  0x0010    
#endif

#ifndef DIR_IS_INITED
#define DIR_IS_INITED(d) ((d)->flags & DIRF_INIT)

#endif

#ifndef DIR_IS_NFS
#define DIR_IS_NFS(d) ((d)->flags & DIRF_NFS)

#endif

#ifndef DIR_IS_FOUND
#define DIR_IS_FOUND(d) ((d)->flags & DIRF_FOUND)

#endif

#ifndef DIR_IS_RENAMED
#define DIR_IS_RENAMED(d) ((d)->flags & DIRF_RENAMED)

#endif

#ifndef DIR_SET_FLAG
#define DIR_SET_FLAG(d,f) (d)->flags |= (f)

#endif

#ifndef DIR_CLEAR_FLAG
#define DIR_CLEAR_FLAG(d,f) (d)->flags &= ~(f)

#endif

#define DIRF_RENAMED  0x0010    /* directory is renamed */

#define DIR_IS_INITED(d) ((d)->flags & DIRF_INIT)
#define DIR_IS_NFS(d) ((d)->flags & DIRF_NFS)
#define DIR_IS_FOUND(d) ((d)->flags & DIRF_FOUND)
/* #define DIR_IS_NEW(d) ((d)->flags & DIRF_NEW) FIXME: not used */
#d
#define DIR_CLEAR_FLAG(d,f) (d)->flags &= ~(f)

struct dumpdir                 /* Dump directory listing */
{
  char *contents;              /* Actual contents */
  size_t total;                /* Total number of elements */
  size_t elc;                  /* Number of D/N/Y elements. */
  char **elv;                  /* Array of D/N/Y elements */
};

/* Directory attributes.  */
struct directory
  {
    struct directory *next;
    struct timespec mtime;      /* Modification time */
    dev_t device_number;	/* device number for directory */
    ino_t inode_number;		/* inode number for directory */
    
dumpdir_locate (struct dumpdir *dump, const char *name)
{
  char **ptr;
  if (!dump)
    return NULL;


#ifndef ST_DEV_MSB
# define ST_DEV_MSB(st) (~ (dev_t) 0 << (sizeof (st).st_dev * CHAR_BIT - 1))

#endif

#ifndef NFS_FILE_STAT
# define NFS_FILE_STAT(st) (((st).st_dev & ST_DEV_MSB (st)) != 0)

#endif

#ifndef PD_FORCE_CHILDREN
#define PD_FORCE_CHILDREN 0x10

#endif

#ifndef PD_FORCE_INIT
#define PD_FORCE_INIT     0x20

#endif

#ifndef PD_CHILDREN
#define PD_CHILDREN(f) ((f) & 3)

#endif

#ifndef TAR_INCREMENTAL_VERSION
#define TAR_INCREMENTAL_VERSION 2

#endif

#ifndef TEMP_DIR_TEMPLATE
#define TEMP_DIR_TEMPLATE "tar.XXXXXX"

#endif

void try_purge_directory_loop_13(char * *arc, struct tar_stat_info *current_stat_info, char * *temp_stub, char * *current_dir, int *re_arg_pa1_13, _Bool *re_arg_pa2_13);
void makedumpdir_loop_5(size_t *i, const char * *p, const char * *dir, const char ** *array);
void read_directory_file_loop_10(char * *ebuf);
void dumpdir_create0_loop_1(size_t *i, size_t *total, size_t *ctsize, const char * *q, const char * *contents, size_t *len, const char * *cmask);
void read_negative_num_loop_8(size_t *i, int *c, FILE * *fp, char buf[]);
void read_unsigned_num_loop_9(size_t *i, int *c, char buf[], FILE * *fp);
void store_rename_loop_6(struct directory * *prev, struct directory * *dir);
void dumpdir_create0_loop_2(size_t *i, char * *p, struct dumpdir * *dump, const char * *cmask);
void makedumpdir_loop_4(const char * *p, const char * *dir, size_t *dirsize, size_t *len);
void get_gnu_dumpdir_loop_11(size_t *size, size_t *copied, union block * *data_block, char * *to);
void dumpdir_ok_loop_12(char * *p, char * *dumpdir, int *expect, int *has_tempdir, int *re_arg_pa1_12, _Bool *re_arg_pa2_12);
void dirlist_replace_prefix_loop_3(struct directory * *dp, const char * *pref, size_t *pref_len, const char * *repl, size_t *repl_len);
void read_obstack_loop_7(size_t *i, int *c, FILE * *fp, struct obstack * *stk);

#endif
