#ifndef checkpoint_loop_2_h_
#define checkpoint_loop_2_h_

/* Checkpoint management for tar.

   Copyright (C) 2007 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the
   Free Software Foundation; either version 3, or (at your option) any later
   version.

   This program is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
   Public License for more details.

   You should have received a copy of the GNU General Public License along
   with this program.  If not, see <http://www.gnu.org/licenses/>. */
#include <system.h>
#include "common.h"

enum checkpoint_opcode
  {
    cop_dot,
    cop_bell,
    cop_echo,
    cop_ttyout,
    cop_sleep,
    cop_exec
  };
struct checkpoint_action
{
  struct checkpoint_action *next;
  enum checkpoint_opcode opcode;
  union
  {
    time_t time;
    char *command;
  } v;

};
static struct checkpoint_action *checkpoint_action, *checkpoint_action_tail;
void expand_checkpoint_string_loop_1(const char * *ip, const char * *input, size_t *outlen, size_t *cpslen, size_t *opstrlen);
void expand_checkpoint_string_loop_2(const char * *ip, const char * *input, char * *op, char * *output, char * *cps, const char * *opstr);

#endif
