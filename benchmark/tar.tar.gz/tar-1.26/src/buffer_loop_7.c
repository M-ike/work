#include "buffer_loop_7.h"
#ifndef READ_ERROR_MAX
#define READ_ERROR_MAX 10

#endif

void bufmap_locate_loop_1(struct bufmap * *map, size_t *off)
{
for ((*map) = bufmap_head; (*map); (*map) = (*map)->next)
    {
      if (!(*map)->next
	  || (*off) < (*map)->next->start * BLOCKSIZE)
	break;
    }

}
void bufmap_free_loop_2(struct bufmap * *map, struct bufmap * *mark)
{
for ((*map) = bufmap_head; (*map) && (*map) != (*mark); )
    {
      struct bufmap *next = (*map)->next;
      free ((*map)->file_name);
      free ((*map));
      (*map) = next;
    }

}
void bufmap_reset_loop_3(struct bufmap * *map, ssize_t *fixup)
{
for (; (*map); (*map) = (*map)->next)
	(*map)->start += (*fixup);

}
#ifndef NMAGIC
#define NMAGIC (sizeof(magic)/sizeof(magic[0]))

#endif

void check_compressed_archive_loop_4(const struct zip_magic * *p, int *re_arg_pa1_4, enum compress_type *re_arg_pa2_4)
{
for ((*p) = magic + 2; (*p) < magic + NMAGIC; (*p)++)
    if (memcmp (record_start->buffer, (*p)->magic, (*p)->length) == 0)
      { (*re_arg_pa1_4) = 0; (*re_arg_pa2_4) = (*p)->type; return; }

}
void change_tape_menu_loop_5(char * *name, char * *input_buffer)
{
for ((*name) = (*input_buffer) + 1;
                 *(*name) == ' ' || *(*name) == '\t';
                 (*name)++)
              ;

}
void change_tape_menu_loop_6(char * *cursor, char * *name)
{
for ((*cursor) = (*name); *(*cursor) && *(*cursor) != '\n'; (*cursor)++)
              ;

}
#ifndef VOLUME_TEXT
#define VOLUME_TEXT " Volume "

#endif

#ifndef VOLUME_TEXT_LEN
#define VOLUME_TEXT_LEN (sizeof VOLUME_TEXT - 1)

#endif

void drop_volume_label_suffix_loop_7(const char * *p, const char * *label, size_t *len)
{
for ((*p) = (*label) + (*len) - 1; (*p) > (*label) && isdigit ((unsigned char) *(*p)); (*p)--)
    ;

}
#ifndef VOL_SUFFIX
#define VOL_SUFFIX "Volume"

#endif

