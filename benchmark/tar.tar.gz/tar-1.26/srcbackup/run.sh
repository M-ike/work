#!/bin/sh

BIN=/home/zql/desktop/LoopExtractor00/driver
SRC=.

file_list=""

for file in `find $SRC -name "*.c"`
do
    file_list=$file_list$file" "
done

echo $file_list
$BIN -include/home/zql/desktop/tar-1.26/config.h -I/home/zql/desktop/tar-1.26/tests/ -I/home/zql/desktop/tar-1.26/gnu/ -I/home/zql/desktop/tar-1.26/build-aux/ -I/home/zql/desktop/tar-1.26/ -I/home/zql/desktop/tar-1.26/.pc/longlink-hack.diff/src/ -I/home/zql/desktop/tar-1.26/lib/ -I/home/zql/desktop/tar-1.26/src  -I/usr/include -I/usr/lib/gcc/x86_64-linux-gnu/4.6/include $file_list
