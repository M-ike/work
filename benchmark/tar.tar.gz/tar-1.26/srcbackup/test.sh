#!/bin/sh 
rm *_loop_*

mv incremen_old.c incremen.c

/home/zql/desktop/work/LoopExtractor01/driver -I/home/zql/桌面/tar-1.26/gnu -I/home/zql/桌面/tar-1.26/lib -I/home/zql/桌面/tar-1.26/src -I/usr/include -I/usr/lib/gcc/x86_64-linux-gnu/4.6/include incremen.c

