#!/bin/sh

rm ./src/*

cp ./srcbackup/* ./src/
