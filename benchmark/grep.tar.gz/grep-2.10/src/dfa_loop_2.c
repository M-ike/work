#include "dfa_loop_2.h"
#ifndef BRACKET_BUFFER_SIZE
#define BRACKET_BUFFER_SIZE 128

#endif

void state_index_loop_1(int *j, const position_set * *s, struct dfa * *d, int *constraint, int *newline, int *letter, int *i)
{
for ((*j) = 0; (*j) < (*s)->nelem; ++(*j))
    if ((*d)->tokens[(*s)->elems[(*j)].index] < 0)
      {
        (*constraint) = (*s)->elems[(*j)].constraint;
        if (SUCCEEDS_IN_CONTEXT((*constraint), (*newline), 0, (*letter), 0)
            || SUCCEEDS_IN_CONTEXT((*constraint), (*newline), 0, (*letter), 1)
            || SUCCEEDS_IN_CONTEXT((*constraint), (*newline), 1, (*letter), 0)
            || SUCCEEDS_IN_CONTEXT((*constraint), (*newline), 1, (*letter), 1))
          (*d)->states[(*i)].constraint |= (*constraint);
        if (! (*d)->states[(*i)].first_end)
          (*d)->states[(*i)].first_end = (*d)->tokens[(*s)->elems[(*j)].index];
      }
    else if ((*d)->tokens[(*s)->elems[(*j)].index] == BACKREF)
      {
        (*d)->states[(*i)].constraint = NO_CONSTRAINT;
        (*d)->states[(*i)].backref = 1;
      }

}
void dfaoptimize_loop_2(unsigned int *i, struct dfa * *d, int *re_arg_pa1_2)
{
for ((*i) = 0; (*i) < (*d)->tindex; ++(*i))
    {
      switch((*d)->tokens[(*i)])
        {
        case ANYCHAR:
          /* Lowered.  */
          abort ();
        case MBCSET:
          /* Requires multi-byte algorithm.  */
          { (*re_arg_pa1_2) = 0; return; }
        default:
          break;
        }
    }

}
