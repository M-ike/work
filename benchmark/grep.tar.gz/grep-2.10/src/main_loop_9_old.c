#include "main_loop_9.h"
#define SGR_START  sgr_start
#define SGR_END    sgr_end
#define PR_SGR_FMT(fmt, s) do { if (*(s)) printf((fmt), (s)); } while (0)
#define PR_SGR_FMT_IF(fmt, s) \
  do { if (color_option && *(s)) printf((fmt), (s)); } while (0)
#define PR_SGR_START(s)    PR_SGR_FMT(   SGR_START, (s))
#define PR_SGR_END(s)      PR_SGR_FMT(   SGR_END,   (s))
#define PR_SGR_START_IF(s) PR_SGR_FMT_IF(SGR_START, (s))
#define PR_SGR_END_IF(s)   PR_SGR_FMT_IF(SGR_END,   (s))
#define INITIAL_BUFSIZE 32768	/* Initial buffer size, not counting slop. */
#define ALIGN_TO(val, alignment) \
  ((size_t) (val) % (alignment) == 0 \
   ? (val) \
   : (val) + ((alignment) - (size_t) (val) % (alignment)))

void prtext_loop_3(int *i, int *out_before, const char * *p, const char * *bp, char *eol)
{
      for ((*i) = 0; (*i) < (*out_before); ++(*i))
        if ((*p) > (*bp))
          do
            --(*p);
          while ((*p)[-1] != (*eol));
}
void setmatcher_loop_6(unsigned int *i, const struct matcher matchers[], const char * *m, compile_fp_t *compile, execute_fp_t *execute, const char * *matcher, int *re_arg_pa1_6)
{
      for ((*i) = 0; matchers[(*i)].name; (*i)++)
        if (STREQ ((*m), matchers[(*i)].name))
          {
            (*compile) = matchers[(*i)].compile;
            (*execute) = matchers[(*i)].execute;
            (*matcher) = (*m);
            { (*re_arg_pa1_6) = 0; return; }
          }
}
void fillbuf_loop_1(size_t *newsize, size_t *bufalloc, size_t *pagesize, size_t *minsize)
{
      for ((*newsize) = (*bufalloc) - (*pagesize) - 1; (*newsize) < (*minsize); (*newsize) *= 2)
        if ((*newsize) * 2 < (*newsize) || (*newsize) * 2 + (*pagesize) + 1 < (*newsize) * 2)
          xalloc_die ();
}
void parse_grep_colors_loop_8(char * *q, struct color_cap color_dict[], char * *name, char * *val, const char * *p, int *re_arg_pa1_8)
{
  for (;;)
    if (*(*q) == ':' || *(*q) == '\0')
      {
        char c = *(*q);
        struct color_cap *cap;

        *(*q)++ = '\0'; /* Terminate (*name) or (*val).  */
        /* Empty (*name) without (*val) (empty cap)
         * won't match and will be ignored.  */
        for (cap = color_dict; cap->name; cap++)
          if (STREQ (cap->name, (*name)))
            break;
        /* If (*name) unknown, go on for forward compatibility.  */
        if (cap->name)
          {
            if (cap->var)
              {
                if ((*val))
              *(cap->var) = (*val);
                else
              error(0, 0, _("in GREP_COLORS=\"%s\", the \"%s\" capacity "
                                "needs a value (\"=...\"); skipped"), (*p), (*name));
          }
        else if ((*val))
          error(0, 0, _("in GREP_COLORS=\"%s\", the \"%s\" capacity "
                "is boolean and cannot take a value (\"=%s\"); skipped"),
                (*p), (*name), (*val));
      }
        if (cap->fct)
          {
            const char *err_str = cap->fct();

            if (err_str)
              error(0, 0, _("in GREP_COLORS=\"%s\", the \"%s\" capacity %s"),
                    (*p), (*name), err_str);
          }
        if (c == '\0')
          { (*re_arg_pa1_8) = 0; return; }
        (*name) = (*q);
        (*val) = NULL;
      }
    else if (*(*q) == '=')
      {
        if ((*q) == (*name) || (*val))
          goto ill_formed;
        *(*q)++ = '\0'; /* Terminate (*name).  */
        (*val) = (*q); /* Can be the empty string.  */
      }
    else if ((*val) == NULL)
      (*q)++; /* Accumulate (*name).  */
    else if (*(*q) == ';' || (*(*q) >= '0' && *(*q) <= '9'))
      (*q)++; /* Accumulate (*val).  Protect the terminal from being sent crap.  */
    else
      goto ill_formed;
}
void grepdir_loop_5(const struct stats * *ancestor, const struct stats * *stats, int *suppress_errors, const char * *dir, int *re_arg_pa1_5, int *re_arg_pa2_5)
{
    for ((*ancestor) = (*stats);  ((*ancestor) = (*ancestor)->parent) != 0;  )
      if ((*ancestor)->stat.st_ino == (*stats)->stat.st_ino
          && (*ancestor)->stat.st_dev == (*stats)->stat.st_dev)
        {
          if (!(*suppress_errors))
            error (0, 0, _("warning: %s: %s"), (*dir),
                   _("recursive directory loop"));
          { (*re_arg_pa1_5) = 0; (*re_arg_pa2_5) = 1; return; }
        }
}
void do_execute_loop_4(const char * *line_next, const char * *buf, size_t *size, unsigned char *eolbyte, const char * *start_ptr, size_t *result, execute_fp_t *execute, size_t * *match_size, int *re_arg_pa1_4, size_t *re_arg_pa2_4)
{
  for ((*line_next) = (*buf); (*line_next) < (*buf) + (*size); )
    {
      const char *line_buf = (*line_next);
      const char *line_end = memchr (line_buf, (*eolbyte), ((*buf) + (*size)) - line_buf);
      if (line_end == NULL)
        (*line_next) = line_end = (*buf) + (*size);
      else
        (*line_next) = line_end + 1;

      if ((*start_ptr) && (*start_ptr) >= line_end)
        continue;

      (*result) = (*execute) (line_buf, (*line_next) - line_buf, (*match_size), (*start_ptr));
      if ((*result) != (size_t) -1)
        { (*re_arg_pa1_4) = 0; (*re_arg_pa2_4) = (line_buf - (*buf)) + (*result); return; }
    }
}
void main_loop_9(size_t *keyalloc, size_t *keycc)
{
        for ((*keyalloc) = 1; (*keyalloc) <= (*keycc) + 1; (*keyalloc) *= 2)
          ;
}
void nlscan_loop_2(const char * *beg, const char * *lastnl, const char * *lim, unsigned char *eolbyte, size_t *newlines)
{
  for ((*beg) = (*lastnl); (*beg) < (*lim); (*beg)++)
    {
      (*beg) = memchr ((*beg), (*eolbyte), (*lim) - (*beg));
      if (!(*beg))
        break;
      (*newlines)++;
    }
}
void prepend_args_loop_7(const char * *o, int *n, char ** *argv, char * *b, int *re_arg_pa1_7, int *re_arg_pa2_7)
{
  for (;;)
    {
      while (c_isspace ((unsigned char) *(*o)))
        (*o)++;
      if (!*(*o))
        { (*re_arg_pa1_7) = 0; (*re_arg_pa2_7) = (*n); return; }
      if ((*argv))
        (*argv)[(*n)] = (*b);
      (*n)++;

      do
        if ((*(*b)++ = *(*o)++) == '\\' && *(*o))
          (*b)[-1] = *(*o)++;
      while (*(*o) && ! c_isspace ((unsigned char) *(*o)));

      *(*b)++ = '\0';
    }
}
