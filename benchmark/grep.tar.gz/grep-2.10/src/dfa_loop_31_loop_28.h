#ifndef dfa_loop_31_loop_28_h_
#define dfa_loop_31_loop_28_h_

#include "dfa_loop_31.h"
#define MATCHES_NEWLINE_CONTEXT(constraint, prevn, currn) \
  ((constraint) & 1 << (((prevn) ? 2 : 0) + ((currn) ? 1 : 0) + 4))
#define MATCHES_LETTER_CONTEXT(constraint, prevl, currl) \
  ((constraint) & 1 << (((prevl) ? 2 : 0) + ((currl) ? 1 : 0)))
#define SUCCEEDS_IN_CONTEXT(constraint, prevn, currn, prevl, currl) \
  (MATCHES_NEWLINE_CONTEXT(constraint, prevn, currn)		     \
   && MATCHES_LETTER_CONTEXT(constraint, prevl, currl))
#define PREV_NEWLINE_DEPENDENT(constraint) \
  (((constraint) & 0xc0) >> 2 != ((constraint) & 0x30))
#define PREV_LETTER_DEPENDENT(constraint) \
  (((constraint) & 0x0c) >> 2 != ((constraint) & 0x03))
#define NO_CONSTRAINT 0xff
#define BEGLINE_CONSTRAINT 0xcf
#define ENDLINE_CONSTRAINT 0xaf
#define BEGWORD_CONSTRAINT 0xf2
#define ENDWORD_CONSTRAINT 0xf4
#define LIMWORD_CONSTRAINT 0xf6
#define NOTLIMWORD_CONSTRAINT 0xf9
#define ACCEPTING(s, r) ((r).states[s].constraint)
#define ACCEPTS_IN_CONTEXT(prevn, currn, prevl, currl, state, dfa) \
  SUCCEEDS_IN_CONTEXT((dfa).states[state].constraint,		   \
                       prevn, currn, prevl, currl)
#undef XNMALLOC
#undef XCALLOC
# define XNMALLOC(n, t) \
    (sizeof (t) == 1 ? xmalloc (n) : xnmalloc (n, sizeof (t)))
# define XCALLOC(n, t) \
    (sizeof (t) == 1 ? xzalloc (n) : xcalloc (n, sizeof (t)))
#define CALLOC(p, n) do { (p) = XCALLOC (n, *(p)); } while (0)
#define MALLOC(p, n) do { (p) = XNMALLOC (n, *(p)); } while (0)
#define REALLOC(p, n) do {(p) = xnrealloc (p, n, sizeof (*(p))); } while (0)
#define REALLOC_IF_NECESSARY(p, n_alloc, n_required)		\
  do								\
    {								\
      assert (0 <= (n_required));				\
      if ((n_alloc) <= (n_required))				\
        {							\
          size_t new_n_alloc = (n_required) + !(p);		\
          (p) = x2nrealloc (p, &new_n_alloc, sizeof (*(p)));	\
          (n_alloc) = new_n_alloc;				\
        }							\
    }								\
  while (false)
#define BRACKET_BUFFER_SIZE 128
#define IS_WORD_CONSTITUENT(C) (isalnum(C) || (C) == '_')
#define SKIP_REMAINS_MB_IF_INITIAL_STATE(s, p)		\
  if (s == 0)						\
    {							\
      while (inputwcs[p - buf_begin] == 0		\
            && mblen_buf[p - buf_begin] > 0		\
            && (unsigned char const *) p < buf_end)	\
        ++p;						\
      if ((char *) p >= end)				\
        {						\
          free(mblen_buf);				\
          free(inputwcs);				\
          *end = saved_end;				\
          return NULL;					\
        }						\
    }

void state_index_loop_7_loop_22(int * *i, struct dfa ** *d, int * *hash, const position_set ** *s, int * *newline, int * *letter, int * *j, int * *re_arg_pa1_7, int * *re_arg_pa2_7, int *re_arg_pa1_22);
void match_mb_charset_loop_16_loop_18(int * *i, struct mb_char_classes ** *work_mbc, int * *op_len, char buffer[], const unsigned char ** *buf_begin, int * *idx, int * *match_len);
void transit_state_loop_20_loop_17(int * *i, int * *nelem, int ** *match_lens, int * *maxlen);
void build_state_loop_13_loop_4(int * *i, struct dfa ** *d);
void dfafree_loop_24_loop_7(int * *i, struct dfa ** *d);
void dfafree_loop_27_loop_10(struct dfamust ** *dm, struct dfa ** *d, struct dfamust ** *ndm);
void freelist_loop_29_loop_8(int * *i, char *** *cpp);
void state_index_loop_6_loop_12(int * *i, const position_set ** *s, int * *hash);
void insert_loop_3_loop_13(int * *i, int * *count, int * *lo, position_set ** *s);
void free_mbdata_loop_23_loop_21(unsigned int * *i, struct dfa ** *d);
void dfaexec_loop_22_loop_26(unsigned int * *i, int sbit[]);
void match_mb_charset_loop_15_loop_28(int * *i, struct mb_char_classes ** *work_mbc, wchar_t * *wc);
void dfamust_loop_31_loop_20(int * *i, struct dfa ** *d, must ** *mp);
void istrstr_loop_28_loop_9(const char ** *cp, const char ** *lookin, const char ** *lookfor, size_t * *len, int * *re_arg_pa1_28, char ** *re_arg_pa2_28, int *re_arg_pa1_9);
void dfamust_loop_30_loop_16(int * *i, struct dfa ** *d, must ** *mp, must * *must0);
void match_mb_charset_loop_17_loop_1(int * *i, struct mb_char_classes ** *work_mbc, int * *op_len, char buffer[], const unsigned char ** *buf_begin, int * *idx, int * *match_len);
void match_mb_charset_loop_19_loop_2(int * *i, struct mb_char_classes ** *work_mbc, wchar_t * *wc);
void dfastate_loop_12_loop_14(int * *i, int * *ngrps, position_set ** *grps);
void dfastate_loop_9_loop_24(int * *i, struct dfa ** *d, int * *wants_newline, int * *wants_letter);
void dfafree_loop_26_loop_19(int * *i, struct dfa ** *d);
void delete_loop_5_loop_25(position_set ** *s, int * *i);
void prepare_wc_buf_loop_21_loop_23(size_t * *i, const char ** *end, const char ** *begin, size_t * *remain_bytes, wchar_t ** *inputwcs, mbstate_t * *mbs, unsigned char ** *mblen_buf, unsigned char * *eol);
void find_pred_loop_2_loop_27(unsigned int * *i, const struct dfa_ctype prednames[], const char ** *str);
void match_mb_charset_loop_18_loop_6(int * *i, struct mb_char_classes ** *work_mbc, wchar_t wcbuf[]);
void dfafree_loop_25_loop_3(int * *i, struct dfa ** *d);
void build_state_loop_14_loop_5(int * *i, int ** *trans, struct dfa ** *d);
void delete_loop_4_loop_11(int * *i, position_set ** *s, position * *p);
void dfaanalyze_loop_8_loop_15(int * *i, position_set * *merged, int * *wants_newline);

#endif
