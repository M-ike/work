#include "kwset_loop_9_loop_9.h"
#ifndef DEPTH_SIZE
#define DEPTH_SIZE (CHAR_BIT + CHAR_BIT/2)

#endif

void kwsprep_loop_1_loop_1(int * *i, struct kwset ** *kwset, struct trie ** *curr)
{
for ((*(*i)) = (*(*kwset))->mind - 1, (*(*curr)) = (*(*kwset))->trie; (*(*i)) >= 0; --(*(*i)))
        {
          (*(*kwset))->target[(*(*i))] = (*(*curr))->links->label;
          (*(*curr)) = (*(*curr))->links->trie;
        }

}
void kwsprep_loop_4_loop_2(struct trie ** *curr, struct kwset ** *kwset)
{
for ((*(*curr)) = (*(*kwset))->trie->next; (*(*curr)); (*(*curr)) = (*(*curr))->next)
        {
          if ((*(*curr))->maxshift > (*(*curr))->parent->maxshift)
            (*(*curr))->maxshift = (*(*curr))->parent->maxshift;
          if ((*(*curr))->shift > (*(*curr))->maxshift)
            (*(*curr))->shift = (*(*curr))->maxshift;
        }

}
void kwsprep_loop_5_loop_3(int * *i, struct trie * next[])
{
for ((*(*i)) = 0; (*(*i)) < NCHAR; ++(*(*i)))
        (*next)[(*(*i))] = NULL;

}
void bmexec_loop_9_loop_4(int * *i, int * *len, const char ** *tp, const char ** *sp)
{
for ((*(*i)) = 3; (*(*i)) <= (*(*len)) && U((*(*tp))[-(*(*i))]) == U((*(*sp))[-(*(*i))]); ++(*(*i)))
            ;

}
void kwsprep_loop_7_loop_5(int * *i, struct kwset ** *kwset, unsigned char delta[], const char ** *trans)
{
for ((*(*i)) = 0; (*(*i)) < NCHAR; ++(*(*i)))
      (*(*kwset))->delta[(*(*i))] = (*delta)[U((*(*trans))[(*(*i))])];

}
void kwsprep_loop_3_loop_6(int * *i, struct kwset ** *kwset, char * *c)
{
for ((*(*i)) = (*(*kwset))->mind - 2; (*(*i)) >= 0; --(*(*i)))
        if ((*(*kwset))->target[(*(*i))] == (*(*c)))
          break;

}
void kwsprep_loop_6_loop_7(int * *i, struct kwset ** *kwset, struct trie * next[], const char ** *trans)
{
for ((*(*i)) = 0; (*(*i)) < NCHAR; ++(*(*i)))
          (*(*kwset))->next[(*(*i))] = (*next)[U((*(*trans))[(*(*i))])];

}
void kwsprep_loop_2_loop_8(int * *i, struct kwset ** *kwset, unsigned char delta[])
{
for ((*(*i)) = 0; (*(*i)) < (*(*kwset))->mind; ++(*(*i)))
        (*delta)[U((*(*kwset))->target[(*(*i))])] = (*(*kwset))->mind - ((*(*i)) + 1);

}
void bmexec_loop_8_loop_9(const char ** *ep, const char ** *text, size_t * *size, int * *len, const char ** *tp, int * *d, const unsigned char ** *d1, int * *gc, int * *i, const char ** *sp, int * *re_arg_pa1_8, size_t * *re_arg_pa2_8, int * *md2, int *re_arg_pa1_9)
{
for ((*(*ep)) = (*(*text)) + (*(*size)) - 11 * (*(*len));;)
      {
        while ((*(*tp)) <= (*(*ep)))
          {
            (*(*d)) = (*(*d1))[U((*(*tp))[-1])], (*(*tp)) += (*(*d));
            (*(*d)) = (*(*d1))[U((*(*tp))[-1])], (*(*tp)) += (*(*d));
            if ((*(*d)) == 0)
              goto found;
            (*(*d)) = (*(*d1))[U((*(*tp))[-1])], (*(*tp)) += (*(*d));
            (*(*d)) = (*(*d1))[U((*(*tp))[-1])], (*(*tp)) += (*(*d));
            (*(*d)) = (*(*d1))[U((*(*tp))[-1])], (*(*tp)) += (*(*d));
            if ((*(*d)) == 0)
              goto found;
            (*(*d)) = (*(*d1))[U((*(*tp))[-1])], (*(*tp)) += (*(*d));
            (*(*d)) = (*(*d1))[U((*(*tp))[-1])], (*(*tp)) += (*(*d));
            (*(*d)) = (*(*d1))[U((*(*tp))[-1])], (*(*tp)) += (*(*d));
            if ((*(*d)) == 0)
              goto found;
            (*(*d)) = (*(*d1))[U((*(*tp))[-1])], (*(*tp)) += (*(*d));
            (*(*d)) = (*(*d1))[U((*(*tp))[-1])], (*(*tp)) += (*(*d));
          }
        break;
      found:
        if (U((*(*tp))[-2]) == (*(*gc)))
          {
            for ((*(*i)) = 3; (*(*i)) <= (*(*len)) && U((*(*tp))[-(*(*i))]) == U((*(*sp))[-(*(*i))]); ++(*(*i)))
              ;
            if ((*(*i)) > (*(*len)))
              { (*(*re_arg_pa1_8)) = 0; (*(*re_arg_pa2_8)) = (*(*tp)) - (*(*len)) - (*(*text)); { (*re_arg_pa1_8_loop_9) = 0; return; } }
          }
        (*(*tp)) += (*(*md2));
      }

}
