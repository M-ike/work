#include "searchutils_loop_1_loop_1.h"
void kwsinit_loop_1(int *i, char trans[])
{
      
    kwsinit_loop_1_loop_1(&i, &trans);

}
