#include "dfa_loop_31.h"
#define MATCHES_NEWLINE_CONTEXT(constraint, prevn, currn) \
  ((constraint) & 1 << (((prevn) ? 2 : 0) + ((currn) ? 1 : 0) + 4))
#define MATCHES_LETTER_CONTEXT(constraint, prevl, currl) \
  ((constraint) & 1 << (((prevl) ? 2 : 0) + ((currl) ? 1 : 0)))
#define SUCCEEDS_IN_CONTEXT(constraint, prevn, currn, prevl, currl) \
  (MATCHES_NEWLINE_CONTEXT(constraint, prevn, currn)		     \
   && MATCHES_LETTER_CONTEXT(constraint, prevl, currl))
#define PREV_NEWLINE_DEPENDENT(constraint) \
  (((constraint) & 0xc0) >> 2 != ((constraint) & 0x30))
#define PREV_LETTER_DEPENDENT(constraint) \
  (((constraint) & 0x0c) >> 2 != ((constraint) & 0x03))
#define NO_CONSTRAINT 0xff
#define BEGLINE_CONSTRAINT 0xcf
#define ENDLINE_CONSTRAINT 0xaf
#define BEGWORD_CONSTRAINT 0xf2
#define ENDWORD_CONSTRAINT 0xf4
#define LIMWORD_CONSTRAINT 0xf6
#define NOTLIMWORD_CONSTRAINT 0xf9
#define ACCEPTING(s, r) ((r).states[s].constraint)
#define ACCEPTS_IN_CONTEXT(prevn, currn, prevl, currl, state, dfa) \
  SUCCEEDS_IN_CONTEXT((dfa).states[state].constraint,		   \
                       prevn, currn, prevl, currl)
#undef XNMALLOC
#undef XCALLOC
# define XNMALLOC(n, t) \
    (sizeof (t) == 1 ? xmalloc (n) : xnmalloc (n, sizeof (t)))
# define XCALLOC(n, t) \
    (sizeof (t) == 1 ? xzalloc (n) : xcalloc (n, sizeof (t)))
#define CALLOC(p, n) do { (p) = XCALLOC (n, *(p)); } while (0)
#define MALLOC(p, n) do { (p) = XNMALLOC (n, *(p)); } while (0)
#define REALLOC(p, n) do {(p) = xnrealloc (p, n, sizeof (*(p))); } while (0)
#define REALLOC_IF_NECESSARY(p, n_alloc, n_required)		\
  do								\
    {								\
      assert (0 <= (n_required));				\
      if ((n_alloc) <= (n_required))				\
        {							\
          size_t new_n_alloc = (n_required) + !(p);		\
          (p) = x2nrealloc (p, &new_n_alloc, sizeof (*(p)));	\
          (n_alloc) = new_n_alloc;				\
        }							\
    }								\
  while (false)
#define BRACKET_BUFFER_SIZE 128
#define IS_WORD_CONSTITUENT(C) (isalnum(C) || (C) == '_')
#define SKIP_REMAINS_MB_IF_INITIAL_STATE(s, p)		\
  if (s == 0)						\
    {							\
      while (inputwcs[p - buf_begin] == 0		\
            && mblen_buf[p - buf_begin] > 0		\
            && (unsigned char const *) p < buf_end)	\
        ++p;						\
      if ((char *) p >= end)				\
        {						\
          free(mblen_buf);				\
          free(inputwcs);				\
          *end = saved_end;				\
          return NULL;					\
        }						\
    }

void match_mb_charset_loop_17(int *i, struct mb_char_classes * *work_mbc, int *op_len, char buffer[], const unsigned char * *buf_begin, int *idx, int *match_len)
{
  for ((*i) = 0; (*i)<(*work_mbc)->ncoll_elems; (*i)++)
    {
      (*op_len) = strlen((*work_mbc)->coll_elems[(*i)]);
      strncpy(buffer, (char const *) (*buf_begin) + (*idx), (*op_len));
      buffer[(*op_len)] = '\0';

      if (strcoll((*work_mbc)->coll_elems[(*i)], buffer) == 0)
        {
          (*match_len) = (*op_len);
          goto charset_matched;
        }
    }
}
void match_mb_charset_loop_19(int *i, struct mb_char_classes * *work_mbc, wchar_t *wc)
{
  for ((*i) = 0; (*i)<(*work_mbc)->nchars; (*i)++)
    {
      if ((*wc) == (*work_mbc)->chars[(*i)])
        goto charset_matched;
    }
}
void dfafree_loop_25(int *i, struct dfa * *d)
{
  for ((*i) = 0; (*i) < (*d)->tindex; ++(*i))
    free((*d)->follows[(*i)].elems);
}
void build_state_loop_13(int *i, struct dfa * *d)
{
      for ((*i) = 0; (*i) < (*d)->tralloc; ++(*i))
        {
          free((*d)->trans[(*i)]);
          free((*d)->fails[(*i)]);
          (*d)->trans[(*i)] = (*d)->fails[(*i)] = NULL;
        }
}
void build_state_loop_14(int *i, int * *trans, struct dfa * *d)
{
  for ((*i) = 0; (*i) < NOTCHAR; ++(*i))
    if ((*trans)[(*i)] >= (*d)->tralloc)
      {
        int oldalloc = (*d)->tralloc;

        while ((*trans)[(*i)] >= (*d)->tralloc)
          (*d)->tralloc *= 2;
        REALLOC((*d)->realtrans, (*d)->tralloc + 1);
        (*d)->trans = (*d)->realtrans + 1;
        REALLOC((*d)->fails, (*d)->tralloc);
        REALLOC((*d)->success, (*d)->tralloc);
        REALLOC((*d)->newlines, (*d)->tralloc);
        while (oldalloc < (*d)->tralloc)
          {
            (*d)->trans[oldalloc] = NULL;
            (*d)->fails[oldalloc++] = NULL;
          }
      }
}
void match_mb_charset_loop_18(int *i, struct mb_char_classes * *work_mbc, wchar_t wcbuf[])
{
  for ((*i) = 0; (*i)<(*work_mbc)->nranges; (*i)++)
    {
      wcbuf[2] = (*work_mbc)->range_sts[(*i)];
      wcbuf[4] = (*work_mbc)->range_ends[(*i)];

      if (wcscoll(wcbuf, wcbuf+2) >= 0 &&
          wcscoll(wcbuf+4, wcbuf) >= 0)
        goto charset_matched;
    }
}
void dfafree_loop_24(int *i, struct dfa * *d)
{
  for ((*i) = 0; (*i) < (*d)->sindex; ++(*i)) {
    free((*d)->states[(*i)].elems.elems);
    if (MBS_SUPPORT)
      free((*d)->states[(*i)].mbps.elems);
  }
}
void freelist_loop_29(int *i, char ** *cpp)
{
  for ((*i) = 0; (*cpp)[(*i)] != NULL; ++(*i))
    {
      free((*cpp)[(*i)]);
      (*cpp)[(*i)] = NULL;
    }
}
void dfastate_loop_10(int *i, int trans[], int *state_letter, int *state)
{
      for ((*i) = 0; (*i) < NOTCHAR; ++(*i))
        (*trans)[(*i)] = (IS_WORD_CONSTITUENT((*i))) ? (*state_letter) : (*state);
}
void istrstr_loop_28(const char * *cp, const char * *lookin, const char * *lookfor, size_t *len, int *re_arg_pa1_28, char * *re_arg_pa2_28)
{
  for ((*cp) = (*lookin); *(*cp) != '\0'; ++(*cp))
    if (strncmp((*cp), (*lookfor), (*len)) == 0)
      { (*re_arg_pa1_28) = 0; (*re_arg_pa2_28) = (char *) (*cp); return; }
}
void dfafree_loop_27(struct dfamust * *dm, struct dfa * *d, struct dfamust * *ndm)
{
  for ((*dm) = (*d)->musts; (*dm); (*dm) = (*ndm))
    {
      (*ndm) = (*dm)->next;
      free((*dm)->must);
      free((*dm));
    }
}
void delete_loop_4(int *i, position_set * *s, position *p)
{
  for ((*i) = 0; (*i) < (*s)->nelem; ++(*i))
    if ((*p).index == (*s)->elems[(*i)].index)
      break;
}
void state_index_loop_6(int *i, const position_set * *s, int *hash)
{
  for ((*i) = 0; (*i) < (*s)->nelem; ++(*i))
    (*hash) ^= (*s)->elems[(*i)].index + (*s)->elems[(*i)].constraint;
}
void insert_loop_3(int *i, int *count, int *lo, position_set * *s)
{
      for ((*i) = (*count); (*i) > (*lo); (*i)--)
        (*s)->elems[(*i)] = (*s)->elems[(*i) - 1];
}
void dfastate_loop_11(int *i, int trans[])
{
    for ((*i) = 0; (*i) < NOTCHAR; ++(*i))
      (*trans)[(*i)] = -1;
}
void dfastate_loop_12(int *i, int *ngrps, position_set * *grps)
{
  for ((*i) = 0; (*i) < (*ngrps); ++(*i))
    free((*grps)[(*i)].elems);
}
void dfaanalyze_loop_8(int *i, position_set *merged, int *wants_newline)
{
  for ((*i) = 0; (*i) < (*merged).nelem; ++(*i))
    if (PREV_NEWLINE_DEPENDENT((*merged).elems[(*i)].constraint))
      (*wants_newline) = 1;
}
void dfamust_loop_30(int *i, struct dfa * *d, must * *mp, must *must0)
{
  for ((*i) = 0; (*i) <= (*d)->tindex; ++(*i))
    (*mp)[(*i)] = (*must0);
}
void transit_state_loop_20(int *i, int *nelem, int * *match_lens, int *maxlen)
{
      for ((*i) = 0; (*i) < (*nelem); (*i)++)
        /* Search the operator which match the longest string,
           in this state.  */
        {
          if ((*match_lens)[(*i)] > (*maxlen))
            (*maxlen) = (*match_lens)[(*i)];
        }
}
void match_mb_charset_loop_16(int *i, struct mb_char_classes * *work_mbc, int *op_len, char buffer[], const unsigned char * *buf_begin, int *idx, int *match_len)
{
  for ((*i) = 0; (*i)<(*work_mbc)->nequivs; (*i)++)
    {
      (*op_len) = strlen((*work_mbc)->equivs[(*i)]);
      strncpy(buffer, (char const *) (*buf_begin) + (*idx), (*op_len));
      buffer[(*op_len)] = '\0';
      if (strcoll((*work_mbc)->equivs[(*i)], buffer) == 0)
        {
          (*match_len) = (*op_len);
          goto charset_matched;
        }
    }
}
void dfafree_loop_26(int *i, struct dfa * *d)
{
  for ((*i) = 0; (*i) < (*d)->tralloc; ++(*i))
    {
      free((*d)->trans[(*i)]);
      free((*d)->fails[(*i)]);
    }
}
void dfamust_loop_31(int *i, struct dfa * *d, must * *mp)
{
  for ((*i) = 0; (*i) <= (*d)->tindex; ++(*i))
    {
      (*mp)[(*i)].in = xmalloc(sizeof *(*mp)[(*i)].in);
      (*mp)[(*i)].left = xmalloc(2);
      (*mp)[(*i)].right = xmalloc(2);
      (*mp)[(*i)].is = xmalloc(2);
      (*mp)[(*i)].left[0] = (*mp)[(*i)].right[0] = (*mp)[(*i)].is[0] = '\0';
      (*mp)[(*i)].in[0] = NULL;
    }
}
void free_mbdata_loop_23(unsigned int *i, struct dfa * *d)
{
  for ((*i) = 0; (*i) < (*d)->nmbcsets; ++(*i))
    {
      unsigned int j;
      struct mb_char_classes *p = &((*d)->mbcsets[(*i)]);
      free(p->chars);
      free(p->ch_classes);
      free(p->range_sts);
      free(p->range_ends);

      for (j = 0; j < p->nequivs; ++j)
        free(p->equivs[j]);
      free(p->equivs);

      for (j = 0; j < p->ncoll_elems; ++j)
        free(p->coll_elems[j]);
      free(p->coll_elems);
    }
}
void notset_loop_1(int *i, int s[])
{
  for ((*i) = 0; (*i) < CHARCLASS_INTS; ++(*i))
    (*s)[(*i)] = ~(*s)[(*i)];
}
void state_index_loop_7(int *i, struct dfa * *d, int *hash, const position_set * *s, int *newline, int *letter, int *j, int *re_arg_pa1_7, int *re_arg_pa2_7)
{
  for ((*i) = 0; (*i) < (*d)->sindex; ++(*i))
    {
      if ((*hash) != (*d)->states[(*i)].hash || (*s)->nelem != (*d)->states[(*i)].elems.nelem
          || (*newline) != (*d)->states[(*i)].newline || (*letter) != (*d)->states[(*i)].letter)
        continue;
      for ((*j) = 0; (*j) < (*s)->nelem; ++(*j))
        if ((*s)->elems[(*j)].constraint
            != (*d)->states[(*i)].elems.elems[(*j)].constraint
            || (*s)->elems[(*j)].index != (*d)->states[(*i)].elems.elems[(*j)].index)
          break;
      if ((*j) == (*s)->nelem)
        { (*re_arg_pa1_7) = 0; (*re_arg_pa2_7) = (*i); return; }
    }
}
void prepare_wc_buf_loop_21(size_t *i, const char * *end, const char * *begin, size_t *remain_bytes, wchar_t * *inputwcs, mbstate_t *mbs, unsigned char * *mblen_buf, unsigned char *eol)
{
  for ((*i) = 0; (*i) < (*end) - (*begin) + 1; (*i)++)
    {
      if ((*remain_bytes) == 0)
        {
          (*remain_bytes)
            = mbrtowc((*inputwcs) + (*i), (*begin) + (*i), (*end) - (*begin) - (*i) + 1, &(*mbs));
          if ((*remain_bytes) < 1
              || (*remain_bytes) == (size_t) -1
              || (*remain_bytes) == (size_t) -2
              || ((*remain_bytes) == 1 && (*inputwcs)[(*i)] == (wchar_t)(*begin)[(*i)]))
            {
              (*remain_bytes) = 0;
              (*inputwcs)[(*i)] = (wchar_t)(*begin)[(*i)];
              (*mblen_buf)[(*i)] = 0;
              if ((*begin)[(*i)] == (*eol))
                break;
            }
          else
            {
              (*mblen_buf)[(*i)] = (*remain_bytes);
              (*remain_bytes)--;
            }
        }
      else
        {
          (*mblen_buf)[(*i)] = (*remain_bytes);
          (*inputwcs)[(*i)] = 0;
          (*remain_bytes)--;
        }
    }
}
void dfastate_loop_9(int *i, struct dfa * *d, int *wants_newline, int *wants_letter)
{
      for ((*i) = 0; (*i) < (*d)->states[0].elems.nelem; ++(*i))
        {
          if (PREV_NEWLINE_DEPENDENT((*d)->states[0].elems.elems[(*i)].constraint))
            (*wants_newline) = 1;
          if (PREV_LETTER_DEPENDENT((*d)->states[0].elems.elems[(*i)].constraint))
            (*wants_letter) = 1;
        }
}
void delete_loop_5(position_set * *s, int *i)
{
    for (--(*s)->nelem; (*i) < (*s)->nelem; ++(*i))
      (*s)->elems[(*i)] = (*s)->elems[(*i) + 1];
}
void dfaexec_loop_22(unsigned int *i, int sbit[])
{
      for ((*i) = 0; (*i) < NOTCHAR; ++(*i))
        sbit[(*i)] = (IS_WORD_CONSTITUENT((*i))) ? 2 : 1;
}
void find_pred_loop_2(unsigned int *i, const struct dfa_ctype prednames[], const char * *str)
{
  for ((*i) = 0; prednames[(*i)].name; ++(*i))
    if (STREQ ((*str), prednames[(*i)].name))
      break;
}
void match_mb_charset_loop_15(int *i, struct mb_char_classes * *work_mbc, wchar_t *wc)
{
  for ((*i) = 0; (*i)<(*work_mbc)->nch_classes; (*i)++)
    {
      if (iswctype((wint_t)(*wc), (*work_mbc)->ch_classes[(*i)]))
        goto charset_matched;
    }
}
