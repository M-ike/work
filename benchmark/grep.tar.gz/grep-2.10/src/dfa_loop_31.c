#include "dfa_loop_31_loop_28.h"
void match_mb_charset_loop_17(int *i, struct mb_char_classes * *work_mbc, int *op_len, char buffer[], const unsigned char * *buf_begin, int *idx, int *match_len)
{
  
    match_mb_charset_loop_17_loop_1(&i, &work_mbc, &op_len, &buffer, &buf_begin, &idx, &match_len);

}
void match_mb_charset_loop_19(int *i, struct mb_char_classes * *work_mbc, wchar_t *wc)
{
  
    match_mb_charset_loop_19_loop_2(&i, &work_mbc, &wc);

}
void dfafree_loop_25(int *i, struct dfa * *d)
{
  
    dfafree_loop_25_loop_3(&i, &d);

}
void build_state_loop_13(int *i, struct dfa * *d)
{
      
    build_state_loop_13_loop_4(&i, &d);

}
void build_state_loop_14(int *i, int * *trans, struct dfa * *d)
{
  
    build_state_loop_14_loop_5(&i, &trans, &d);

}
void match_mb_charset_loop_18(int *i, struct mb_char_classes * *work_mbc, wchar_t wcbuf[])
{
  
    match_mb_charset_loop_18_loop_6(&i, &work_mbc, &wcbuf);

}
void dfafree_loop_24(int *i, struct dfa * *d)
{
  
    dfafree_loop_24_loop_7(&i, &d);

}
void freelist_loop_29(int *i, char ** *cpp)
{
  
    freelist_loop_29_loop_8(&i, &cpp);

}
void dfastate_loop_10(int *i, int trans[], int *state_letter, int *state)
{
      for ((*i) = 0; (*i) < NOTCHAR; ++(*i))
        (*trans)[(*i)] = (IS_WORD_CONSTITUENT((*i))) ? (*state_letter) : (*state);
}
void istrstr_loop_28(const char * *cp, const char * *lookin, const char * *lookfor, size_t *len, int *re_arg_pa1_28, char * *re_arg_pa2_28)
{
  	{ int re_arg_pa1_28_loop_9 = -1; 
    istrstr_loop_28_loop_9(&cp, &lookin, &lookfor, &len, &re_arg_pa1_28, &re_arg_pa2_28, &re_arg_pa1_9);
	if(re_arg_pa1_28_loop_9 != -1) return; }

}
void dfafree_loop_27(struct dfamust * *dm, struct dfa * *d, struct dfamust * *ndm)
{
  
    dfafree_loop_27_loop_10(&dm, &d, &ndm);

}
void delete_loop_4(int *i, position_set * *s, position *p)
{
  
    delete_loop_4_loop_11(&i, &s, &p);

}
void state_index_loop_6(int *i, const position_set * *s, int *hash)
{
  
    state_index_loop_6_loop_12(&i, &s, &hash);

}
void insert_loop_3(int *i, int *count, int *lo, position_set * *s)
{
      
    insert_loop_3_loop_13(&i, &count, &lo, &s);

}
void dfastate_loop_11(int *i, int trans[])
{
    for ((*i) = 0; (*i) < NOTCHAR; ++(*i))
      (*trans)[(*i)] = -1;
}
void dfastate_loop_12(int *i, int *ngrps, position_set * *grps)
{
  
    dfastate_loop_12_loop_14(&i, &ngrps, &grps);

}
void dfaanalyze_loop_8(int *i, position_set *merged, int *wants_newline)
{
  
    dfaanalyze_loop_8_loop_15(&i, &merged, &wants_newline);

}
void dfamust_loop_30(int *i, struct dfa * *d, must * *mp, must *must0)
{
  
    dfamust_loop_30_loop_16(&i, &d, &mp, &must0);

}
void transit_state_loop_20(int *i, int *nelem, int * *match_lens, int *maxlen)
{
      
    transit_state_loop_20_loop_17(&i, &nelem, &match_lens, &maxlen);

}
void match_mb_charset_loop_16(int *i, struct mb_char_classes * *work_mbc, int *op_len, char buffer[], const unsigned char * *buf_begin, int *idx, int *match_len)
{
  
    match_mb_charset_loop_16_loop_18(&i, &work_mbc, &op_len, &buffer, &buf_begin, &idx, &match_len);

}
void dfafree_loop_26(int *i, struct dfa * *d)
{
  
    dfafree_loop_26_loop_19(&i, &d);

}
void dfamust_loop_31(int *i, struct dfa * *d, must * *mp)
{
  
    dfamust_loop_31_loop_20(&i, &d, &mp);

}
void free_mbdata_loop_23(unsigned int *i, struct dfa * *d)
{
  
    free_mbdata_loop_23_loop_21(&i, &d);

}
void notset_loop_1(int *i, int s[])
{
  for ((*i) = 0; (*i) < CHARCLASS_INTS; ++(*i))
    (*s)[(*i)] = ~(*s)[(*i)];
}
void state_index_loop_7(int *i, struct dfa * *d, int *hash, const position_set * *s, int *newline, int *letter, int *j, int *re_arg_pa1_7, int *re_arg_pa2_7)
{
  	{ int re_arg_pa1_7_loop_22 = -1; 
    state_index_loop_7_loop_22(&i, &d, &hash, &s, &newline, &letter, &j, &re_arg_pa1_7, &re_arg_pa2_7, &re_arg_pa1_22);
	if(re_arg_pa1_7_loop_22 != -1) return; }

}
void prepare_wc_buf_loop_21(size_t *i, const char * *end, const char * *begin, size_t *remain_bytes, wchar_t * *inputwcs, mbstate_t *mbs, unsigned char * *mblen_buf, unsigned char *eol)
{
  
    prepare_wc_buf_loop_21_loop_23(&i, &end, &begin, &remain_bytes, &inputwcs, &mbs, &mblen_buf, &eol);

}
void dfastate_loop_9(int *i, struct dfa * *d, int *wants_newline, int *wants_letter)
{
      
    dfastate_loop_9_loop_24(&i, &d, &wants_newline, &wants_letter);

}
void delete_loop_5(position_set * *s, int *i)
{
    
    delete_loop_5_loop_25(&s, &i);

}
void dfaexec_loop_22(unsigned int *i, int sbit[])
{
      
    dfaexec_loop_22_loop_26(&i, &sbit);

}
void find_pred_loop_2(unsigned int *i, const struct dfa_ctype prednames[], const char * *str)
{
  
    find_pred_loop_2_loop_27(&i, &prednames, &str);

}
void match_mb_charset_loop_15(int *i, struct mb_char_classes * *work_mbc, wchar_t *wc)
{
  
    match_mb_charset_loop_15_loop_28(&i, &work_mbc, &wc);

}
