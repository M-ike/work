#include "dfa_loop_2.h"
static inline unsigned char to_uchar (char ch) { return ch; }
static int
tstbit (unsigned int b, charclass const c)
{
  return c[b / INTBITS] & 1 << b % INTBITS;
}
static void
setbit (unsigned int b, charclass c)
{
  c[b / INTBITS] |= 1 << b % INTBITS;
}
static void
clrbit (unsigned int b, charclass c)
{
  c[b / INTBITS] &= ~(1 << b % INTBITS);
}
static void
copyset (charclass const src, charclass dst)
{
  memcpy (dst, src, sizeof (charclass));
}
static void
zeroset (charclass s)
{
  memset (s, 0, sizeof (charclass));
}
static void
notset (charclass s)
{
  int i;


    notset_loop_1(&i, &s);
}
static int
equal (charclass const s1, charclass const s2)
{
  return memcmp (s1, s2, sizeof (charclass)) == 0;
}
static int
charclass_index (charclass const s)
{
  int i;

  for (i = 0; i < dfa->cindex; ++i)
    if (equal(s, dfa->charclasses[i]))
      return i;
  REALLOC_IF_NECESSARY(dfa->charclasses, dfa->calloc, dfa->cindex + 1);
  ++dfa->cindex;
  copyset(s, dfa->charclasses[i]);
  return i;
}
void
dfasyntax (reg_syntax_t bits, int fold, unsigned char eol)
{
  syntax_bits_set = 1;
  syntax_bits = bits;
  case_fold = fold;
  eolbyte = eol;
}
static bool
setbit_wc (wint_t wc, charclass c)
{
  int b = wctob (wc);
  if (b == EOF)
    return false;

  setbit (b, c);
  return true;
}
static void
setbit_c (int b, charclass c)
{
  /* Do nothing if b is invalid in this character set.  */
  if (MB_CUR_MAX > 1 && btowc (b) == WEOF)
    return;
  setbit (b, c);
}
static void
setbit_case_fold_c (int b, charclass c)
{
  if (MB_CUR_MAX > 1)
    {
      wint_t wc = btowc (b);
      if (wc == WEOF)
        return;
      setbit (b, c);
      if (case_fold && iswalpha (wc))
        setbit_wc (iswupper (wc) ? towlower (wc) : towupper (wc), c);
    }
  else
    {
      setbit (b, c);
      if (case_fold && isalpha (b))
        setbit_c (isupper (b) ? tolower (b) : toupper (b), c);
    }
}
static inline int
using_utf8 (void)
{
  static int utf8 = -1;
  if (utf8 == -1)
    {
#if defined HAVE_LANGINFO_CODESET && defined MBS_SUPPORT
      utf8 = (STREQ (nl_langinfo (CODESET), "UTF-8"));
#else
      utf8 = 0;
#endif
    }

  return utf8;
}
static const struct dfa_ctype *
find_pred (const char *str)
{
  unsigned int i;

    find_pred_loop_2(&i, prednames, &str);

  return &prednames[i];
}
static token
parse_bracket_exp (void)
{
  int invert;
  int c, c1, c2;
  charclass ccl;

  /* Used to warn about [:space:].
     Bit 0 = first character is a colon.
     Bit 1 = last character is a colon.
     Bit 2 = includes any other character but a colon.
     Bit 3 = includes ranges, char/equiv classes or collation elements.  */
  int colon_warning_state;

  wint_t wc;
  wint_t wc2;

  /* Work area to build a mb_char_classes.  */
  struct mb_char_classes *work_mbc;
  int chars_al, range_sts_al, range_ends_al, ch_classes_al,
    equivs_al, coll_elems_al;

  chars_al = 1;
  range_sts_al = range_ends_al = 0;
  ch_classes_al = equivs_al = coll_elems_al = 0;
  if (MB_CUR_MAX > 1)
    {
      REALLOC_IF_NECESSARY(dfa->mbcsets, dfa->mbcsets_alloc, dfa->nmbcsets + 1);

      /* dfa->multibyte_prop[] hold the index of dfa->mbcsets.
         We will update dfa->multibyte_prop[] in addtok(), because we can't
         decide the index in dfa->tokens[].  */

      /* Initialize work area.  */
      work_mbc = &(dfa->mbcsets[dfa->nmbcsets++]);
      memset (work_mbc, 0, sizeof *work_mbc);
    }
  else
    work_mbc = NULL;

  memset (ccl, 0, sizeof ccl);
  FETCH_WC (c, wc, _("unbalanced ["));
  if (c == '^')
    {
      FETCH_WC (c, wc, _("unbalanced ["));
      invert = 1;
    }
  else
    invert = 0;

  wint_t wc1 = 0;
  colon_warning_state = (c == ':');
  do
    {
      c1 = EOF; /* mark c1 is not initialized".  */
      colon_warning_state &= ~2;

      /* Note that if we're looking at some other [:...:] construct,
         we just treat it as a bunch of ordinary characters.  We can do
         this because we assume regex has checked for syntax errors before
         dfa is ever called. */
      if (c == '[' && (syntax_bits & RE_CHAR_CLASSES))
        {
#define BRACKET_BUFFER_SIZE 128
          char str[BRACKET_BUFFER_SIZE];
          FETCH_WC (c1, wc1, _("unbalanced ["));

          /* If pattern contains `[[:', `[[.', or `[[='.  */
          if (c1 == ':'
              /* TODO: handle `[[.' and `[[=' also for MB_CUR_MAX == 1.  */
              || (MB_CUR_MAX > 1 && (c1 == '.' || c1 == '='))
              )
            {
              size_t len = 0;
              for (;;)
                {
                  FETCH_WC (c, wc, _("unbalanced ["));
                  if ((c == c1 && *lexptr == ']') || lexleft == 0)
                    break;
                  if (len < BRACKET_BUFFER_SIZE)
                    str[len++] = c;
                  else
                    /* This is in any case an invalid class name.  */
                    str[0] = '\0';
                }
              str[len] = '\0';

              /* Fetch bracket.  */
              FETCH_WC (c, wc, _("unbalanced ["));
              if (c1 == ':')
                /* build character class.  */
                {
                  char const *class
                    = (case_fold && (STREQ  (str, "upper")
                                     || STREQ  (str, "lower"))
                                       ? "alpha"
                                       : str);
                  const struct dfa_ctype *pred = find_pred (class);
                  if (!pred)
                    dfaerror(_("invalid character class"));

                  if (MB_CUR_MAX > 1 && !pred->single_byte_only)
                    {
                      /* Store the character class as wctype_t.  */
                      wctype_t wt = wctype (class);

                      if (ch_classes_al == 0)
                        MALLOC(work_mbc->ch_classes, ++ch_classes_al);
                      REALLOC_IF_NECESSARY(work_mbc->ch_classes,
                                           ch_classes_al,
                                           work_mbc->nch_classes + 1);
                      work_mbc->ch_classes[work_mbc->nch_classes++] = wt;
                    }

                  for (c2 = 0; c2 < NOTCHAR; ++c2)
                    if (pred->func(c2))
                      setbit_case_fold_c (c2, ccl);
                }

              else if (MBS_SUPPORT && (c1 == '=' || c1 == '.'))
                {
                  char *elem;
                  MALLOC(elem, len + 1);
                  strncpy(elem, str, len + 1);

                  if (c1 == '=')
                    /* build equivalent class.  */
                    {
                      if (equivs_al == 0)
                        MALLOC(work_mbc->equivs, ++equivs_al);
                      REALLOC_IF_NECESSARY(work_mbc->equivs,
                                           equivs_al,
                                           work_mbc->nequivs + 1);
                      work_mbc->equivs[work_mbc->nequivs++] = elem;
                    }

                  if (c1 == '.')
                    /* build collating element.  */
                    {
                      if (coll_elems_al == 0)
                        MALLOC(work_mbc->coll_elems, ++coll_elems_al);
                      REALLOC_IF_NECESSARY(work_mbc->coll_elems,
                                           coll_elems_al,
                                           work_mbc->ncoll_elems + 1);
                      work_mbc->coll_elems[work_mbc->ncoll_elems++] = elem;
                    }
                }
              colon_warning_state |= 8;

              /* Fetch new lookahead character.  */
              FETCH_WC (c1, wc1, _("unbalanced ["));
              continue;
            }

          /* We treat '[' as a normal character here.  c/c1/wc/wc1
             are already set up.  */
        }

      if (c == '\\' && (syntax_bits & RE_BACKSLASH_ESCAPE_IN_LISTS))
        FETCH_WC(c, wc, _("unbalanced ["));

      if (c1 == EOF)
        FETCH_WC(c1, wc1, _("unbalanced ["));

      if (c1 == '-')
        /* build range characters.  */
        {
          FETCH_WC(c2, wc2, _("unbalanced ["));
          if (c2 == ']')
            {
              /* In the case [x-], the - is an ordinary hyphen,
                 which is left in c1, the lookahead character. */
              lexptr -= cur_mb_len;
              lexleft += cur_mb_len;
            }
        }

      if (c1 == '-' && c2 != ']')
        {
          if (c2 == '\\'
              && (syntax_bits & RE_BACKSLASH_ESCAPE_IN_LISTS))
            FETCH_WC(c2, wc2, _("unbalanced ["));

          if (MB_CUR_MAX > 1)
            {
              /* When case folding map a range, say [m-z] (or even [M-z])
                 to the pair of ranges, [m-z] [M-Z].  */
              if (range_sts_al == 0)
                {
                  MALLOC(work_mbc->range_sts, ++range_sts_al);
                  MALLOC(work_mbc->range_ends, ++range_ends_al);
                }
              REALLOC_IF_NECESSARY(work_mbc->range_sts,
                                   range_sts_al, work_mbc->nranges + 1);
              REALLOC_IF_NECESSARY(work_mbc->range_ends,
                                   range_ends_al, work_mbc->nranges + 1);
              work_mbc->range_sts[work_mbc->nranges] =
                case_fold ? towlower(wc) : (wchar_t)wc;
              work_mbc->range_ends[work_mbc->nranges++] =
                case_fold ? towlower(wc2) : (wchar_t)wc2;

#ifndef GREP
              if (case_fold && (iswalpha(wc) || iswalpha(wc2)))
                {
                  REALLOC_IF_NECESSARY(work_mbc->range_sts,
                                       range_sts_al, work_mbc->nranges + 1);
                  work_mbc->range_sts[work_mbc->nranges] = towupper(wc);
                  REALLOC_IF_NECESSARY(work_mbc->range_ends,
                                       range_ends_al, work_mbc->nranges + 1);
                  work_mbc->range_ends[work_mbc->nranges++] = towupper(wc2);
                }
#endif
            }
          else
            {
              c1 = c;
              if (case_fold)
                {
                  c1 = tolower (c1);
                  c2 = tolower (c2);
                }
              if (!hard_LC_COLLATE)
                for (c = c1; c <= c2; c++)
                  setbit_case_fold_c (c, ccl);
              else
                {
                  /* Defer to the system regex library about the meaning
                     of range expressions.  */
                  regex_t re;
                  char pattern[6] = { '[', c1, '-', c2, ']', 0 };
                  char subject[2] = { 0, 0 };
                  regcomp (&re, pattern, REG_NOSUB);
                  for (c = 0; c < NOTCHAR; ++c)
                    {
                      subject[0] = c;
                      if (!(case_fold && isupper (c))
                          && regexec (&re, subject, 0, NULL, 0) != REG_NOMATCH)
                        setbit_case_fold_c (c, ccl);
                    }
                  regfree (&re);
                }
            }

          colon_warning_state |= 8;
          FETCH_WC(c1, wc1, _("unbalanced ["));
          continue;
        }

      colon_warning_state |= (c == ':') ? 2 : 4;

      if (MB_CUR_MAX == 1)
        {
          setbit_case_fold_c (c, ccl);
          continue;
        }

      if (case_fold && iswalpha(wc))
        {
          wc = towlower(wc);
          if (!setbit_wc (wc, ccl))
            {
              REALLOC_IF_NECESSARY(work_mbc->chars, chars_al,
                                   work_mbc->nchars + 1);
              work_mbc->chars[work_mbc->nchars++] = wc;
            }
#ifdef GREP
          continue;
#else
          wc = towupper(wc);
#endif
        }
      if (!setbit_wc (wc, ccl))
        {
          REALLOC_IF_NECESSARY(work_mbc->chars, chars_al,
                               work_mbc->nchars + 1);
          work_mbc->chars[work_mbc->nchars++] = wc;
        }
    }
  while ((wc = wc1, (c = c1) != ']'));

  if (colon_warning_state == 7)
    dfawarn (_("character class syntax is [[:space:]], not [:space:]"));

  if (MB_CUR_MAX > 1)
    {
      static charclass zeroclass;
      work_mbc->invert = invert;
      work_mbc->cset = equal(ccl, zeroclass) ? -1 : charclass_index(ccl);
      return MBCSET;
    }

  if (invert)
    {
      assert(MB_CUR_MAX == 1);
      notset(ccl);
      if (syntax_bits & RE_HAT_LISTS_NOT_NEWLINE)
        clrbit(eolbyte, ccl);
    }

  return CSET + charclass_index(ccl);
}
static token
lex (void)
{
  unsigned int c, c2;
  int backslash = 0;
  charclass ccl;
  int i;

  /* Basic plan: We fetch a character.  If it's a backslash,
     we set the backslash flag and go through the loop again.
     On the plus side, this avoids having a duplicate of the
     main switch inside the backslash case.  On the minus side,
     it means that just about every case begins with
     "if (backslash) ...".  */
  for (i = 0; i < 2; ++i)
    {
      if (MB_CUR_MAX > 1)
        {
          FETCH_WC (c, wctok, NULL);
          if ((int)c == EOF)
            goto normal_char;
        }
      else
        FETCH(c, NULL);

      switch (c)
        {
        case '\\':
          if (backslash)
            goto normal_char;
          if (lexleft == 0)
            dfaerror(_("unfinished \\ escape"));
          backslash = 1;
          break;

        case '^':
          if (backslash)
            goto normal_char;
          if (syntax_bits & RE_CONTEXT_INDEP_ANCHORS
              || lasttok == END
              || lasttok == LPAREN
              || lasttok == OR)
            return lasttok = BEGLINE;
          goto normal_char;

        case '$':
          if (backslash)
            goto normal_char;
          if (syntax_bits & RE_CONTEXT_INDEP_ANCHORS
              || lexleft == 0
              || (syntax_bits & RE_NO_BK_PARENS
                  ? lexleft > 0 && *lexptr == ')'
                  : lexleft > 1 && lexptr[0] == '\\' && lexptr[1] == ')')
              || (syntax_bits & RE_NO_BK_VBAR
                  ? lexleft > 0 && *lexptr == '|'
                  : lexleft > 1 && lexptr[0] == '\\' && lexptr[1] == '|')
              || ((syntax_bits & RE_NEWLINE_ALT)
                  && lexleft > 0 && *lexptr == '\n'))
            return lasttok = ENDLINE;
          goto normal_char;

        case '1':
        case '2':
        case '3':
        case '4':
        case '5':
        case '6':
        case '7':
        case '8':
        case '9':
          if (backslash && !(syntax_bits & RE_NO_BK_REFS))
            {
              laststart = 0;
              return lasttok = BACKREF;
            }
          goto normal_char;

        case '`':
          if (backslash && !(syntax_bits & RE_NO_GNU_OPS))
            return lasttok = BEGLINE;	/* FIXME: should be beginning of string */
          goto normal_char;

        case '\'':
          if (backslash && !(syntax_bits & RE_NO_GNU_OPS))
            return lasttok = ENDLINE;	/* FIXME: should be end of string */
          goto normal_char;

        case '<':
          if (backslash && !(syntax_bits & RE_NO_GNU_OPS))
            return lasttok = BEGWORD;
          goto normal_char;

        case '>':
          if (backslash && !(syntax_bits & RE_NO_GNU_OPS))
            return lasttok = ENDWORD;
          goto normal_char;

        case 'b':
          if (backslash && !(syntax_bits & RE_NO_GNU_OPS))
            return lasttok = LIMWORD;
          goto normal_char;

        case 'B':
          if (backslash && !(syntax_bits & RE_NO_GNU_OPS))
            return lasttok = NOTLIMWORD;
          goto normal_char;

        case '?':
          if (syntax_bits & RE_LIMITED_OPS)
            goto normal_char;
          if (backslash != ((syntax_bits & RE_BK_PLUS_QM) != 0))
            goto normal_char;
          if (!(syntax_bits & RE_CONTEXT_INDEP_OPS) && laststart)
            goto normal_char;
          return lasttok = QMARK;

        case '*':
          if (backslash)
            goto normal_char;
          if (!(syntax_bits & RE_CONTEXT_INDEP_OPS) && laststart)
            goto normal_char;
          return lasttok = STAR;

        case '+':
          if (syntax_bits & RE_LIMITED_OPS)
            goto normal_char;
          if (backslash != ((syntax_bits & RE_BK_PLUS_QM) != 0))
            goto normal_char;
          if (!(syntax_bits & RE_CONTEXT_INDEP_OPS) && laststart)
            goto normal_char;
          return lasttok = PLUS;

        case '{':
          if (!(syntax_bits & RE_INTERVALS))
            goto normal_char;
          if (backslash != ((syntax_bits & RE_NO_BK_BRACES) == 0))
            goto normal_char;
          if (!(syntax_bits & RE_CONTEXT_INDEP_OPS) && laststart)
            goto normal_char;

          if (syntax_bits & RE_NO_BK_BRACES)
            {
              /* Scan ahead for a valid interval; if it's not valid,
                 treat it as a literal '{'.  */
              int lo = -1, hi = -1;
              char const *p = lexptr;
              char const *lim = p + lexleft;
              for (;  p != lim && ISASCIIDIGIT (*p);  p++)
                lo = (lo < 0 ? 0 : lo * 10) + *p - '0';
              if (p != lim && *p == ',')
                while (++p != lim && ISASCIIDIGIT (*p))
                  hi = (hi < 0 ? 0 : hi * 10) + *p - '0';
              else
                hi = lo;
              if (p == lim || *p != '}'
                  || lo < 0 || RE_DUP_MAX < hi || (0 <= hi && hi < lo))
                goto normal_char;
            }

          minrep = 0;
          /* Cases:
             {M} - exact count
             {M,} - minimum count, maximum is infinity
             {M,N} - M through N */
          FETCH(c, _("unfinished repeat count"));
          if (ISASCIIDIGIT (c))
            {
              minrep = c - '0';
              for (;;)
                {
                  FETCH(c, _("unfinished repeat count"));
                  if (! ISASCIIDIGIT (c))
                    break;
                  minrep = 10 * minrep + c - '0';
                }
            }
          else
            dfaerror(_("malformed repeat count"));
          if (c == ',')
            {
              FETCH (c, _("unfinished repeat count"));
              if (! ISASCIIDIGIT (c))
                maxrep = -1;
              else
                {
                  maxrep = c - '0';
                  for (;;)
                    {
                      FETCH (c, _("unfinished repeat count"));
                      if (! ISASCIIDIGIT (c))
                        break;
                      maxrep = 10 * maxrep + c - '0';
                    }
                  if (0 <= maxrep && maxrep < minrep)
                    dfaerror (_("malformed repeat count"));
                }
            }
          else
            maxrep = minrep;
          if (!(syntax_bits & RE_NO_BK_BRACES))
            {
              if (c != '\\')
                dfaerror(_("malformed repeat count"));
              FETCH(c, _("unfinished repeat count"));
            }
          if (c != '}')
            dfaerror(_("malformed repeat count"));
          laststart = 0;
          return lasttok = REPMN;

        case '|':
          if (syntax_bits & RE_LIMITED_OPS)
            goto normal_char;
          if (backslash != ((syntax_bits & RE_NO_BK_VBAR) == 0))
            goto normal_char;
          laststart = 1;
          return lasttok = OR;

        case '\n':
          if (syntax_bits & RE_LIMITED_OPS
              || backslash
              || !(syntax_bits & RE_NEWLINE_ALT))
            goto normal_char;
          laststart = 1;
          return lasttok = OR;

        case '(':
          if (backslash != ((syntax_bits & RE_NO_BK_PARENS) == 0))
            goto normal_char;
          ++parens;
          laststart = 1;
          return lasttok = LPAREN;

        case ')':
          if (backslash != ((syntax_bits & RE_NO_BK_PARENS) == 0))
            goto normal_char;
          if (parens == 0 && syntax_bits & RE_UNMATCHED_RIGHT_PAREN_ORD)
            goto normal_char;
          --parens;
          laststart = 0;
          return lasttok = RPAREN;

        case '.':
          if (backslash)
            goto normal_char;
          if (MB_CUR_MAX > 1)
            {
              /* In multibyte environment period must match with a single
                 character not a byte.  So we use ANYCHAR.  */
              laststart = 0;
              return lasttok = ANYCHAR;
            }
          zeroset(ccl);
          notset(ccl);
          if (!(syntax_bits & RE_DOT_NEWLINE))
            clrbit(eolbyte, ccl);
          if (syntax_bits & RE_DOT_NOT_NULL)
            clrbit('\0', ccl);
          laststart = 0;
          return lasttok = CSET + charclass_index(ccl);

        case 's':
        case 'S':
          if (!backslash || (syntax_bits & RE_NO_GNU_OPS))
            goto normal_char;
          zeroset(ccl);
          for (c2 = 0; c2 < NOTCHAR; ++c2)
            if (isspace(c2))
              setbit(c2, ccl);
          if (c == 'S')
            notset(ccl);
          laststart = 0;
          return lasttok = CSET + charclass_index(ccl);

        case 'w':
        case 'W':
          if (!backslash || (syntax_bits & RE_NO_GNU_OPS))
            goto normal_char;
          zeroset(ccl);
          for (c2 = 0; c2 < NOTCHAR; ++c2)
            if (IS_WORD_CONSTITUENT(c2))
              setbit(c2, ccl);
          if (c == 'W')
            notset(ccl);
          laststart = 0;
          return lasttok = CSET + charclass_index(ccl);

        case '[':
          if (backslash)
            goto normal_char;
          laststart = 0;
          return lasttok = parse_bracket_exp();

        default:
        normal_char:
          laststart = 0;
          /* For multibyte character sets, folding is done in atom.  Always
             return WCHAR.  */
          if (MB_CUR_MAX > 1)
            return lasttok = WCHAR;

          if (case_fold && isalpha(c))
            {
              zeroset(ccl);
              setbit_case_fold_c (c, ccl);
              return lasttok = CSET + charclass_index(ccl);
            }

          return lasttok = c;
        }
    }

  /* The above loop should consume at most a backslash
     and some other character. */
  abort();
  return END;	/* keeps pedantic compilers happy. */
}
static void
addtok_mb (token t, int mbprop)
{
  if (MB_CUR_MAX > 1)
    {
      REALLOC_IF_NECESSARY(dfa->multibyte_prop, dfa->nmultibyte_prop,
                           dfa->tindex + 1);
      dfa->multibyte_prop[dfa->tindex] = mbprop;
    }

  REALLOC_IF_NECESSARY(dfa->tokens, dfa->talloc, dfa->tindex + 1);
  dfa->tokens[dfa->tindex++] = t;

  switch (t)
    {
    case QMARK:
    case STAR:
    case PLUS:
      break;

    case CAT:
    case OR:
      --depth;
      break;

    default:
      ++dfa->nleaves;
    case EMPTY:
      ++depth;
      break;
    }
  if (depth > dfa->depth)
    dfa->depth = depth;
}
static void
addtok (token t)
{
  if (MB_CUR_MAX > 1 && t == MBCSET)
    {
      bool need_or = false;
      struct mb_char_classes *work_mbc = &dfa->mbcsets[dfa->nmbcsets - 1];

      /* Extract wide characters into alternations for better performance.
         This does not require UTF-8.  */
      if (!work_mbc->invert)
        {
          int i;
          for (i = 0; i < work_mbc->nchars; i++)
            {
              addtok_wc (work_mbc->chars[i]);
              if (need_or)
                addtok (OR);
              need_or = true;
            }
          work_mbc->nchars = 0;
        }

      /* UTF-8 allows treating a simple, non-inverted MBCSET like a CSET.  */
      if (work_mbc->invert
          || (!using_utf8() && work_mbc->cset != -1)
          || work_mbc->nchars != 0
          || work_mbc->nch_classes != 0
          || work_mbc->nranges != 0
          || work_mbc->nequivs != 0
          || work_mbc->ncoll_elems != 0)
        {
          addtok_mb (MBCSET, ((dfa->nmbcsets - 1) << 2) + 3);
          if (need_or)
            addtok (OR);
        }
      else
        {
          /* Characters have been handled above, so it is possible
             that the mbcset is empty now.  Do nothing in that case.  */
          if (work_mbc->cset != -1)
            {
              assert (using_utf8 ());
              addtok (CSET + work_mbc->cset);
              if (need_or)
                addtok (OR);
            }
        }
    }
  else
    {
      addtok_mb (t, 3);
    }
}
static void
addtok_wc (wint_t wc)
{
  unsigned char buf[MB_LEN_MAX];
  mbstate_t s;
  int i;
  memset (&s, 0, sizeof s);
  cur_mb_len = wcrtomb ((char *) buf, wc, &s);

  /* This is merely stop-gap.  When cur_mb_len is 0 or negative,
     buf[0] is undefined, yet skipping the addtok_mb call altogether
     can result in heap corruption.  */
  if (cur_mb_len <= 0)
    buf[0] = 0;

  addtok_mb(buf[0], cur_mb_len == 1 ? 3 : 1);
  for (i = 1; i < cur_mb_len; i++)
    {
      addtok_mb(buf[i], i == cur_mb_len - 1 ? 2 : 0);
      addtok(CAT);
    }
}
static void
add_utf8_anychar (void)
{
#if MBS_SUPPORT
  static const charclass utf8_classes[5] = {
      {  0,  0,  0,  0, ~0, ~0, 0, 0 },            /* 80-bf: non-lead bytes */
      { ~0, ~0, ~0, ~0, 0, 0, 0, 0 },              /* 00-7f: 1-byte sequence */
      {  0,  0,  0,  0,  0,  0, 0xfffffffcU, 0 },  /* c2-df: 2-byte sequence */
      {  0,  0,  0,  0,  0,  0,  0, 0xffff },      /* e0-ef: 3-byte sequence */
      {  0,  0,  0,  0,  0,  0,  0, 0xff0000 }     /* f0-f7: 4-byte sequence */
  };
  const unsigned int n = sizeof (utf8_classes) / sizeof (utf8_classes[0]);
  unsigned int i;

  /* Define the five character classes that are needed below.  */
  if (dfa->utf8_anychar_classes[0] == 0)
    for (i = 0; i < n; i++)
      {
        charclass c;
        copyset (utf8_classes[i], c);
        if (i == 1)
          {
            if (!(syntax_bits & RE_DOT_NEWLINE))
              clrbit (eolbyte, c);
            if (syntax_bits & RE_DOT_NOT_NULL)
              clrbit ('\0', c);
          }
        dfa->utf8_anychar_classes[i] = CSET + charclass_index(c);
      }

  /* A valid UTF-8 character is

          ([0x00-0x7f]
           |[0xc2-0xdf][0x80-0xbf]
           |[0xe0-0xef[0x80-0xbf][0x80-0xbf]
           |[0xf0-f7][0x80-0xbf][0x80-0xbf][0x80-0xbf])

     which I'll write more concisely "B|CA|DAA|EAAA".  Factor the [0x00-0x7f]
     and you get "B|(C|(D|EA)A)A".  And since the token buffer is in reverse
     Polish notation, you get "B C D E A CAT OR A CAT OR A CAT OR".  */
  for (i = 1; i < n; i++)
    addtok (dfa->utf8_anychar_classes[i]);
  while (--i > 1)
    {
      addtok (dfa->utf8_anychar_classes[0]);
      addtok (CAT);
      addtok (OR);
    }
#endif
}
static void
atom (void)
{
  if (0)
    {
      /* empty */
    }
  else if (MBS_SUPPORT && tok == WCHAR)
    {
      addtok_wc (case_fold ? towlower(wctok) : wctok);
#ifndef GREP
      if (case_fold && iswalpha(wctok))
        {
          addtok_wc (towupper(wctok));
          addtok (OR);
        }
#endif

      tok = lex();
    }
  else if (MBS_SUPPORT && tok == ANYCHAR && using_utf8())
    {
      /* For UTF-8 expand the period to a series of CSETs that define a valid
         UTF-8 character.  This avoids using the slow multibyte path.  I'm
         pretty sure it would be both profitable and correct to do it for
         any encoding; however, the optimization must be done manually as
         it is done above in add_utf8_anychar.	So, let's start with
         UTF-8: it is the most used, and the structure of the encoding
         makes the correctness more obvious.  */
      add_utf8_anychar();
      tok = lex();
    }
  else if ((tok >= 0 && tok < NOTCHAR) || tok >= CSET || tok == BACKREF
           || tok == BEGLINE || tok == ENDLINE || tok == BEGWORD
#if MBS_SUPPORT
           || tok == ANYCHAR || tok == MBCSET
#endif /* MBS_SUPPORT */
           || tok == ENDWORD || tok == LIMWORD || tok == NOTLIMWORD)
    {
      addtok(tok);
      tok = lex();
    }
  else if (tok == LPAREN)
    {
      tok = lex();
      regexp();
      if (tok != RPAREN)
        dfaerror(_("unbalanced ("));
      tok = lex();
    }
  else
    addtok(EMPTY);
}
static int
nsubtoks (int tindex)
{
  int ntoks1;

  switch (dfa->tokens[tindex - 1])
    {
    default:
      return 1;
    case QMARK:
    case STAR:
    case PLUS:
      return 1 + nsubtoks(tindex - 1);
    case CAT:
    case OR:
      ntoks1 = nsubtoks(tindex - 1);
      return 1 + ntoks1 + nsubtoks(tindex - 1 - ntoks1);
    }
}
static void
copytoks (int tindex, int ntokens)
{
  int i;

  for (i = 0; i < ntokens; ++i)
    {
      addtok(dfa->tokens[tindex + i]);
      /* Update index into multibyte csets.  */
      if (MB_CUR_MAX > 1 && dfa->tokens[tindex + i] == MBCSET)
        dfa->multibyte_prop[dfa->tindex - 1] = dfa->multibyte_prop[tindex + i];
    }
}
static void
closure (void)
{
  int tindex, ntokens, i;

  atom();
  while (tok == QMARK || tok == STAR || tok == PLUS || tok == REPMN)
    if (tok == REPMN && (minrep || maxrep))
      {
        ntokens = nsubtoks(dfa->tindex);
        tindex = dfa->tindex - ntokens;
        if (maxrep < 0)
          addtok(PLUS);
        if (minrep == 0)
          addtok(QMARK);
        for (i = 1; i < minrep; ++i)
          {
            copytoks(tindex, ntokens);
            addtok(CAT);
          }
        for (; i < maxrep; ++i)
          {
            copytoks(tindex, ntokens);
            addtok(QMARK);
            addtok(CAT);
          }
        tok = lex();
      }
    else if (tok == REPMN)
      {
        dfa->tindex -= nsubtoks(dfa->tindex);
        tok = lex();
        closure();
      }
    else
      {
        addtok(tok);
        tok = lex();
      }
}
static void
branch (void)
{
  closure();
  while (tok != RPAREN && tok != OR && tok >= 0)
    {
      closure();
      addtok(CAT);
    }
}
static void
regexp (void)
{
  branch();
  while (tok == OR)
    {
      tok = lex();
      branch();
      addtok(OR);
    }
}
void
dfaparse (char const *s, size_t len, struct dfa *d)
{
  dfa = d;
  lexptr = s;
  lexleft = len;
  lasttok = END;
  laststart = 1;
  parens = 0;
#ifdef LC_COLLATE
  hard_LC_COLLATE = hard_locale (LC_COLLATE);
#endif
  if (MB_CUR_MAX > 1)
    {
      cur_mb_len = 0;
      memset(&mbs, 0, sizeof mbs);
    }

  if (! syntax_bits_set)
    dfaerror(_("no syntax specified"));

  tok = lex();
  depth = d->depth;

  regexp();

  if (tok != END)
    dfaerror(_("unbalanced )"));

  addtok(END - d->nregexps);
  addtok(CAT);

  if (d->nregexps)
    addtok(OR);

  ++d->nregexps;
}
static void
copy (position_set const *src, position_set *dst)
{
  memcpy(dst->elems, src->elems, sizeof(dst->elems[0]) * src->nelem);
  dst->nelem = src->nelem;
}
static void
insert (position p, position_set *s)
{
  int count = s->nelem;
  int lo = 0, hi = count;
  while (lo < hi)
    {
      int mid = ((unsigned) lo + (unsigned) hi) >> 1;
      if (s->elems[mid].index > p.index)
        lo = mid + 1;
      else
        hi = mid;
    }

  if (lo < count && p.index == s->elems[lo].index)
    s->elems[lo].constraint |= p.constraint;
  else
    {
      int i;

    insert_loop_3(&i, &count, &lo, &s);
      s->elems[lo] = p;
      ++s->nelem;
    }
}
static void
merge (position_set const *s1, position_set const *s2, position_set *m)
{
  int i = 0, j = 0;

  m->nelem = 0;
  while (i < s1->nelem && j < s2->nelem)
    if (s1->elems[i].index > s2->elems[j].index)
      m->elems[m->nelem++] = s1->elems[i++];
    else if (s1->elems[i].index < s2->elems[j].index)
      m->elems[m->nelem++] = s2->elems[j++];
    else
      {
        m->elems[m->nelem] = s1->elems[i++];
        m->elems[m->nelem++].constraint |= s2->elems[j++].constraint;
      }
  while (i < s1->nelem)
    m->elems[m->nelem++] = s1->elems[i++];
  while (j < s2->nelem)
    m->elems[m->nelem++] = s2->elems[j++];
}
static void
delete (position p, position_set *s)
{
  int i;


    delete_loop_4(&i, &s, &p);
  if (i < s->nelem)

    delete_loop_5(&s, &i);
}
static int
state_index (struct dfa *d, position_set const *s, int newline, int letter)
{
  int hash = 0;
  int constraint;
  int i, j;

  newline = newline ? 1 : 0;
  letter = letter ? 1 : 0;


    state_index_loop_6(&i, &s, &hash);

  /* Try to find a state that exactly matches the proposed one. */
	{ int re_arg_pa1_7 = -1; int re_arg_pa2_7;
    state_index_loop_7(&i, &d, &hash, &s, &newline, &letter, &j, &re_arg_pa1_7, &re_arg_pa2_7);
	if(re_arg_pa1_7 != -1) return re_arg_pa2_7; }

  /* We'll have to create a new state. */
  REALLOC_IF_NECESSARY(d->states, d->salloc, d->sindex + 1);
  d->states[i].hash = hash;
  MALLOC(d->states[i].elems.elems, s->nelem);
  copy(s, &d->states[i].elems);
  d->states[i].newline = newline;
  d->states[i].letter = letter;
  d->states[i].backref = 0;
  d->states[i].constraint = 0;
  d->states[i].first_end = 0;
  if (MBS_SUPPORT)
    {
      d->states[i].mbps.nelem = 0;
      d->states[i].mbps.elems = NULL;
    }
  
    state_index_loop_1(&j, &s, &d, &constraint, &newline, &letter, &i);


  ++d->sindex;

  return i;
}
static void
epsclosure (position_set *s, struct dfa const *d)
{
  int i, j;
  char *visited;	/* array of booleans, enough to use char, not int */
  position p, old;

  CALLOC(visited, d->tindex);

  for (i = 0; i < s->nelem; ++i)
    if (d->tokens[s->elems[i].index] >= NOTCHAR
        && d->tokens[s->elems[i].index] != BACKREF
#if MBS_SUPPORT
        && d->tokens[s->elems[i].index] != ANYCHAR
        && d->tokens[s->elems[i].index] != MBCSET
#endif
        && d->tokens[s->elems[i].index] < CSET)
      {
        old = s->elems[i];
        p.constraint = old.constraint;
        delete(s->elems[i], s);
        if (visited[old.index])
          {
            --i;
            continue;
          }
        visited[old.index] = 1;
        switch (d->tokens[old.index])
          {
          case BEGLINE:
            p.constraint &= BEGLINE_CONSTRAINT;
            break;
          case ENDLINE:
            p.constraint &= ENDLINE_CONSTRAINT;
            break;
          case BEGWORD:
            p.constraint &= BEGWORD_CONSTRAINT;
            break;
          case ENDWORD:
            p.constraint &= ENDWORD_CONSTRAINT;
            break;
          case LIMWORD:
            p.constraint &= LIMWORD_CONSTRAINT;
            break;
          case NOTLIMWORD:
            p.constraint &= NOTLIMWORD_CONSTRAINT;
            break;
          default:
            break;
          }
        for (j = 0; j < d->follows[old.index].nelem; ++j)
          {
            p.index = d->follows[old.index].elems[j].index;
            insert(p, s);
          }
        /* Force rescan to start at the beginning. */
        i = -1;
      }

  free(visited);
}
void
dfaanalyze (struct dfa *d, int searchflag)
{
  int *nullable;		/* Nullable stack. */
  int *nfirstpos;		/* Element count stack for firstpos sets. */
  position *firstpos;		/* Array where firstpos elements are stored. */
  int *nlastpos;		/* Element count stack for lastpos sets. */
  position *lastpos;		/* Array where lastpos elements are stored. */
  int *nalloc;			/* Sizes of arrays allocated to follow sets. */
  position_set tmp;		/* Temporary set for merging sets. */
  position_set merged;		/* Result of merging sets. */
  int wants_newline;		/* True if some position wants newline info. */
  int *o_nullable;
  int *o_nfirst, *o_nlast;
  position *o_firstpos, *o_lastpos;
  int i, j;
  position *pos;

#ifdef DEBUG
  fprintf(stderr, "dfaanalyze:\n");
  for (i = 0; i < d->tindex; ++i)
    {
      fprintf(stderr, " %d:", i);
      prtok(d->tokens[i]);
    }
  putc('\n', stderr);
#endif

  d->searchflag = searchflag;

  MALLOC(nullable, d->depth);
  o_nullable = nullable;
  MALLOC(nfirstpos, d->depth);
  o_nfirst = nfirstpos;
  MALLOC(firstpos, d->nleaves);
  o_firstpos = firstpos, firstpos += d->nleaves;
  MALLOC(nlastpos, d->depth);
  o_nlast = nlastpos;
  MALLOC(lastpos, d->nleaves);
  o_lastpos = lastpos, lastpos += d->nleaves;
  CALLOC(nalloc, d->tindex);
  MALLOC(merged.elems, d->nleaves);

  CALLOC(d->follows, d->tindex);

  for (i = 0; i < d->tindex; ++i)
#ifdef DEBUG
    {				/* Nonsyntactic #ifdef goo... */
#endif
    switch (d->tokens[i])
      {
      case EMPTY:
        /* The empty set is nullable. */
        *nullable++ = 1;

        /* The firstpos and lastpos of the empty leaf are both empty. */
        *nfirstpos++ = *nlastpos++ = 0;
        break;

      case STAR:
      case PLUS:
        /* Every element in the firstpos of the argument is in the follow
           of every element in the lastpos. */
        tmp.nelem = nfirstpos[-1];
        tmp.elems = firstpos;
        pos = lastpos;
        for (j = 0; j < nlastpos[-1]; ++j)
          {
            merge(&tmp, &d->follows[pos[j].index], &merged);
            REALLOC_IF_NECESSARY(d->follows[pos[j].index].elems,
                                 nalloc[pos[j].index], merged.nelem);
            copy(&merged, &d->follows[pos[j].index]);
          }

      case QMARK:
        /* A QMARK or STAR node is automatically nullable. */
        if (d->tokens[i] != PLUS)
          nullable[-1] = 1;
        break;

      case CAT:
        /* Every element in the firstpos of the second argument is in the
           follow of every element in the lastpos of the first argument. */
        tmp.nelem = nfirstpos[-1];
        tmp.elems = firstpos;
        pos = lastpos + nlastpos[-1];
        for (j = 0; j < nlastpos[-2]; ++j)
          {
            merge(&tmp, &d->follows[pos[j].index], &merged);
            REALLOC_IF_NECESSARY(d->follows[pos[j].index].elems,
                                 nalloc[pos[j].index], merged.nelem);
            copy(&merged, &d->follows[pos[j].index]);
          }

        /* The firstpos of a CAT node is the firstpos of the first argument,
           union that of the second argument if the first is nullable. */
        if (nullable[-2])
          nfirstpos[-2] += nfirstpos[-1];
        else
          firstpos += nfirstpos[-1];
        --nfirstpos;

        /* The lastpos of a CAT node is the lastpos of the second argument,
           union that of the first argument if the second is nullable. */
        if (nullable[-1])
          nlastpos[-2] += nlastpos[-1];
        else
          {
            pos = lastpos + nlastpos[-2];
            for (j = nlastpos[-1] - 1; j >= 0; --j)
              pos[j] = lastpos[j];
            lastpos += nlastpos[-2];
            nlastpos[-2] = nlastpos[-1];
          }
        --nlastpos;

        /* A CAT node is nullable if both arguments are nullable. */
        nullable[-2] = nullable[-1] && nullable[-2];
        --nullable;
        break;

      case OR:
        /* The firstpos is the union of the firstpos of each argument. */
        nfirstpos[-2] += nfirstpos[-1];
        --nfirstpos;

        /* The lastpos is the union of the lastpos of each argument. */
        nlastpos[-2] += nlastpos[-1];
        --nlastpos;

        /* An OR node is nullable if either argument is nullable. */
        nullable[-2] = nullable[-1] || nullable[-2];
        --nullable;
        break;

      default:
        /* Anything else is a nonempty position.  (Note that special
           constructs like \< are treated as nonempty strings here;
           an "epsilon closure" effectively makes them nullable later.
           Backreferences have to get a real position so we can detect
           transitions on them later.  But they are nullable. */
        *nullable++ = d->tokens[i] == BACKREF;

        /* This position is in its own firstpos and lastpos. */
        *nfirstpos++ = *nlastpos++ = 1;
        --firstpos, --lastpos;
        firstpos->index = lastpos->index = i;
        firstpos->constraint = lastpos->constraint = NO_CONSTRAINT;

        /* Allocate the follow set for this position. */
        nalloc[i] = 1;
        MALLOC(d->follows[i].elems, nalloc[i]);
        break;
      }
#ifdef DEBUG
    /* ... balance the above nonsyntactic #ifdef goo... */
      fprintf(stderr, "node %d:", i);
      prtok(d->tokens[i]);
      putc('\n', stderr);
      fprintf(stderr, nullable[-1] ? " nullable: yes\n" : " nullable: no\n");
      fprintf(stderr, " firstpos:");
      for (j = nfirstpos[-1] - 1; j >= 0; --j)
        {
          fprintf(stderr, " %d:", firstpos[j].index);
          prtok(d->tokens[firstpos[j].index]);
        }
      fprintf(stderr, "\n lastpos:");
      for (j = nlastpos[-1] - 1; j >= 0; --j)
        {
          fprintf(stderr, " %d:", lastpos[j].index);
          prtok(d->tokens[lastpos[j].index]);
        }
      putc('\n', stderr);
    }
#endif

  /* For each follow set that is the follow set of a real position, replace
     it with its epsilon closure. */
  for (i = 0; i < d->tindex; ++i)
    if (d->tokens[i] < NOTCHAR || d->tokens[i] == BACKREF
#if MBS_SUPPORT
        || d->tokens[i] == ANYCHAR
        || d->tokens[i] == MBCSET
#endif
        || d->tokens[i] >= CSET)
      {
#ifdef DEBUG
        fprintf(stderr, "follows(%d:", i);
        prtok(d->tokens[i]);
        fprintf(stderr, "):");
        for (j = d->follows[i].nelem - 1; j >= 0; --j)
          {
            fprintf(stderr, " %d:", d->follows[i].elems[j].index);
            prtok(d->tokens[d->follows[i].elems[j].index]);
          }
        putc('\n', stderr);
#endif
        copy(&d->follows[i], &merged);
        epsclosure(&merged, d);
        if (d->follows[i].nelem < merged.nelem)
          REALLOC(d->follows[i].elems, merged.nelem);
        copy(&merged, &d->follows[i]);
      }

  /* Get the epsilon closure of the firstpos of the regexp.  The result will
     be the set of positions of state 0. */
  merged.nelem = 0;
  for (i = 0; i < nfirstpos[-1]; ++i)
    insert(firstpos[i], &merged);
  epsclosure(&merged, d);

  /* Check if any of the positions of state 0 will want newline context. */
  wants_newline = 0;

    dfaanalyze_loop_8(&i, &merged, &wants_newline);

  /* Build the initial state. */
  d->salloc = 1;
  d->sindex = 0;
  MALLOC(d->states, d->salloc);
  state_index(d, &merged, wants_newline, 0);

  free(o_nullable);
  free(o_nfirst);
  free(o_firstpos);
  free(o_nlast);
  free(o_lastpos);
  free(nalloc);
  free(merged.elems);
}
void
dfastate (int s, struct dfa *d, int trans[])
{
  position_set *grps;		/* As many as will ever be needed. */
  charclass *labels;		/* Labels corresponding to the groups. */
  int ngrps = 0;		/* Number of groups actually used. */
  position pos;			/* Current position being considered. */
  charclass matches;		/* Set of matching characters. */
  int matchesf;			/* True if matches is nonempty. */
  charclass intersect;		/* Intersection with some label set. */
  int intersectf;		/* True if intersect is nonempty. */
  charclass leftovers;		/* Stuff in the label that didn't match. */
  int leftoversf;		/* True if leftovers is nonempty. */
  static charclass letters;	/* Set of characters considered letters. */
  static charclass newline;	/* Set of characters that aren't newline. */
  position_set follows;		/* Union of the follows of some group. */
  position_set tmp;		/* Temporary space for merging sets. */
  int state;			/* New state. */
  int wants_newline;		/* New state wants to know newline context. */
  int state_newline;		/* New state on a newline transition. */
  int wants_letter;		/* New state wants to know letter context. */
  int state_letter;		/* New state on a letter transition. */
  static int initialized;	/* Flag for static initialization. */
  int next_isnt_1st_byte = 0;	/* Flag if we can't add state0.  */
  int i, j, k;

  grps = xnmalloc (NOTCHAR, sizeof *grps);
  labels = xnmalloc (NOTCHAR, sizeof *labels);

  /* Initialize the set of letters, if necessary. */
  if (! initialized)
    {
      initialized = 1;
      for (i = 0; i < NOTCHAR; ++i)
        if (IS_WORD_CONSTITUENT(i))
          setbit(i, letters);
      setbit(eolbyte, newline);
    }

  zeroset(matches);

  for (i = 0; i < d->states[s].elems.nelem; ++i)
    {
      pos = d->states[s].elems.elems[i];
      if (d->tokens[pos.index] >= 0 && d->tokens[pos.index] < NOTCHAR)
        setbit(d->tokens[pos.index], matches);
      else if (d->tokens[pos.index] >= CSET)
        copyset(d->charclasses[d->tokens[pos.index] - CSET], matches);
      else if (MBS_SUPPORT
               && (d->tokens[pos.index] == ANYCHAR
                   || d->tokens[pos.index] == MBCSET))
        /* MB_CUR_MAX > 1  */
        {
          /* ANYCHAR and MBCSET must match with a single character, so we
             must put it to d->states[s].mbps, which contains the positions
             which can match with a single character not a byte.  */
          if (d->states[s].mbps.nelem == 0)
            {
              MALLOC(d->states[s].mbps.elems, d->states[s].elems.nelem);
            }
          insert(pos, &(d->states[s].mbps));
          continue;
        }
      else
        continue;

      /* Some characters may need to be eliminated from matches because
         they fail in the current context. */
      if (pos.constraint != 0xFF)
        {
          if (! MATCHES_NEWLINE_CONTEXT(pos.constraint,
                                         d->states[s].newline, 1))
            clrbit(eolbyte, matches);
          if (! MATCHES_NEWLINE_CONTEXT(pos.constraint,
                                         d->states[s].newline, 0))
            for (j = 0; j < CHARCLASS_INTS; ++j)
              matches[j] &= newline[j];
          if (! MATCHES_LETTER_CONTEXT(pos.constraint,
                                        d->states[s].letter, 1))
            for (j = 0; j < CHARCLASS_INTS; ++j)
              matches[j] &= ~letters[j];
          if (! MATCHES_LETTER_CONTEXT(pos.constraint,
                                        d->states[s].letter, 0))
            for (j = 0; j < CHARCLASS_INTS; ++j)
              matches[j] &= letters[j];

          /* If there are no characters left, there's no point in going on. */
          for (j = 0; j < CHARCLASS_INTS && !matches[j]; ++j)
            continue;
          if (j == CHARCLASS_INTS)
            continue;
        }

      for (j = 0; j < ngrps; ++j)
        {
          /* If matches contains a single character only, and the current
             group's label doesn't contain that character, go on to the
             next group. */
          if (d->tokens[pos.index] >= 0 && d->tokens[pos.index] < NOTCHAR
              && !tstbit(d->tokens[pos.index], labels[j]))
            continue;

          /* Check if this group's label has a nonempty intersection with
             matches. */
          intersectf = 0;
          for (k = 0; k < CHARCLASS_INTS; ++k)
            (intersect[k] = matches[k] & labels[j][k]) ? (intersectf = 1) : 0;
          if (! intersectf)
            continue;

          /* It does; now find the set differences both ways. */
          leftoversf = matchesf = 0;
          for (k = 0; k < CHARCLASS_INTS; ++k)
            {
              /* Even an optimizing compiler can't know this for sure. */
              int match = matches[k], label = labels[j][k];

              (leftovers[k] = ~match & label) ? (leftoversf = 1) : 0;
              (matches[k] = match & ~label) ? (matchesf = 1) : 0;
            }

          /* If there were leftovers, create a new group labeled with them. */
          if (leftoversf)
            {
              copyset(leftovers, labels[ngrps]);
              copyset(intersect, labels[j]);
              MALLOC(grps[ngrps].elems, d->nleaves);
              copy(&grps[j], &grps[ngrps]);
              ++ngrps;
            }

          /* Put the position in the current group.  Note that there is no
             reason to call insert() here. */
          grps[j].elems[grps[j].nelem++] = pos;

          /* If every character matching the current position has been
             accounted for, we're done. */
          if (! matchesf)
            break;
        }

      /* If we've passed the last group, and there are still characters
         unaccounted for, then we'll have to create a new group. */
      if (j == ngrps)
        {
          copyset(matches, labels[ngrps]);
          zeroset(matches);
          MALLOC(grps[ngrps].elems, d->nleaves);
          grps[ngrps].nelem = 1;
          grps[ngrps].elems[0] = pos;
          ++ngrps;
        }
    }

  MALLOC(follows.elems, d->nleaves);
  MALLOC(tmp.elems, d->nleaves);

  /* If we are a searching matcher, the default transition is to a state
     containing the positions of state 0, otherwise the default transition
     is to fail miserably. */
  if (d->searchflag)
    {
      wants_newline = 0;
      wants_letter = 0;

    dfastate_loop_9(&i, &d, &wants_newline, &wants_letter);
      copy(&d->states[0].elems, &follows);
      state = state_index(d, &follows, 0, 0);
      if (wants_newline)
        state_newline = state_index(d, &follows, 1, 0);
      else
        state_newline = state;
      if (wants_letter)
        state_letter = state_index(d, &follows, 0, 1);
      else
        state_letter = state;

    dfastate_loop_10(&i, &trans, &state_letter, &state);
      trans[eolbyte] = state_newline;
    }
  else

    dfastate_loop_11(&i, &trans);

  for (i = 0; i < ngrps; ++i)
    {
      follows.nelem = 0;

      /* Find the union of the follows of the positions of the group.
         This is a hideously inefficient loop.  Fix it someday. */
      for (j = 0; j < grps[i].nelem; ++j)
        for (k = 0; k < d->follows[grps[i].elems[j].index].nelem; ++k)
          insert(d->follows[grps[i].elems[j].index].elems[k], &follows);

      if (d->mb_cur_max > 1)
        {
          /* If a token in follows.elems is not 1st byte of a multibyte
             character, or the states of follows must accept the bytes
             which are not 1st byte of the multibyte character.
             Then, if a state of follows encounter a byte, it must not be
             a 1st byte of a multibyte character nor single byte character.
             We cansel to add state[0].follows to next state, because
             state[0] must accept 1st-byte

             For example, we assume <sb a> is a certain single byte
             character, <mb A> is a certain multibyte character, and the
             codepoint of <sb a> equals the 2nd byte of the codepoint of
             <mb A>.
             When state[0] accepts <sb a>, state[i] transit to state[i+1]
             by accepting accepts 1st byte of <mb A>, and state[i+1]
             accepts 2nd byte of <mb A>, if state[i+1] encounter the
             codepoint of <sb a>, it must not be <sb a> but 2nd byte of
             <mb A>, so we cannot add state[0].  */

          next_isnt_1st_byte = 0;
          for (j = 0; j < follows.nelem; ++j)
            {
              if (!(d->multibyte_prop[follows.elems[j].index] & 1))
                {
                  next_isnt_1st_byte = 1;
                  break;
                }
            }
        }

      /* If we are building a searching matcher, throw in the positions
         of state 0 as well. */
      if (d->searchflag
          && (! MBS_SUPPORT
              || (d->mb_cur_max == 1 || !next_isnt_1st_byte)))
        for (j = 0; j < d->states[0].elems.nelem; ++j)
          insert(d->states[0].elems.elems[j], &follows);

      /* Find out if the new state will want any context information. */
      wants_newline = 0;
      if (tstbit(eolbyte, labels[i]))
        for (j = 0; j < follows.nelem; ++j)
          if (PREV_NEWLINE_DEPENDENT(follows.elems[j].constraint))
            wants_newline = 1;

      wants_letter = 0;
      for (j = 0; j < CHARCLASS_INTS; ++j)
        if (labels[i][j] & letters[j])
          break;
      if (j < CHARCLASS_INTS)
        for (j = 0; j < follows.nelem; ++j)
          if (PREV_LETTER_DEPENDENT(follows.elems[j].constraint))
            wants_letter = 1;

      /* Find the state(s) corresponding to the union of the follows. */
      state = state_index(d, &follows, 0, 0);
      if (wants_newline)
        state_newline = state_index(d, &follows, 1, 0);
      else
        state_newline = state;
      if (wants_letter)
        state_letter = state_index(d, &follows, 0, 1);
      else
        state_letter = state;

      /* Set the transitions for each character in the current label. */
      for (j = 0; j < CHARCLASS_INTS; ++j)
        for (k = 0; k < INTBITS; ++k)
          if (labels[i][j] & 1 << k)
            {
              int c = j * INTBITS + k;

              if (c == eolbyte)
                trans[c] = state_newline;
              else if (IS_WORD_CONSTITUENT(c))
                trans[c] = state_letter;
              else if (c < NOTCHAR)
                trans[c] = state;
            }
    }


    dfastate_loop_12(&i, &ngrps, &grps);
  free(follows.elems);
  free(tmp.elems);
  free(grps);
  free(labels);
}
static void
build_state (int s, struct dfa *d)
{
  int *trans;			/* The new transition table. */
  int i;

  /* Set an upper limit on the number of transition tables that will ever
     exist at once.  1024 is arbitrary.  The idea is that the frequently
     used transition tables will be quickly rebuilt, whereas the ones that
     were only needed once or twice will be cleared away. */
  if (d->trcount >= 1024)
    {

    build_state_loop_13(&i, &d);
      d->trcount = 0;
    }

  ++d->trcount;

  /* Set up the success bits for this state. */
  d->success[s] = 0;
  if (ACCEPTS_IN_CONTEXT(d->states[s].newline, 1, d->states[s].letter, 0,
      s, *d))
    d->success[s] |= 4;
  if (ACCEPTS_IN_CONTEXT(d->states[s].newline, 0, d->states[s].letter, 1,
      s, *d))
    d->success[s] |= 2;
  if (ACCEPTS_IN_CONTEXT(d->states[s].newline, 0, d->states[s].letter, 0,
      s, *d))
    d->success[s] |= 1;

  MALLOC(trans, NOTCHAR);
  dfastate(s, d, trans);

  /* Now go through the new transition table, and make sure that the trans
     and fail arrays are allocated large enough to hold a pointer for the
     largest state mentioned in the table. */

    build_state_loop_14(&i, &trans, &d);

  /* Keep the newline transition in a special place so we can use it as
     a sentinel. */
  d->newlines[s] = trans[eolbyte];
  trans[eolbyte] = -1;

  if (ACCEPTING(s, *d))
    d->fails[s] = trans;
  else
    d->trans[s] = trans;
}
static void
build_state_zero (struct dfa *d)
{
  d->tralloc = 1;
  d->trcount = 0;
  CALLOC(d->realtrans, d->tralloc + 1);
  d->trans = d->realtrans + 1;
  CALLOC(d->fails, d->tralloc);
  MALLOC(d->success, d->tralloc);
  MALLOC(d->newlines, d->tralloc);
  build_state(0, d);
}
static void
realloc_trans_if_necessary(struct dfa *d, int new_state)
{
  /* Make sure that the trans and fail arrays are allocated large enough
     to hold a pointer for the new state. */
  if (new_state >= d->tralloc)
    {
      int oldalloc = d->tralloc;

      while (new_state >= d->tralloc)
        d->tralloc *= 2;
      REALLOC(d->realtrans, d->tralloc + 1);
      d->trans = d->realtrans + 1;
      REALLOC(d->fails, d->tralloc);
      REALLOC(d->success, d->tralloc);
      REALLOC(d->newlines, d->tralloc);
      while (oldalloc < d->tralloc)
        {
          d->trans[oldalloc] = NULL;
          d->fails[oldalloc++] = NULL;
        }
    }
}
static status_transit_state
transit_state_singlebyte (struct dfa *d, int s, unsigned char const *p,
                                  int *next_state)
{
  int *t;
  int works = s;

  status_transit_state rval = TRANSIT_STATE_IN_PROGRESS;

  while (rval == TRANSIT_STATE_IN_PROGRESS)
    {
      if ((t = d->trans[works]) != NULL)
        {
          works = t[*p];
          rval = TRANSIT_STATE_DONE;
          if (works < 0)
            works = 0;
        }
      else if (works < 0)
        {
          if (p == buf_end)
            {
              /* At the moment, it must not happen.  */
              abort ();
            }
          works = 0;
        }
      else if (d->fails[works])
        {
          works = d->fails[works][*p];
          rval = TRANSIT_STATE_DONE;
        }
      else
        {
          build_state(works, d);
        }
    }
  *next_state = works;
  return rval;
}
static int
match_anychar (struct dfa *d, int s, position pos, int idx)
{
  int newline = 0;
  int letter = 0;
  wchar_t wc;
  int mbclen;

  wc = inputwcs[idx];
  mbclen = (mblen_buf[idx] == 0)? 1 : mblen_buf[idx];

  /* Check context.  */
  if (wc == (wchar_t)eolbyte)
    {
      if (!(syntax_bits & RE_DOT_NEWLINE))
        return 0;
      newline = 1;
    }
  else if (wc == (wchar_t)'\0')
    {
      if (syntax_bits & RE_DOT_NOT_NULL)
        return 0;
      newline = 1;
    }

  if (iswalnum(wc) || wc == L'_')
    letter = 1;

  if (!SUCCEEDS_IN_CONTEXT(pos.constraint, d->states[s].newline,
                           newline, d->states[s].letter, letter))
    return 0;

  return mbclen;
}
static int
match_mb_charset (struct dfa *d, int s, position pos, int idx)
{
  int i;
  int match;		/* Flag which represent that matching succeed.  */
  int match_len;	/* Length of the character (or collating element)
                           with which this operator match.  */
  int op_len;		/* Length of the operator.  */
  char buffer[128];
  wchar_t wcbuf[6];

  /* Pointer to the structure to which we are currently refering.  */
  struct mb_char_classes *work_mbc;

  int newline = 0;
  int letter = 0;
  wchar_t wc;		/* Current refering character.  */

  wc = inputwcs[idx];

  /* Check context.  */
  if (wc == (wchar_t)eolbyte)
    {
      if (!(syntax_bits & RE_DOT_NEWLINE))
        return 0;
      newline = 1;
    }
  else if (wc == (wchar_t)'\0')
    {
      if (syntax_bits & RE_DOT_NOT_NULL)
        return 0;
      newline = 1;
    }
  if (iswalnum(wc) || wc == L'_')
    letter = 1;
  if (!SUCCEEDS_IN_CONTEXT(pos.constraint, d->states[s].newline,
                           newline, d->states[s].letter, letter))
    return 0;

  /* Assign the current refering operator to work_mbc.  */
  work_mbc = &(d->mbcsets[(d->multibyte_prop[pos.index]) >> 2]);
  match = !work_mbc->invert;
  match_len = (mblen_buf[idx] == 0)? 1 : mblen_buf[idx];

  /* Match in range 0-255?  */
  if (wc < NOTCHAR && work_mbc->cset != -1
      && tstbit((unsigned char)wc, d->charclasses[work_mbc->cset]))
    goto charset_matched;

  /* match with a character class?  */

    match_mb_charset_loop_15(&i, &work_mbc, &wc);

  strncpy(buffer, (char const *) buf_begin + idx, match_len);
  buffer[match_len] = '\0';

  /* match with an equivalent class?  */

    match_mb_charset_loop_16(&i, &work_mbc, &op_len, buffer, &buf_begin, &idx, &match_len);

  /* match with a collating element?  */

    match_mb_charset_loop_17(&i, &work_mbc, &op_len, buffer, &buf_begin, &idx, &match_len);

  wcbuf[0] = wc;
  wcbuf[1] = wcbuf[3] = wcbuf[5] = '\0';

  /* match with a range?  */

    match_mb_charset_loop_18(&i, &work_mbc, wcbuf);

  /* match with a character?  */

    match_mb_charset_loop_19(&i, &work_mbc, &wc);

  match = !match;

 charset_matched:
  return match ? match_len : 0;
}
static int*
check_matching_with_multibyte_ops (struct dfa *d, int s, int idx)
{
  int i;
  int* rarray;

  MALLOC(rarray, d->states[s].mbps.nelem);
  for (i = 0; i < d->states[s].mbps.nelem; ++i)
    {
      position pos = d->states[s].mbps.elems[i];
      switch(d->tokens[pos.index])
        {
        case ANYCHAR:
          rarray[i] = match_anychar(d, s, pos, idx);
          break;
        case MBCSET:
          rarray[i] = match_mb_charset(d, s, pos, idx);
          break;
        default:
          break; /* cannot happen.  */
        }
    }
  return rarray;
}
static status_transit_state
transit_state_consume_1char (struct dfa *d, int s, unsigned char const **pp,
                             int *match_lens, int *mbclen, position_set *pps)
{
  int i, j;
  int s1, s2;
  int* work_mbls;
  status_transit_state rs = TRANSIT_STATE_DONE;

  /* Calculate the length of the (single/multi byte) character
     to which p points.  */
  *mbclen = (mblen_buf[*pp - buf_begin] == 0)? 1
    : mblen_buf[*pp - buf_begin];

  /* Calculate the state which can be reached from the state `s' by
     consuming `*mbclen' single bytes from the buffer.  */
  s1 = s;
  for (i = 0; i < *mbclen; i++)
    {
      s2 = s1;
      rs = transit_state_singlebyte(d, s2, (*pp)++, &s1);
    }
  /* Copy the positions contained by `s1' to the set `pps'.  */
  copy(&(d->states[s1].elems), pps);

  /* Check (inputed)match_lens, and initialize if it is NULL.  */
  if (match_lens == NULL && d->states[s].mbps.nelem != 0)
    work_mbls = check_matching_with_multibyte_ops(d, s, *pp - buf_begin);
  else
    work_mbls = match_lens;

  /* Add all of the positions which can be reached from `s' by consuming
     a single character.  */
  for (i = 0; i < d->states[s].mbps.nelem ; i++)
   {
      if (work_mbls[i] == *mbclen)
        for (j = 0; j < d->follows[d->states[s].mbps.elems[i].index].nelem;
             j++)
          insert(d->follows[d->states[s].mbps.elems[i].index].elems[j],
                 pps);
    }

  if (match_lens == NULL && work_mbls != NULL)
    free(work_mbls);
  return rs;
}
static int
transit_state (struct dfa *d, int s, unsigned char const **pp)
{
  int s1;
  int mbclen;		/* The length of current input multibyte character. */
  int maxlen = 0;
  int i, j;
  int *match_lens = NULL;
  int nelem = d->states[s].mbps.nelem; /* Just a alias.  */
  position_set follows;
  unsigned char const *p1 = *pp;
  wchar_t wc;

  if (nelem > 0)
    /* This state has (a) multibyte operator(s).
       We check whether each of them can match or not.  */
    {
      /* Note: caller must free the return value of this function.  */
      match_lens = check_matching_with_multibyte_ops(d, s, *pp - buf_begin);


    transit_state_loop_20(&i, &nelem, &match_lens, &maxlen);
    }

  if (nelem == 0 || maxlen == 0)
    /* This state has no multibyte operator which can match.
       We need to check only one single byte character.  */
    {
      status_transit_state rs;
      rs = transit_state_singlebyte(d, s, *pp, &s1);

      /* We must update the pointer if state transition succeeded.  */
      if (rs == TRANSIT_STATE_DONE)
        ++*pp;

      free(match_lens);
      return s1;
    }

  /* This state has some operators which can match a multibyte character.  */
  follows.nelem = 0;
  MALLOC(follows.elems, d->nleaves);

  /* `maxlen' may be longer than the length of a character, because it may
     not be a character but a (multi character) collating element.
     We enumerate all of the positions which `s' can reach by consuming
     `maxlen' bytes.  */
  transit_state_consume_1char(d, s, pp, match_lens, &mbclen, &follows);

  wc = inputwcs[*pp - mbclen - buf_begin];
  s1 = state_index(d, &follows, wc == L'\n', iswalnum(wc));
  realloc_trans_if_necessary(d, s1);

  while (*pp - p1 < maxlen)
    {
      follows.nelem = 0;
      transit_state_consume_1char(d, s1, pp, NULL, &mbclen, &follows);

      for (i = 0; i < nelem ; i++)
        {
          if (match_lens[i] == *pp - p1)
            for (j = 0;
                 j < d->follows[d->states[s1].mbps.elems[i].index].nelem; j++)
              insert(d->follows[d->states[s1].mbps.elems[i].index].elems[j],
                     &follows);
        }

      wc = inputwcs[*pp - mbclen - buf_begin];
      s1 = state_index(d, &follows, wc == L'\n', iswalnum(wc));
      realloc_trans_if_necessary(d, s1);
    }
  free(match_lens);
  free(follows.elems);
  return s1;
}
static void
prepare_wc_buf (const char *begin, const char *end)
{
#if MBS_SUPPORT
  unsigned char eol = eolbyte;
  size_t remain_bytes, i;

  buf_begin = (unsigned char *) begin;

  remain_bytes = 0;

    prepare_wc_buf_loop_21(&i, &end, &begin, &remain_bytes, &inputwcs, &mbs, &mblen_buf, &eol);

  buf_end = (unsigned char *) (begin + i);
  mblen_buf[i] = 0;
  inputwcs[i] = 0; /* sentinel */
#endif /* MBS_SUPPORT */
}
char *
dfaexec (struct dfa *d, char const *begin, char *end,
         int newline, int *count, int *backref)
{
  int s, s1;		/* Current state. */
  unsigned char const *p; /* Current input character. */
  int **trans, *t;	/* Copy of d->trans so it can be optimized
                                   into a register. */
  unsigned char eol = eolbyte;	/* Likewise for eolbyte.  */
  unsigned char saved_end;
  static int sbit[NOTCHAR];	/* Table for anding with d->success. */
  static int sbit_init;

  if (! sbit_init)
    {
      unsigned int i;

      sbit_init = 1;

    dfaexec_loop_22(&i, sbit);
      sbit[eol] = 4;
    }

  if (! d->tralloc)
    build_state_zero(d);

  s = s1 = 0;
  p = (unsigned char const *) begin;
  trans = d->trans;
  saved_end = *(unsigned char *) end;
  *end = eol;

  if (d->mb_cur_max > 1)
    {
      MALLOC(mblen_buf, end - begin + 2);
      MALLOC(inputwcs, end - begin + 2);
      memset(&mbs, 0, sizeof(mbstate_t));
      prepare_wc_buf ((const char *) p, end);
    }

  for (;;)
    {
      if (d->mb_cur_max > 1)
        while ((t = trans[s]))
          {
            if (p > buf_end)
              break;
            s1 = s;
            SKIP_REMAINS_MB_IF_INITIAL_STATE(s, p);

            if (d->states[s].mbps.nelem == 0)
              {
                s = t[*p++];
                continue;
              }

            /* Falling back to the glibc matcher in this case gives
               better performance (up to 25% better on [a-z], for
               example) and enables support for collating symbols and
               equivalence classes.  */
            if (backref)
              {
                *backref = 1;
                free(mblen_buf);
                free(inputwcs);
                *end = saved_end;
                return (char *) p;
              }

            /* Can match with a multibyte character (and multi character
               collating element).  Transition table might be updated.  */
            s = transit_state(d, s, &p);
            trans = d->trans;
          }
      else
        {
          while ((t = trans[s]) != 0)
            {
              s1 = t[*p++];
              if ((t = trans[s1]) == 0)
                {
                  int tmp = s; s = s1; s1 = tmp; /* swap */
                  break;
                }
              s = t[*p++];
            }
        }

      if (s >= 0 && (char *) p <= end && d->fails[s])
        {
          if (d->success[s] & sbit[*p])
            {
              if (backref)
                *backref = (d->states[s].backref != 0);
              if (d->mb_cur_max > 1)
                {
                  free(mblen_buf);
                  free(inputwcs);
                }
              *end = saved_end;
              return (char *) p;
            }

          s1 = s;
          if (d->mb_cur_max > 1)
            {
              /* Can match with a multibyte character (and multicharacter
                 collating element).  Transition table might be updated.  */
              s = transit_state(d, s, &p);
              trans = d->trans;
            }
          else
            s = d->fails[s][*p++];
          continue;
        }

      /* If the previous character was a newline, count it. */
      if ((char *) p <= end && p[-1] == eol)
        {
          if (count)
            ++*count;

          if (d->mb_cur_max > 1)
            prepare_wc_buf ((const char *) p, end);
        }

      /* Check if we've run off the end of the buffer. */
      if ((char *) p > end)
        {
          if (d->mb_cur_max > 1)
            {
              free(mblen_buf);
              free(inputwcs);
            }
          *end = saved_end;
          return NULL;
        }

      if (s >= 0)
        {
          build_state(s, d);
          trans = d->trans;
          continue;
        }

      if (p[-1] == eol && newline)
        {
          s = d->newlines[s1];
          continue;
        }

      s = 0;
    }
}
static void
free_mbdata (struct dfa *d)
{
  unsigned int i;

  free(d->multibyte_prop);
  d->multibyte_prop = NULL;


    free_mbdata_loop_23(&i, &d);

  free(d->mbcsets);
  d->mbcsets = NULL;
  d->nmbcsets = 0;
}
void
dfainit (struct dfa *d)
{
  memset (d, 0, sizeof *d);

  d->calloc = 1;
  MALLOC(d->charclasses, d->calloc);

  d->talloc = 1;
  MALLOC(d->tokens, d->talloc);

  d->mb_cur_max = MB_CUR_MAX;

  if (d->mb_cur_max > 1)
    {
      d->nmultibyte_prop = 1;
      MALLOC(d->multibyte_prop, d->nmultibyte_prop);
      d->mbcsets_alloc = 1;
      MALLOC(d->mbcsets, d->mbcsets_alloc);
    }
}
static void
dfaoptimize (struct dfa *d)
{
  if (!MBS_SUPPORT || !using_utf8())
    return;

  unsigned int i;
  	{ int re_arg_pa1_2 = -1; 
    dfaoptimize_loop_2(&i, &d, &re_arg_pa1_2);
	if(re_arg_pa1_2 != -1) return; }


  free_mbdata (d);
  d->mb_cur_max = 1;
}
void
dfacomp (char const *s, size_t len, struct dfa *d, int searchflag)
{
  dfainit(d);
  dfaparse(s, len, d);
  dfamust(d);
  dfaoptimize(d);
  dfaanalyze(d, searchflag);
}
void
dfafree (struct dfa *d)
{
  int i;
  struct dfamust *dm, *ndm;

  free(d->charclasses);
  free(d->tokens);

  if (d->mb_cur_max > 1)
    free_mbdata(d);


    dfafree_loop_24(&i, &d);
  free(d->states);

    dfafree_loop_25(&i, &d);
  free(d->follows);

    dfafree_loop_26(&i, &d);
  free(d->realtrans);
  free(d->fails);
  free(d->newlines);
  free(d->success);

    dfafree_loop_27(&dm, &d, &ndm);
}
static char *
icatalloc (char *old, char const *new)
{
  char *result;
  size_t oldsize = old == NULL ? 0 : strlen (old);
  size_t newsize = new == NULL ? 0 : strlen (new);
  if (newsize == 0)
    return old;
  result = xrealloc (old, oldsize + newsize + 1);
  strcpy (result + oldsize, new);
  return result;
}
static char *
icpyalloc (char const *string)
{
  return icatalloc (NULL, string);
}
static char *
istrstr (char const *lookin, char const *lookfor)
{
  char const *cp;
  size_t len;

  len = strlen(lookfor);
	{ int re_arg_pa1_28 = -1; char * re_arg_pa2_28;
    istrstr_loop_28(&cp, &lookin, &lookfor, &len, &re_arg_pa1_28, &re_arg_pa2_28);
	if(re_arg_pa1_28 != -1) return re_arg_pa2_28; }
  return NULL;
}
static void
freelist (char **cpp)
{
  int i;

  if (cpp == NULL)
    return;

    freelist_loop_29(&i, &cpp);
}
static char **
enlist (char **cpp, char *new, size_t len)
{
  int i, j;

  if (cpp == NULL)
    return NULL;
  if ((new = icpyalloc(new)) == NULL)
    {
      freelist(cpp);
      return NULL;
    }
  new[len] = '\0';
  /* Is there already something in the list that's new (or longer)? */
  for (i = 0; cpp[i] != NULL; ++i)
    if (istrstr(cpp[i], new) != NULL)
      {
        free(new);
        return cpp;
      }
  /* Eliminate any obsoleted strings. */
  j = 0;
  while (cpp[j] != NULL)
    if (istrstr(new, cpp[j]) == NULL)
      ++j;
    else
      {
        free(cpp[j]);
        if (--i == j)
          break;
        cpp[j] = cpp[i];
        cpp[i] = NULL;
      }
  /* Add the new string. */
  cpp = xnrealloc(cpp, i + 2, sizeof *cpp);
  cpp[i] = new;
  cpp[i + 1] = NULL;
  return cpp;
}
static char **
comsubs (char *left, char const *right)
{
  char **cpp;
  char *lcp;
  char *rcp;
  size_t i, len;

  if (left == NULL || right == NULL)
    return NULL;
  cpp = malloc(sizeof *cpp);
  if (cpp == NULL)
    return NULL;
  cpp[0] = NULL;
  for (lcp = left; *lcp != '\0'; ++lcp)
    {
      len = 0;
      rcp = strchr (right, *lcp);
      while (rcp != NULL)
        {
          for (i = 1; lcp[i] != '\0' && lcp[i] == rcp[i]; ++i)
            continue;
          if (i > len)
            len = i;
          rcp = strchr (rcp + 1, *lcp);
        }
      if (len == 0)
        continue;
      {
        char **p = enlist (cpp, lcp, len);
        if (p == NULL)
          {
            freelist (cpp);
            cpp = NULL;
            break;
          }
        cpp = p;
      }
    }
  return cpp;
}
static char **
addlists (char **old, char **new)
{
  int i;

  if (old == NULL || new == NULL)
    return NULL;
  for (i = 0; new[i] != NULL; ++i)
    {
      old = enlist(old, new[i], strlen(new[i]));
      if (old == NULL)
        break;
    }
  return old;
}
static char **
inboth (char **left, char **right)
{
  char **both;
  char **temp;
  int lnum, rnum;

  if (left == NULL || right == NULL)
    return NULL;
  both = malloc(sizeof *both);
  if (both == NULL)
    return NULL;
  both[0] = NULL;
  for (lnum = 0; left[lnum] != NULL; ++lnum)
    {
      for (rnum = 0; right[rnum] != NULL; ++rnum)
        {
          temp = comsubs(left[lnum], right[rnum]);
          if (temp == NULL)
            {
              freelist(both);
              return NULL;
            }
          both = addlists(both, temp);
          freelist(temp);
          free(temp);
          if (both == NULL)
            return NULL;
        }
    }
  return both;
}
static void
resetmust (must *mp)
{
  mp->left[0] = mp->right[0] = mp->is[0] = '\0';
  freelist(mp->in);
}
static void
dfamust (struct dfa *d)
{
  must *musts;
  must *mp;
  char *result;
  int ri;
  int i;
  int exact;
  token t;
  static must must0;
  struct dfamust *dm;
  static char empty_string[] = "";

  result = empty_string;
  exact = 0;
  musts = xnmalloc(d->tindex + 1, sizeof *musts);
  mp = musts;

    dfamust_loop_30(&i, &d, &mp, &must0);

    dfamust_loop_31(&i, &d, &mp);
#ifdef DEBUG
  fprintf(stderr, "dfamust:\n");
  for (i = 0; i < d->tindex; ++i)
    {
      fprintf(stderr, " %d:", i);
      prtok(d->tokens[i]);
    }
  putc('\n', stderr);
#endif
  for (ri = 0; ri < d->tindex; ++ri)
    {
      switch (t = d->tokens[ri])
        {
        case LPAREN:
        case RPAREN:
          assert (!"neither LPAREN nor RPAREN may appear here");
        case EMPTY:
        case BEGLINE:
        case ENDLINE:
        case BEGWORD:
        case ENDWORD:
        case LIMWORD:
        case NOTLIMWORD:
        case BACKREF:
          resetmust(mp);
          break;
        case STAR:
        case QMARK:
          assert (musts < mp);
          --mp;
          resetmust(mp);
          break;
        case OR:
          assert (&musts[2] <= mp);
          {
            char **new;
            must *lmp;
            must *rmp;
            int j, ln, rn, n;

            rmp = --mp;
            lmp = --mp;
            /* Guaranteed to be.  Unlikely, but. . . */
            if (!STREQ (lmp->is, rmp->is))
              lmp->is[0] = '\0';
            /* Left side--easy */
            i = 0;
            while (lmp->left[i] != '\0' && lmp->left[i] == rmp->left[i])
              ++i;
            lmp->left[i] = '\0';
            /* Right side */
            ln = strlen(lmp->right);
            rn = strlen(rmp->right);
            n = ln;
            if (n > rn)
              n = rn;
            for (i = 0; i < n; ++i)
              if (lmp->right[ln - i - 1] != rmp->right[rn - i - 1])
                break;
            for (j = 0; j < i; ++j)
              lmp->right[j] = lmp->right[(ln - i) + j];
            lmp->right[j] = '\0';
            new = inboth(lmp->in, rmp->in);
            if (new == NULL)
              goto done;
            freelist(lmp->in);
            free(lmp->in);
            lmp->in = new;
          }
          break;
        case PLUS:
          assert (musts < mp);
          --mp;
          mp->is[0] = '\0';
          break;
        case END:
          assert (mp == &musts[1]);
          for (i = 0; musts[0].in[i] != NULL; ++i)
            if (strlen(musts[0].in[i]) > strlen(result))
              result = musts[0].in[i];
          if (STREQ (result, musts[0].is))
            exact = 1;
          goto done;
        case CAT:
          assert (&musts[2] <= mp);
          {
            must *lmp;
            must *rmp;

            rmp = --mp;
            lmp = --mp;
            /* In.  Everything in left, plus everything in
               right, plus catenation of
               left's right and right's left. */
            lmp->in = addlists(lmp->in, rmp->in);
            if (lmp->in == NULL)
              goto done;
            if (lmp->right[0] != '\0' &&
                rmp->left[0] != '\0')
              {
                char *tp;

                tp = icpyalloc(lmp->right);
                tp = icatalloc(tp, rmp->left);
                lmp->in = enlist(lmp->in, tp, strlen(tp));
                free(tp);
                if (lmp->in == NULL)
                  goto done;
              }
            /* Left-hand */
            if (lmp->is[0] != '\0')
              {
                lmp->left = icatalloc(lmp->left,
                                      rmp->left);
                if (lmp->left == NULL)
                  goto done;
              }
            /* Right-hand */
            if (rmp->is[0] == '\0')
              lmp->right[0] = '\0';
            lmp->right = icatalloc(lmp->right, rmp->right);
            if (lmp->right == NULL)
              goto done;
            /* Guaranteed to be */
            if (lmp->is[0] != '\0' && rmp->is[0] != '\0')
              {
                lmp->is = icatalloc(lmp->is, rmp->is);
                if (lmp->is == NULL)
                  goto done;
              }
            else
              lmp->is[0] = '\0';
          }
          break;
        default:
          if (t < END)
            {
              assert (!"oops! t >= END");
            }
          else if (t == '\0')
            {
              /* not on *my* shift */
              goto done;
            }
          else if (t >= CSET
                   || !MBS_SUPPORT
                   || t == ANYCHAR
                   || t == MBCSET
                   )
            {
              /* easy enough */
              resetmust(mp);
            }
          else
            {
              /* plain character */
              resetmust(mp);
              mp->is[0] = mp->left[0] = mp->right[0] = t;
              mp->is[1] = mp->left[1] = mp->right[1] = '\0';
              mp->in = enlist(mp->in, mp->is, (size_t)1);
              if (mp->in == NULL)
                goto done;
            }
          break;
        }
#ifdef DEBUG
      fprintf(stderr, " node: %d:", ri);
      prtok(d->tokens[ri]);
      fprintf(stderr, "\n  in:");
      for (i = 0; mp->in[i]; ++i)
        fprintf(stderr, " \"%s\"", mp->in[i]);
      fprintf(stderr, "\n  is: \"%s\"\n", mp->is);
      fprintf(stderr, "  left: \"%s\"\n", mp->left);
      fprintf(stderr, "  right: \"%s\"\n", mp->right);
#endif
      ++mp;
    }
 done:
  if (strlen(result))
    {
      MALLOC(dm, 1);
      dm->exact = exact;
      MALLOC(dm->must, strlen(result) + 1);
      strcpy(dm->must, result);
      dm->next = d->musts;
      d->musts = dm;
    }
  mp = musts;
  for (i = 0; i <= d->tindex; ++i)
    {
      freelist(mp[i].in);
      free(mp[i].in);
      free(mp[i].left);
      free(mp[i].right);
      free(mp[i].is);
    }
  free(mp);
}
struct dfa *
dfaalloc (void)
{
  return xmalloc (sizeof (struct dfa));
}
struct dfamust *
dfamusts (struct dfa const *d)
{
  return d->musts;
}
