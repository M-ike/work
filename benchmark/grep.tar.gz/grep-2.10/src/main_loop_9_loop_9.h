#ifndef main_loop_9_loop_9_h_
#define main_loop_9_loop_9_h_

#include "main_loop_9.h"
#define SGR_START  sgr_start
#define SGR_END    sgr_end
#define PR_SGR_FMT(fmt, s) do { if (*(s)) printf((fmt), (s)); } while (0)
#define PR_SGR_FMT_IF(fmt, s) \
  do { if (color_option && *(s)) printf((fmt), (s)); } while (0)
#define PR_SGR_START(s)    PR_SGR_FMT(   SGR_START, (s))
#define PR_SGR_END(s)      PR_SGR_FMT(   SGR_END,   (s))
#define PR_SGR_START_IF(s) PR_SGR_FMT_IF(SGR_START, (s))
#define PR_SGR_END_IF(s)   PR_SGR_FMT_IF(SGR_END,   (s))
#define INITIAL_BUFSIZE 32768	/* Initial buffer size, not counting slop. */
#define ALIGN_TO(val, alignment) \
  ((size_t) (val) % (alignment) == 0 \
   ? (val) \
   : (val) + ((alignment) - (size_t) (val) % (alignment)))

void setmatcher_loop_6_loop_2(unsigned int * *i, const struct matcher matchers[], const char ** *m, compile_fp_t * *compile, execute_fp_t * *execute, const char ** *matcher, int * *re_arg_pa1_6, int *re_arg_pa1_2);
void fillbuf_loop_1_loop_3(size_t * *newsize, size_t * *bufalloc, size_t * *pagesize, size_t * *minsize);
void grepdir_loop_5_loop_5(const struct stats ** *ancestor, const struct stats ** *stats, int * *suppress_errors, const char ** *dir, int * *re_arg_pa1_5, int * *re_arg_pa2_5, int *re_arg_pa1_5);
void nlscan_loop_2_loop_8(const char ** *beg, const char ** *lastnl, const char ** *lim, unsigned char * *eolbyte, size_t * *newlines);
void prtext_loop_3_loop_1(int * *i, int * *out_before, const char ** *p, const char ** *bp, char * *eol);
void main_loop_9_loop_7(size_t * *keyalloc, size_t * *keycc);
void do_execute_loop_4_loop_6(const char ** *line_next, const char ** *buf, size_t * *size, unsigned char * *eolbyte, const char ** *start_ptr, size_t * *result, execute_fp_t * *execute, size_t ** *match_size, int * *re_arg_pa1_4, size_t * *re_arg_pa2_4, int *re_arg_pa1_6);
void prepend_args_loop_7_loop_9(const char ** *o, int * *re_arg_pa1_7, int * *re_arg_pa2_7, int * *n, char *** *argv, char ** *b, int *re_arg_pa1_9);
void parse_grep_colors_loop_8_loop_4(char ** *q, struct color_cap color_dict[], char ** *name, char ** *val, const char ** *p, int * *re_arg_pa1_8, int *re_arg_pa1_4);

#endif
