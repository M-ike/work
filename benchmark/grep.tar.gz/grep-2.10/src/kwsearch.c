#include "kwsearch_loop_1.h"
void
Fcompile (char const *pattern, size_t size)
{
  char const *err;
  size_t psize = size;
  char const *pat = (match_icase && MB_CUR_MAX > 1
                     ? mbtolower (pattern, &psize)
                     : pattern);

  kwsinit (&kwset);

  char const *beg = pat;
  do
    {
      char const *lim;
      char const *end;

    Fcompile_loop_1(&lim, &beg, &end, &pat, &psize);

      if ((err = kwsincr (kwset, beg, end - beg)) != NULL)
        error (EXIT_TROUBLE, 0, "%s", err);
      beg = lim;
    }
  while (beg < pat + psize);

  if ((err = kwsprep (kwset)) != NULL)
    error (EXIT_TROUBLE, 0, "%s", err);
}
size_t
Fexecute (char const *buf, size_t size, size_t *match_size,
          char const *start_ptr)
{
  char const *beg, *try, *end, *mb_start;
  size_t len;
  char eol = eolbyte;
  struct kwsmatch kwsmatch;
  size_t ret_val;
  if (MB_CUR_MAX > 1)
    {
      if (match_icase)
        {
          char *case_buf = mbtolower (buf, &size);
          if (start_ptr)
            start_ptr = case_buf + (start_ptr - buf);
          buf = case_buf;
        }
    }

  for (mb_start = beg = start_ptr ? start_ptr : buf; beg <= buf + size; beg++)
    {
      size_t offset = kwsexec (kwset, beg, buf + size - beg, &kwsmatch);
      if (offset == (size_t) -1)
        goto failure;
      len = kwsmatch.size[0];
      if (MB_CUR_MAX > 1
          && is_mb_middle (&mb_start, beg + offset, buf + size, len))
        {
          /* The match was a part of multibyte character, advance at least
             one byte to ensure no infinite loop happens.  */
          mbstate_t s;
          memset (&s, 0, sizeof s);
          size_t mb_len = mbrlen (mb_start, (buf + size) - (beg + offset), &s);
          if (mb_len == (size_t) -2)
            goto failure;
          beg = mb_start;
          if (mb_len != (size_t) -1)
            beg += mb_len - 1;
          continue;
        }
      beg += offset;
      if (start_ptr && !match_words)
        goto success_in_beg_and_len;
      if (match_lines)
        {
          if (beg > buf && beg[-1] != eol)
            continue;
          if (beg + len < buf + size && beg[len] != eol)
            continue;
          goto success;
        }
      else if (match_words)
        for (try = beg; ; )
          {
            if (try > buf && WCHAR((unsigned char) try[-1]))
              break;
            if (try + len < buf + size && WCHAR((unsigned char) try[len]))
              {
                if (!len)
                  break;
                offset = kwsexec (kwset, beg, --len, &kwsmatch);
                if (offset == (size_t) -1)
                  break;
                try = beg + offset;
                len = kwsmatch.size[0];
              }
            else if (!start_ptr)
              goto success;
            else
              goto success_in_beg_and_len;
          } /* for (try) */
      else
        goto success;
    } /* for (beg in buf) */

 failure:
  ret_val = -1;
  goto out;

 success:
  if ((end = memchr (beg + len, eol, (buf + size) - (beg + len))) != NULL)
    end++;
  else
    end = buf + size;
  while (buf < beg && beg[-1] != eol)
    --beg;
  len = end - beg;
 success_in_beg_and_len:
  *match_size = len;
  ret_val = beg - buf;
 out:
  return ret_val;
}
