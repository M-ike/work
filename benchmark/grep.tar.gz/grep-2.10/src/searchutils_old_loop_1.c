#include "searchutils_old_loop_1.h"
#ifndef NCHAR
#define NCHAR (UCHAR_MAX + 1)

#endif

void kwsinit_loop_1(int *i, char trans[])
{
for ((*i) = 0; (*i) < NCHAR; ++(*i))
        trans[(*i)] = tolower ((*i));

}
