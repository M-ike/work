#include "kwsearch_old_loop_1.h"
#ifndef WCHAR
#define WCHAR(C) (isalnum (C) || (C) == '_')

#endif

void Fcompile_loop_1(const char * *lim, const char * *beg, const char * *end, const char * *pat, size_t *psize)
{
for ((*lim) = (*beg);; ++(*lim))
        {
          (*end) = (*lim);
          if ((*lim) >= (*pat) + (*psize))
            break;
         if (*(*lim) == '\n')
           {
             (*lim)++;
             break;
           }
#if HAVE_DOS_FILE_CONTENTS
         if (*(*lim) == '\r' && (*lim) + 1 < (*pat) + (*psize) && (*lim)[1] == '\n')
           {
             (*lim) += 2;
             break;
           }
#endif
        }

}
