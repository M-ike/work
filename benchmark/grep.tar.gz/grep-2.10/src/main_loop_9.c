#include "main_loop_9_loop_9.h"
void prtext_loop_3(int *i, int *out_before, const char * *p, const char * *bp, char *eol)
{
      
    prtext_loop_3_loop_1(&i, &out_before, &p, &bp, &eol);

}
void setmatcher_loop_6(unsigned int *i, const struct matcher matchers[], const char * *m, compile_fp_t *compile, execute_fp_t *execute, const char * *matcher, int *re_arg_pa1_6)
{
      	{ int re_arg_pa1_6_loop_2 = -1; 
    setmatcher_loop_6_loop_2(&i, &matchers, &m, &compile, &execute, &matcher, &re_arg_pa1_6, &re_arg_pa1_2);
	if(re_arg_pa1_6_loop_2 != -1) return; }

}
void fillbuf_loop_1(size_t *newsize, size_t *bufalloc, size_t *pagesize, size_t *minsize)
{
      
    fillbuf_loop_1_loop_3(&newsize, &bufalloc, &pagesize, &minsize);

}
void parse_grep_colors_loop_8(char * *q, struct color_cap color_dict[], char * *name, char * *val, const char * *p, int *re_arg_pa1_8)
{
  	{ int re_arg_pa1_8_loop_4 = -1; 
    parse_grep_colors_loop_8_loop_4(&q, &color_dict, &name, &val, &p, &re_arg_pa1_8, &re_arg_pa1_4);
	if(re_arg_pa1_8_loop_4 != -1) return; }

}
void grepdir_loop_5(const struct stats * *ancestor, const struct stats * *stats, int *suppress_errors, const char * *dir, int *re_arg_pa1_5, int *re_arg_pa2_5)
{
    	{ int re_arg_pa1_5_loop_5 = -1; 
    grepdir_loop_5_loop_5(&ancestor, &stats, &suppress_errors, &dir, &re_arg_pa1_5, &re_arg_pa2_5, &re_arg_pa1_5);
	if(re_arg_pa1_5_loop_5 != -1) return; }

}
void do_execute_loop_4(const char * *line_next, const char * *buf, size_t *size, unsigned char *eolbyte, const char * *start_ptr, size_t *result, execute_fp_t *execute, size_t * *match_size, int *re_arg_pa1_4, size_t *re_arg_pa2_4)
{
  	{ int re_arg_pa1_4_loop_6 = -1; 
    do_execute_loop_4_loop_6(&line_next, &buf, &size, &eolbyte, &start_ptr, &result, &execute, &match_size, &re_arg_pa1_4, &re_arg_pa2_4, &re_arg_pa1_6);
	if(re_arg_pa1_4_loop_6 != -1) return; }

}
void main_loop_9(size_t *keyalloc, size_t *keycc)
{
        
    main_loop_9_loop_7(&keyalloc, &keycc);

}
void nlscan_loop_2(const char * *beg, const char * *lastnl, const char * *lim, unsigned char *eolbyte, size_t *newlines)
{
  
    nlscan_loop_2_loop_8(&beg, &lastnl, &lim, &eolbyte, &newlines);

}
void prepend_args_loop_7(const char * *o, int *n, char ** *argv, char * *b, int *re_arg_pa1_7, int *re_arg_pa2_7)
{
  	{ int re_arg_pa1_7_loop_9 = -1; 
    prepend_args_loop_7_loop_9(&o, &re_arg_pa1_7, &re_arg_pa2_7, &n, &argv, &b, &re_arg_pa1_9);
	if(re_arg_pa1_7_loop_9 != -1) return; }

}
