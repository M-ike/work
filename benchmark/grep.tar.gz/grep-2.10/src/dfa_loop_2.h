#ifndef dfa_loop_2_h_
#define dfa_loop_2_h_

#include "dfa_loop_31.h"

void state_index_loop_1(int *j, const position_set * *s, struct dfa * *d, int *constraint, int *newline, int *letter, int *i);
void dfaoptimize_loop_2(unsigned int *i, struct dfa * *d, int *re_arg_pa1_2);

#endif
