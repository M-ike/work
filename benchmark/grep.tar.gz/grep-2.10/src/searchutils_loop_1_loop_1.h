#ifndef searchutils_loop_1_loop_1_h_
#define searchutils_loop_1_loop_1_h_

#include "searchutils_loop_1.h"

void kwsinit_loop_1_loop_1(int * *i, char trans[]);

#endif
