#ifndef main_old_loop_9_h_
#define main_old_loop_9_h_

/* grep.c - main driver file for grep.
   Copyright (C) 1992, 1997-2002, 2004-2011 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 3, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street - Fifth Floor, Boston, MA
   02110-1301, USA.  */
/* Written July 1992 by Mike Haertel.  */
#include <config.h>
#include <sys/types.h>
#include <sys/stat.h>
#if defined HAVE_SETRLIMIT
# include <sys/time.h>
# include <sys/resource.h>
#endif
#include "mbsupport.h"
#include <wchar.h>
#include <wctype.h>
#include <fcntl.h>
#include <stdio.h>
#include "system.h"
#include "argmatch.h"
#include "c-ctype.h"
#include "closeout.h"
#include "error.h"
#include "exclude.h"
#include "exitfail.h"
#include "getopt.h"
#include "grep.h"
#include "intprops.h"
#include "isdir.h"
#include "progname.h"
#include "propername.h"
#include "quote.h"
#include "savedir.h"
#include "version-etc.h"
#include "xalloc.h"
#include "xstrtol.h"
#define SEP_CHAR_SELECTED ':'
#define SEP_CHAR_REJECTED '-'
#define SEP_STR_GROUP    "--"
#define STREQ(a, b) (strcmp (a, b) == 0)
#define AUTHORS \
  proper_name ("Mike Haertel"), \
  _("others, see <http://git.sv.gnu.org/cgit/grep.git/tree/AUTHORS>")
/* When stdout is connected to a regular file, save its stat
   information here, so that we can automatically skip it, thus
   avoiding a potential (racy) infinite loop.  */

struct stats
{
  struct stats const *parent;
  struct stat stat;
};
static int suppress_errors;
struct color_cap
  {
    const char *name;
    const char **var;
    const char *(*fct)(void);
  };
static struct color_cap color_dict[] =
  {
    { "mt", &selected_match_color, color_cap_mt_fct }, /* both ms/mc */
    { "ms", &selected_match_color, NULL }, /* selected matched text */
    { "mc", &context_match_color,  NULL }, /* context matched text */
    { "fn", &filename_color,       NULL }, /* filename */
    { "ln", &line_num_color,       NULL }, /* line number */
    { "bn", &byte_num_color,       NULL }, /* byte (sic) offset */
    { "se", &sep_color,            NULL }, /* separator */
    { "sl", &selected_line_color,  NULL }, /* selected lines */
    { "cx", &context_line_color,   NULL }, /* context lines */
    { "rv", NULL,                  color_cap_rv_fct }, /* -v reverses sl/cx */
    { "ne", NULL,                  color_cap_ne_fct }, /* no EL on SGR_* */
    { NULL, NULL,                  NULL }
  };
enum
{
  BINARY_FILES_OPTION = CHAR_MAX + 1,
  COLOR_OPTION,
  INCLUDE_OPTION,
  EXCLUDE_OPTION,
  EXCLUDE_FROM_OPTION,
  LINE_BUFFERED_OPTION,
  LABEL_OPTION,
  EXCLUDE_DIRECTORY_OPTION,
  GROUP_SEPARATOR_OPTION,
  MMAP_OPTION
};
unsigned char eolbyte;
enum directories_type
  {
    READ_DIRECTORIES = 2,
    RECURSE_DIRECTORIES,
    SKIP_DIRECTORIES
  };
enum
  {
    READ_DEVICES,
    SKIP_DEVICES
  } devices = READ_DEVICES;
static compile_fp_t compile;
static execute_fp_t execute;
static size_t bufalloc;
static char *buflim;
static size_t pagesize;
enum
{
  BINARY_BINARY_FILES,
  TEXT_BINARY_FILES,
  WITHOUT_MATCH_BINARY_FILES
} binary_files;
static int out_quiet;
static int out_before;
static char const *lastnl;
static char const *lastout;
static off_t outleft;
void grepdir_loop_5(const struct stats * *ancestor, const struct stats * *stats, const char * *dir, int *re_arg_pa1_5, int *re_arg_pa2_5);
void setmatcher_loop_6(unsigned int *i, const char * *m, const char * *matcher, int *re_arg_pa1_6);
void parse_grep_colors_loop_8(char * *q, char * *name, char * *val, const char * *p, int *re_arg_pa1_8);
void do_execute_loop_4(const char * *line_next, const char * *buf, size_t *size, const char * *start_ptr, size_t *result, size_t * *match_size, int *re_arg_pa1_4, size_t *re_arg_pa2_4);
void nlscan_loop_2(const char * *beg, const char * *lim, size_t *newlines);
void fillbuf_loop_1(size_t *newsize, size_t *minsize);
void prtext_loop_3(int *i, const char * *p, const char * *bp, char *eol);
void main_loop_9(size_t *keyalloc, size_t *keycc);
void prepend_args_loop_7(const char * *o, int *n, char ** *argv, char * *b, int *re_arg_pa1_7, int *re_arg_pa2_7);

#endif
