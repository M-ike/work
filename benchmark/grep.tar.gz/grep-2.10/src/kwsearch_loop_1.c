#include "kwsearch_loop_1_loop_1.h"
void Fcompile_loop_1(const char * *lim, const char * *beg, const char * *end, const char * *pat, size_t *psize)
{
      
    Fcompile_loop_1_loop_1(&lim, &beg, &end, &pat, &psize);

}
