#include "searchutils_loop_1_loop_1.h"
void kwsinit_loop_1_loop_1(int * *i, char trans[])
{
for ((*(*i)) = 0; (*(*i)) < NCHAR; ++(*(*i)))
        (*trans)[(*(*i))] = tolower ((*(*i)));

}
