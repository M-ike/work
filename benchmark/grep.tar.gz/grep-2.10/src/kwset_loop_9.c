#include "kwset_loop_9_loop_9.h"
void kwsprep_loop_1(int *i, struct kwset * *kwset, struct trie * *curr)
{
      
    kwsprep_loop_1_loop_1(&i, &kwset, &curr);

}
void kwsprep_loop_4(struct trie * *curr, struct kwset * *kwset)
{
      
    kwsprep_loop_4_loop_2(&curr, &kwset);

}
void kwsprep_loop_5(int *i, struct trie * next[])
{
      
    kwsprep_loop_5_loop_3(&i, &next);

}
void bmexec_loop_9(int *i, int *len, const char * *tp, const char * *sp)
{
          
    bmexec_loop_9_loop_4(&i, &len, &tp, &sp);

}
void kwsprep_loop_7(int *i, struct kwset * *kwset, unsigned char delta[], const char * *trans)
{
    
    kwsprep_loop_7_loop_5(&i, &kwset, &delta, &trans);

}
void kwsprep_loop_3(int *i, struct kwset * *kwset, char *c)
{
      
    kwsprep_loop_3_loop_6(&i, &kwset, &c);

}
void kwsprep_loop_6(int *i, struct kwset * *kwset, struct trie * next[], const char * *trans)
{
        
    kwsprep_loop_6_loop_7(&i, &kwset, &next, &trans);

}
void kwsprep_loop_2(int *i, struct kwset * *kwset, unsigned char delta[])
{
      
    kwsprep_loop_2_loop_8(&i, &kwset, &delta);

}
void bmexec_loop_8(const char * *ep, const char * *text, size_t *size, int *len, const char * *tp, int *d, const unsigned char * *d1, int *gc, int *i, const char * *sp, int *md2, int *re_arg_pa1_8, size_t *re_arg_pa2_8)
{
    	{ int re_arg_pa1_8_loop_9 = -1; 
    bmexec_loop_8_loop_9(&ep, &text, &size, &len, &tp, &d, &d1, &gc, &i, &sp, &re_arg_pa1_8, &re_arg_pa2_8, &md2, &re_arg_pa1_9);
	if(re_arg_pa1_8_loop_9 != -1) return; }

}
