#ifndef kwset_loop_9_loop_9_h_
#define kwset_loop_9_loop_9_h_

#include "kwset_loop_9.h"
#define DEPTH_SIZE (CHAR_BIT + CHAR_BIT/2)

void bmexec_loop_8_loop_9(const char ** *ep, const char ** *text, size_t * *size, int * *len, const char ** *tp, int * *d, const unsigned char ** *d1, int * *gc, int * *i, const char ** *sp, int * *re_arg_pa1_8, size_t * *re_arg_pa2_8, int * *md2, int *re_arg_pa1_9);
void kwsprep_loop_6_loop_7(int * *i, struct kwset ** *kwset, struct trie * next[], const char ** *trans);
void kwsprep_loop_1_loop_1(int * *i, struct kwset ** *kwset, struct trie ** *curr);
void kwsprep_loop_3_loop_6(int * *i, struct kwset ** *kwset, char * *c);
void kwsprep_loop_7_loop_5(int * *i, struct kwset ** *kwset, unsigned char delta[], const char ** *trans);
void kwsprep_loop_2_loop_8(int * *i, struct kwset ** *kwset, unsigned char delta[]);
void kwsprep_loop_4_loop_2(struct trie ** *curr, struct kwset ** *kwset);
void bmexec_loop_9_loop_4(int * *i, int * *len, const char ** *tp, const char ** *sp);
void kwsprep_loop_5_loop_3(int * *i, struct trie * next[]);

#endif
