#ifndef kwsearch_loop_1_loop_1_h_
#define kwsearch_loop_1_loop_1_h_

#include "kwsearch_loop_1.h"

void Fcompile_loop_1_loop_1(const char ** *lim, const char ** *beg, const char ** *end, const char ** *pat, size_t * *psize);

#endif
