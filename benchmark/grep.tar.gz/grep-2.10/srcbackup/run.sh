#!/bin/sh

BIN=/home/zql/desktop/LoopExtractor00/driver
SRC=.

file_list=""

for file in `find $SRC -name "*.c"`
do
    file_list=$file_list$file" "
done

echo $file_list
$BIN -I/home/zql/desktop/grep-2.10/lib -I/home/zql/desktop/grep-2.10/ -I/home/zql/desktop/grep-2.10/src -I/usr/include -I/usr/lib/gcc/x86_64-linux-gnu/4.6/include $file_list
